`ifndef WRITE_RESPONSE_BRIDGE_SV
`define WRITE_RESPONSE_BRIDGE_SV

module write_response_bridge #(
    parameter DATA_WIDTH = 2
)(
    //==================================================
    // PCLK DOMAIN
    //==================================================

    input  logic PCLK,
    input  logic PRESETn,

    input  logic write_resp_valid,
    input  logic write_resp_error,


    //==================================================
    // ACLK DOMAIN
    //==================================================

    input  logic ACLK,
    input  logic ARESETn,

    // AXI B channel
    output logic axi_write_valid,
    output logic [DATA_WIDTH-1:0] axi_write_resp,
    input  logic axi_write_ready
);


    //==================================================
    // FIFO SIGNALS
    //==================================================

    logic fifo_write_en;
    logic fifo_read_en;

    logic [DATA_WIDTH-1:0] fifo_write_data;
    logic [DATA_WIDTH-1:0] fifo_read_data;

    logic fifo_full;
    logic fifo_empty;


    //==================================================
    // APB ERROR -> AXI RESPONSE
    //
    // 2'b00 = OKAY
    // 2'b10 = SLVERR
    //==================================================

    always_comb begin

        if (write_resp_error)
            fifo_write_data = 2'b10;
        else
            fifo_write_data = 2'b00;

    end


    //==================================================
    // WRITE RESPONSE INTO FIFO
    //==================================================

    assign fifo_write_en =
        write_resp_valid && !fifo_full;


    //==================================================
    // READ RESPONSE FROM FIFO
    //==================================================

    assign fifo_read_en =
        !axi_write_valid &&
        !fifo_empty;


    //==================================================
    // ASYNCHRONOUS FIFO
    // PCLK -> ACLK
    //==================================================

    async_fifo #(
        .DATA_WIDTH(DATA_WIDTH),
        .DEPTH(4)
    ) write_response_fifo (

        .wclk      (PCLK),
        .wrst_n    (PRESETn),

        .write_en  (fifo_write_en),
        .write_data(fifo_write_data),

        .full      (fifo_full),

        .rclk      (ACLK),
        .rrst_n    (ARESETn),

        .read_en   (fifo_read_en),
        .read_data (fifo_read_data),

        .empty     (fifo_empty)

    );


    //==================================================
    // AXI B CHANNEL
    //==================================================

    always_ff @(posedge ACLK or negedge ARESETn) begin

        if (!ARESETn) begin

            axi_write_valid <= 1'b0;
            axi_write_resp  <= 2'b00;

        end

        else begin

            // Load response from FIFO
            if (!axi_write_valid && !fifo_empty) begin

                axi_write_resp  <= fifo_read_data;
                axi_write_valid <= 1'b1;

            end

            // BVALID/BREADY handshake
            else if (axi_write_valid && axi_write_ready) begin

                axi_write_valid <= 1'b0;

            end

        end

    end

endmodule

`endif