module axi_write_data_bridge #(
    parameter DATA_WIDTH = 32
)(
    axi_if axi,

    input logic PCLK,
    input logic PRESETn,

    // Write data available on PCLK side
    output logic                  wdata_valid,
    output logic [DATA_WIDTH-1:0] wdata,

    // Downstream block consumes write data
    input logic                   wdata_ready
);

    //==================================================
    // ASYNC FIFO SIGNALS
    //==================================================

    logic [DATA_WIDTH-1:0] fifo_write_data;
    logic [DATA_WIDTH-1:0] fifo_read_data;

    logic fifo_write_en;
    logic fifo_read_en;

    logic fifo_full;
    logic fifo_empty;

    //==================================================
    // PCLK SIDE REGISTER
    //==================================================

    logic [DATA_WIDTH-1:0] wdata_reg;

    logic wdata_valid_reg;

    //==================================================
    // PCLK CONTROL FSM
    //==================================================

    typedef enum logic [1:0] {
        PCLK_IDLE,
        PCLK_READ,
        PCLK_HOLD
    } pclk_state_t;

    pclk_state_t pclk_state;

    //==================================================
    // ASYNC WRITE DATA FIFO
    //==================================================

    async_fifo #(
        .DATA_WIDTH(DATA_WIDTH),
        .DEPTH(8)
    ) write_data_fifo (

        //================================================
        // ACLK / AXI SIDE
        //================================================

        .wclk       (axi.ACLK),
        .wrst_n     (axi.ARESETn),

        .write_en   (fifo_write_en),
        .write_data (fifo_write_data),

        .full       (fifo_full),

        //================================================
        // PCLK / APB SIDE
        //================================================

        .rclk       (PCLK),
        .rrst_n     (PRESETn),

        .read_en    (fifo_read_en),
        .read_data  (fifo_read_data),

        .empty      (fifo_empty)

    );

    //==================================================
    // AXI WREADY
    //==================================================

    always_comb begin

        axi.WREADY = 1'b0;

        if (axi.ARESETn && !fifo_full)
            axi.WREADY = 1'b1;

    end

    //==================================================
    // WRITE DATA INTO FIFO
    //==================================================

    always_comb begin

        fifo_write_en   = 1'b0;
        fifo_write_data = '0;

        if (axi.WVALID && axi.WREADY) begin

            fifo_write_en   = 1'b1;
            fifo_write_data = axi.WDATA;

        end

    end

    //==================================================
    // FIFO READ CONTROL
    //==================================================

    always_comb begin

        fifo_read_en = 1'b0;

        if (pclk_state == PCLK_IDLE) begin

            if (!fifo_empty)
                fifo_read_en = 1'b1;

        end

    end

    //==================================================
    // PCLK CONTROL
    //==================================================

    always_ff @(posedge PCLK or negedge PRESETn) begin

        if (!PRESETn) begin

            pclk_state     <= PCLK_IDLE;
            wdata_reg      <= '0;
            wdata_valid_reg <= 1'b0;

        end

        else begin

            case (pclk_state)

                //======================================
                // WAIT FOR WRITE DATA
                //======================================

                PCLK_IDLE: begin

                    if (!fifo_empty)
                        pclk_state <= PCLK_READ;

                end

                //======================================
                // CAPTURE FIFO DATA
                //======================================

                PCLK_READ: begin

                    wdata_reg       <= fifo_read_data;
                    wdata_valid_reg <= 1'b1;

                    pclk_state <= PCLK_HOLD;

                end

                //======================================
                // WRITE DATA AVAILABLE
                //======================================

                PCLK_HOLD: begin

                    if (wdata_ready) begin

                        wdata_valid_reg <= 1'b0;

                        pclk_state <= PCLK_IDLE;

                    end

                end

                default: begin

                    pclk_state <= PCLK_IDLE;

                end

            endcase

        end

    end

    //==================================================
    // OUTPUT WRITE DATA
    //==================================================

    always_comb begin

        wdata_valid = wdata_valid_reg;

        wdata       = wdata_reg;

    end

endmodule