module axi_request_bridge #(
    parameter ADDR_WIDTH = 32
)(
    axi_if axi,

    input logic PCLK,
    input logic PRESETn,

    output logic                  req_valid,
    output logic [ADDR_WIDTH-1:0] req_addr,
    output logic                  req_is_write,

    input logic                   req_ready
);

    //==================================================
    // REQUEST FIFO SIGNALS
    //==================================================

    logic [ADDR_WIDTH:0] request_data;

    logic request_write_en;
    logic request_full;

    logic request_read_en;
    logic request_empty;

    logic [ADDR_WIDTH:0] request_read_data;


    //==================================================
    // PCLK REQUEST REGISTER
    //==================================================

    logic [ADDR_WIDTH:0] request_reg;


    //==================================================
    // PCLK CONTROL FSM
    //==================================================

    typedef enum logic [1:0] {
        PCLK_IDLE,
        PCLK_READ,
        PCLK_HOLD
    } pclk_state_t;

    pclk_state_t pclk_state;


    //==================================================
    // ASYNC REQUEST FIFO
    //==================================================

    async_fifo #(
        .DATA_WIDTH(ADDR_WIDTH + 1),
        .DEPTH(8)
    ) request_fifo (

        //================================================
        // ACLK / AXI SIDE
        //================================================

        .wclk       (axi.ACLK),
        .wrst_n     (axi.ARESETn),

        .write_en   (request_write_en),
        .write_data (request_data),

        .full       (request_full),


        //================================================
        // PCLK / APB SIDE
        //================================================

        .rclk       (PCLK),
        .rrst_n     (PRESETn),

        .read_en    (request_read_en),
        .read_data  (request_read_data),

        .empty      (request_empty)

    );


    //==================================================
    // AXI READY SIGNALS
    //==================================================

    always_comb begin

        axi.AWREADY = 1'b0;
        axi.ARREADY = 1'b0;

        if (axi.ARESETn && !request_full) begin

            axi.AWREADY = 1'b1;
            axi.ARREADY = 1'b1;

        end

    end


    //==================================================
    // WRITE REQUEST INTO FIFO
    //==================================================

    always_comb begin

        request_write_en = 1'b0;
        request_data     = '0;


        // WRITE REQUEST HAS PRIORITY

        if (axi.AWVALID && axi.AWREADY) begin

            request_write_en = 1'b1;

            request_data = {
                1'b1,
                axi.AWADDR
            };

        end


        // READ REQUEST

        else if (axi.ARVALID && axi.ARREADY) begin

            request_write_en = 1'b1;

            request_data = {
                1'b0,
                axi.ARADDR
            };

        end

    end


    //==================================================
    // FIFO READ CONTROL
    //==================================================

    always_comb begin

        request_read_en = 1'b0;

        if ((pclk_state == PCLK_IDLE) &&
            !request_empty) begin

            request_read_en = 1'b1;

        end

    end


    //==================================================
    // PCLK CONTROL FSM
    //==================================================

    always_ff @(posedge PCLK or negedge PRESETn) begin

        if (!PRESETn) begin

            pclk_state  <= PCLK_IDLE;
            request_reg <= '0;

        end

        else begin

            case (pclk_state)

                //======================================
                // WAIT FOR FIFO DATA
                //======================================

                PCLK_IDLE: begin

                    if (!request_empty) begin

                        pclk_state <= PCLK_READ;

                    end

                end


                //======================================
                // CAPTURE FIFO DATA
                //======================================

                PCLK_READ: begin

                    request_reg <= request_read_data;

                    pclk_state <= PCLK_HOLD;

                end


                //======================================
                // REQUEST AVAILABLE
                //======================================

                PCLK_HOLD: begin

                    if (req_ready) begin

                        pclk_state <= PCLK_IDLE;

                    end

                end


                //======================================
                // DEFAULT
                //======================================

                default: begin

                    pclk_state <= PCLK_IDLE;

                end

            endcase

        end

    end


    //==================================================
    // REQUEST OUTPUT
    //==================================================

    always_comb begin

        req_valid = 1'b0;

        req_addr = request_reg[ADDR_WIDTH-1:0];

        req_is_write = request_reg[ADDR_WIDTH];


        if (pclk_state == PCLK_HOLD) begin

            req_valid = 1'b1;

        end

    end


    //==================================================
    // DEBUG MONITOR
    //==================================================

    always @(posedge axi.ACLK) begin

        if (axi.AWVALID && axi.AWREADY) begin

            $display(
                "REQUEST BRIDGE: AXI WRITE ACCEPTED, ADDR=%h",
                axi.AWADDR
            );

        end


        if (axi.ARVALID && axi.ARREADY) begin

            $display(
                "REQUEST BRIDGE: AXI READ ACCEPTED, ADDR=%h",
                axi.ARADDR
            );

        end

    end


    always @(posedge PCLK) begin

        if (request_read_en) begin

            $display(
                "REQUEST BRIDGE: FIFO READ, EMPTY=%b",
                request_empty
            );

        end


        if (pclk_state == PCLK_HOLD) begin

            $display(
                "REQUEST BRIDGE: REQ VALID=%b WRITE=%b ADDR=%h READY=%b",
                req_valid,
                req_is_write,
                req_addr,
                req_ready
            );

        end

    end

endmodule