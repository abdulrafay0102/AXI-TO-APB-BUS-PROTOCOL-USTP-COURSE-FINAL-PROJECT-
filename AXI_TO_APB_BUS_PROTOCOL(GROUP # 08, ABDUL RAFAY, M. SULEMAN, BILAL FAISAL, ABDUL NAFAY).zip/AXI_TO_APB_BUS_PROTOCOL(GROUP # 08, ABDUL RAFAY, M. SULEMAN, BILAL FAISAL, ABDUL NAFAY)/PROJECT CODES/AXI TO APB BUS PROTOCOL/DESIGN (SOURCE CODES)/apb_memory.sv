module apb_memory #(
    parameter ADDR_WIDTH = 32,
    parameter DATA_WIDTH = 32,
    parameter DEPTH      = 256
)(
    input  logic                  PCLK,
    input  logic                  PRESETn,

    input  logic [ADDR_WIDTH-1:0] PADDR,
    input  logic [DATA_WIDTH-1:0] PWDATA,
    output logic [DATA_WIDTH-1:0] PRDATA,

    input  logic                  PWRITE,
    input  logic                  PSEL,
    input  logic                  PENABLE,

    output logic                  PREADY,
    output logic                  PSLVERR
);


    //==================================================
    // MEMORY
    //==================================================

    logic [DATA_WIDTH-1:0] memory [0:DEPTH-1];


    //==================================================
    // ADDRESS INDEX
    //==================================================

    logic [$clog2(DEPTH)-1:0] mem_index;

    always_comb begin

        mem_index = PADDR >> 2;

    end


    //==================================================
    // APB READY / ERROR
    //==================================================

    always_comb begin

        PREADY  = 1'b1;
        PSLVERR = 1'b0;

    end


    //==================================================
    // APB READ DATA
    //==================================================

    always_comb begin

        PRDATA = '0;

        if (PSEL && !PWRITE) begin

            if (mem_index < DEPTH)
                PRDATA = memory[mem_index];

        end

    end


    //==================================================
    // APB WRITE
    //==================================================

    always_ff @(posedge PCLK or negedge PRESETn) begin

        if (!PRESETn) begin

            for (int i = 0; i < DEPTH; i = i + 1) begin

                memory[i] <= '0;

            end

        end

        else begin

            if (PSEL && PENABLE && PWRITE) begin

                if (mem_index < DEPTH) begin

                    memory[mem_index] <= PWDATA;

                    $display(
                        "APB MEMORY: WRITE ADDR=%h DATA=%h",
                        PADDR,
                        PWDATA
                    );

                end

            end

        end

    end


    //==================================================
    // DEBUG READ
    //==================================================

    always @(posedge PCLK) begin

        if (PSEL && PENABLE && !PWRITE) begin

            $display(
                "APB MEMORY: READ ADDR=%h INDEX=%0d DATA=%h",
                PADDR,
                mem_index,
                memory[mem_index]
            );

        end

    end

endmodule