module readback_bridge #(
    parameter DATA_WIDTH = 32
)(
    // ------------------------------------------------
    // PCLK DOMAIN
    // ------------------------------------------------

    input  logic PCLK,
    input  logic PRESETn,

    input  logic read_data_valid,
    input  logic [DATA_WIDTH-1:0] read_data,
    output logic read_data_ready,

    // ------------------------------------------------
    // ACLK DOMAIN
    // ------------------------------------------------

    input  logic ACLK,
    input  logic ARESETn,

    output logic axi_read_valid,
    output logic [DATA_WIDTH-1:0] axi_read_data,
    output logic [1:0] axi_read_resp,
    input  logic axi_read_ready
);

    logic fifo_full;
    logic fifo_empty;

    logic fifo_write_en;
    logic fifo_read_en;

    logic [DATA_WIDTH-1:0] fifo_read_data;

    typedef enum logic [1:0] {
        ACLK_IDLE,
        ACLK_READ,
        ACLK_HOLD
    } read_state_t;

    read_state_t read_state;


    // ------------------------------------------------
    // PCLK SIDE
    // ------------------------------------------------

    assign read_data_ready = !fifo_full;

    assign fifo_write_en =
        read_data_valid && read_data_ready;


    // ------------------------------------------------
    // ACLK SIDE - FIFO READ CONTROL
    // ------------------------------------------------

    always_comb begin

        fifo_read_en = 1'b0;

        if (read_state == ACLK_READ)
            fifo_read_en = 1'b1;

    end


    // ------------------------------------------------
    // ACLK CONTROL
    // ------------------------------------------------

    always_ff @(posedge ACLK or negedge ARESETn) begin

        if (!ARESETn) begin

            read_state     <= ACLK_IDLE;
            axi_read_valid <= 1'b0;
            axi_read_data  <= '0;
            axi_read_resp  <= 2'b00;

        end
        else begin

            case (read_state)

                // ------------------------------------
                // WAIT FOR DATA
                // ------------------------------------

                ACLK_IDLE: begin

                    axi_read_valid <= 1'b0;

                    if (!fifo_empty)
                        read_state <= ACLK_READ;

                end


                // ------------------------------------
                // READ FROM FIFO
                // ------------------------------------

                ACLK_READ: begin

                    // FIFO updates read_data on this
                    // clock edge.
                    read_state <= ACLK_HOLD;

                end


                // ------------------------------------
                // PRESENT DATA TO AXI SIDE
                // ------------------------------------

                ACLK_HOLD: begin

                    axi_read_data  <= fifo_read_data;
                    axi_read_resp  <= 2'b00;
                    axi_read_valid <= 1'b1;

                    // Do NOT clear valid here.
                    // Wait for the next clock.
                    if (axi_read_valid && axi_read_ready) begin

                        axi_read_valid <= 1'b0;
                        read_state <= ACLK_IDLE;

                    end

                end


                default: begin

                    read_state <= ACLK_IDLE;
                    axi_read_valid <= 1'b0;

                end

            endcase

        end

    end


    // ------------------------------------------------
    // READBACK ASYNC FIFO
    // PCLK → ACLK
    // ------------------------------------------------

    async_fifo #(
        .DATA_WIDTH(DATA_WIDTH),
        .DEPTH(8)
    ) readback_fifo (

        .wclk       (PCLK),
        .wrst_n     (PRESETn),

        .write_en   (fifo_write_en),
        .write_data (read_data),
        .full       (fifo_full),

        .rclk       (ACLK),
        .rrst_n     (ARESETn),

        .read_en    (fifo_read_en),
        .read_data  (fifo_read_data),
        .empty      (fifo_empty)

    );

endmodule