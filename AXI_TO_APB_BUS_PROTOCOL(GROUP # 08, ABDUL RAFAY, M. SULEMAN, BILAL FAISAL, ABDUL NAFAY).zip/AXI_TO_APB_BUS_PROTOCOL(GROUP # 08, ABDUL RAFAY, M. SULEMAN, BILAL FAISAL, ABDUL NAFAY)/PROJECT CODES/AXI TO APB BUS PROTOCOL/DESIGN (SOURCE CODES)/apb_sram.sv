module apb_sram #(
    parameter ADDR_WIDTH = 32,
    parameter DATA_WIDTH = 32,
    parameter DEPTH = 256
)(
    input logic                  PCLK,
    input logic                  PRESETn,

    input logic [ADDR_WIDTH-1:0] PADDR,
    input logic [DATA_WIDTH-1:0] PWDATA,
    output logic [DATA_WIDTH-1:0] PRDATA,

    input logic                  PWRITE,
    input logic                  PSEL,
    input logic                  PENABLE,

    output logic                 PREADY,
    output logic                 PSLVERR
);

    logic [DATA_WIDTH-1:0] memory [0:DEPTH-1];

    integer i;

    always_ff @(posedge PCLK or negedge PRESETn) begin

        if (!PRESETn) begin

            PRDATA  <= '0;
            PREADY  <= 1'b0;
            PSLVERR <= 1'b0;

            for (i = 0; i < DEPTH; i = i + 1)
                memory[i] <= '0;

        end
        else begin

            PREADY  <= 1'b0;
            PSLVERR <= 1'b0;

            if (PSEL && PENABLE) begin

                PREADY <= 1'b1;

                if (PWRITE) begin
                    memory[PADDR[9:2]] <= PWDATA;
                end
                else begin
                    PRDATA <= memory[PADDR[9:2]];
                end

            end
        end
    end

endmodule