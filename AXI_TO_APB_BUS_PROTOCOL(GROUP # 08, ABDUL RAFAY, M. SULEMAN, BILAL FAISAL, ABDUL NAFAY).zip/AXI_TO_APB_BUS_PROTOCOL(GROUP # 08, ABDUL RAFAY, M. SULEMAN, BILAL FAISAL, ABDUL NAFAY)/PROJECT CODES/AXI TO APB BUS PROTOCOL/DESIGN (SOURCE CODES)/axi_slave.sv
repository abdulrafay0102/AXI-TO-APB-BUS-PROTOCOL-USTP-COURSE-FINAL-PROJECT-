module axi_slave #(
    parameter ADDR_WIDTH = 32,
    parameter DATA_WIDTH = 32,
    parameter DEPTH      = 256
)(
    axi_if axi
);

    logic [DATA_WIDTH-1:0] memory [0:DEPTH-1];

    logic [ADDR_WIDTH-1:0] write_addr;
    logic write_addr_received;

    integer i;

    // READY signals
    always_comb begin
        if (axi.ARESETn) begin
            axi.AWREADY = 1'b1;
            axi.WREADY  = 1'b1;
            axi.ARREADY = 1'b1;
        end
        else begin
            axi.AWREADY = 1'b0;
            axi.WREADY  = 1'b0;
            axi.ARREADY = 1'b0;
        end
    end


    // AXI slave operation
    always_ff @(posedge axi.ACLK or negedge axi.ARESETn) begin

        if (!axi.ARESETn) begin

            axi.BVALID <= 1'b0;
            axi.BRESP  <= 2'b00;

            axi.RVALID <= 1'b0;
            axi.RDATA  <= '0;
            axi.RRESP  <= 2'b00;

            write_addr <= '0;
            write_addr_received <= 1'b0;

            for (i = 0; i < DEPTH; i = i + 1)
                memory[i] <= '0;

        end

        else begin

            // -----------------------------
            // WRITE ADDRESS
            // -----------------------------

            if (axi.AWVALID && axi.AWREADY) begin

                write_addr <= axi.AWADDR;
                write_addr_received <= 1'b1;

            end


            // -----------------------------
            // WRITE DATA
            // -----------------------------

            if (axi.WVALID && axi.WREADY &&
                write_addr_received) begin

                memory[write_addr[9:2]] <= axi.WDATA;

                write_addr_received <= 1'b0;

                axi.BVALID <= 1'b1;
                axi.BRESP  <= 2'b00;

            end


            // -----------------------------
            // WRITE RESPONSE
            // -----------------------------

            if (axi.BVALID && axi.BREADY) begin
                axi.BVALID <= 1'b0;
            end


            // -----------------------------
            // READ ADDRESS
            // -----------------------------

            if (axi.ARVALID && axi.ARREADY) begin

                axi.RDATA <= memory[axi.ARADDR[9:2]];
                axi.RRESP <= 2'b00;
                axi.RVALID <= 1'b1;

            end


            // -----------------------------
            // READ DATA
            // -----------------------------

            if (axi.RVALID && axi.RREADY) begin
                axi.RVALID <= 1'b0;
            end

        end
    end

endmodule