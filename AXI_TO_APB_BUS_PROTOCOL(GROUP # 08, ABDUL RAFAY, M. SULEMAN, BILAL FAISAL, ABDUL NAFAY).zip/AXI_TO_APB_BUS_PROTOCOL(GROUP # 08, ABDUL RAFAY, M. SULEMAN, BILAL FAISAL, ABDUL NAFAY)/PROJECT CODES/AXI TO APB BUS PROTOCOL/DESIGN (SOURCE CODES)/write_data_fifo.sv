module write_data_fifo #(
    parameter DATA_WIDTH = 32,
    parameter DEPTH = 8
)(
    input  logic                  clk,
    input  logic                  resetn,

    // WRITE SIDE
    input  logic                  write_en,
    input  logic [DATA_WIDTH-1:0] write_data,

    // READ SIDE
    input  logic                  read_en,
    output logic [DATA_WIDTH-1:0] read_data,

    // STATUS
    output logic                  full,
    output logic                  empty,
    output logic [$clog2(DEPTH+1)-1:0] count
);

    // FIFO memory
    logic [DATA_WIDTH-1:0] memory [0:DEPTH-1];

    // Read and write pointers
    logic [$clog2(DEPTH)-1:0] write_ptr;
    logic [$clog2(DEPTH)-1:0] read_ptr;

    integer i;

    // FIFO status
    assign empty = (count == 0);
    assign full  = (count == DEPTH);

    // Current data at read pointer
    assign read_data = memory[read_ptr];

    // FIFO operation
    always_ff @(posedge clk or negedge resetn) begin

        if (!resetn) begin

            write_ptr <= '0;
            read_ptr  <= '0;
            count     <= '0;

            for (i = 0; i < DEPTH; i = i + 1)
                memory[i] <= '0;

        end else begin

            // Write data into FIFO
            if (write_en && !full) begin

                memory[write_ptr] <= write_data;

                if (write_ptr == DEPTH-1)
                    write_ptr <= '0;
                else
                    write_ptr <= write_ptr + 1'b1;

            end

            // Read data from FIFO
            if (read_en && !empty) begin

                if (read_ptr == DEPTH-1)
                    read_ptr <= '0;
                else
                    read_ptr <= read_ptr + 1'b1;

            end

            // Update FIFO count
            case ({
                write_en && !full,
                read_en && !empty
            })

                2'b10:
                    count <= count + 1'b1;

                2'b01:
                    count <= count - 1'b1;

                default:
                    count <= count;

            endcase

        end
    end

endmodule