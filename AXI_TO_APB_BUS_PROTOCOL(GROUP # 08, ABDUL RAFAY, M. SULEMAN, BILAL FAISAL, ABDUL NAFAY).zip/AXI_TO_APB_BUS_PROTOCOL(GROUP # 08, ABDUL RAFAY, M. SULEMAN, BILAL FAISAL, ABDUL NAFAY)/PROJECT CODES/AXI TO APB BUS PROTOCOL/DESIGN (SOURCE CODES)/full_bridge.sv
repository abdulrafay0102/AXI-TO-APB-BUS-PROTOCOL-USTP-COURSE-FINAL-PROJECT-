module full_bridge #(
    parameter ADDR_WIDTH = 32,
    parameter DATA_WIDTH = 32
)(
    axi_if axi,

    input logic PCLK,
    input logic PRESETn,

    output logic [ADDR_WIDTH-1:0] APB_ADDR,
    output logic [DATA_WIDTH-1:0] APB_WDATA,
    output logic APB_WRITE,
    output logic APB_SEL,
    output logic APB_ENABLE,

    input logic [DATA_WIDTH-1:0] APB_RDATA,
    input logic APB_READY,
    input logic APB_ERROR,

    output logic transaction_done
);

    logic read_resp_valid;
    logic [DATA_WIDTH-1:0] read_resp_data;

    logic write_resp_valid;
    logic write_resp_error;


    //==================================================
    // BRIDGE CONTROL
    //==================================================

    bridge_control_integration #(
        .ADDR_WIDTH(ADDR_WIDTH),
        .DATA_WIDTH(DATA_WIDTH)
    ) bridge_control (
        .axi(axi),

        .PCLK(PCLK),
        .PRESETn(PRESETn),

        .PADDR(APB_ADDR),
        .PWDATA(APB_WDATA),
        .PWRITE(APB_WRITE),
        .PSEL(APB_SEL),
        .PENABLE(APB_ENABLE),

        .PRDATA(APB_RDATA),
        .PREADY(APB_READY),
        .PSLVERR(APB_ERROR),

        .busy(),
        .transaction_done(transaction_done),

        .read_resp_valid(read_resp_valid),
        .read_resp_data(read_resp_data),

        .write_resp_valid(write_resp_valid),
        .write_resp_error(write_resp_error)
    );


    //==================================================
    // READ RESPONSE BRIDGE
    // PCLK → ACLK
    //==================================================

    readback_bridge #(
        .DATA_WIDTH(DATA_WIDTH)
    ) readback_bridge_inst (

        .PCLK(PCLK),
        .PRESETn(PRESETn),

        .read_data_valid(read_resp_valid),
        .read_data(read_resp_data),
        .read_data_ready(),

        .ACLK(axi.ACLK),
        .ARESETn(axi.ARESETn),

        .axi_read_valid(axi.RVALID),
        .axi_read_data(axi.RDATA),
      	.axi_read_resp(axi.RRESP),
        .axi_read_ready(axi.RREADY)
    );


    //==================================================
    // WRITE RESPONSE BRIDGE
    // PCLK → ACLK
    //==================================================

    write_response_bridge #(
        .DATA_WIDTH(2)
    ) write_response_bridge_inst (

        .PCLK(PCLK),
        .PRESETn(PRESETn),

        .write_resp_valid(write_resp_valid),
        .write_resp_error(write_resp_error),

        .ACLK(axi.ACLK),
        .ARESETn(axi.ARESETn),

        .axi_write_valid(axi.BVALID),
        .axi_write_resp(axi.BRESP),
        .axi_write_ready(axi.BREADY)
    );

endmodule