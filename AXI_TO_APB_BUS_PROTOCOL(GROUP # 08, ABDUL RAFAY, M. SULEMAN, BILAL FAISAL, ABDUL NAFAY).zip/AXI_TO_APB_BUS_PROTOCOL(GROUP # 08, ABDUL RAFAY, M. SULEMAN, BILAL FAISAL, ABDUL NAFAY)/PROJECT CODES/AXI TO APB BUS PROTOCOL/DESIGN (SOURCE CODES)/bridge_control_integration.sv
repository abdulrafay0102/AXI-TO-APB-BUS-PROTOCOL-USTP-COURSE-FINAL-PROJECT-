module bridge_control_integration #(
    parameter ADDR_WIDTH = 32,
    parameter DATA_WIDTH = 32
)(
    axi_if axi,

    input logic PCLK,
    input logic PRESETn,

    output logic [ADDR_WIDTH-1:0] PADDR,
    output logic [DATA_WIDTH-1:0] PWDATA,
    output logic PWRITE,
    output logic PSEL,
    output logic PENABLE,

    input logic [DATA_WIDTH-1:0] PRDATA,
    input logic PREADY,
    input logic PSLVERR,

    output logic busy,
    output logic transaction_done,

    output logic read_resp_valid,
    output logic [DATA_WIDTH-1:0] read_resp_data,

    output logic write_resp_valid,
    output logic write_resp_error
);


    //==================================================
    // AXI REQUEST BRIDGE SIGNALS
    //==================================================

    logic req_valid;
    logic [ADDR_WIDTH-1:0] req_addr;
    logic req_is_write;
    logic req_ready;


    axi_request_bridge #(
        .ADDR_WIDTH(ADDR_WIDTH)
    ) request_bridge (

        .axi(axi),

        .PCLK(PCLK),
        .PRESETn(PRESETn),

        .req_valid(req_valid),
        .req_addr(req_addr),
        .req_is_write(req_is_write),

        .req_ready(req_ready)

    );


    //==================================================
    // AXI WRITE DATA BRIDGE SIGNALS
    //==================================================

    logic wdata_valid;
    logic [DATA_WIDTH-1:0] wdata;
    logic wdata_ready;


    axi_write_data_bridge #(
        .DATA_WIDTH(DATA_WIDTH)
    ) write_data_bridge (

        .axi(axi),

        .PCLK(PCLK),
        .PRESETn(PRESETn),

        .wdata_valid(wdata_valid),
        .wdata(wdata),

        .wdata_ready(wdata_ready)

    );


    //==================================================
    // APB MASTER SIGNALS
    //==================================================

    logic apb_req_valid;
    logic apb_req_write;

    logic [ADDR_WIDTH-1:0] apb_req_addr;
    logic [DATA_WIDTH-1:0] apb_req_wdata;

    logic apb_req_ready;

    logic apb_resp_valid;
    logic [DATA_WIDTH-1:0] apb_resp_rdata;
    logic apb_resp_error;


    //==================================================
    // APB MASTER FSM
    //==================================================

    apb_master_fsm #(
        .ADDR_WIDTH(ADDR_WIDTH),
        .DATA_WIDTH(DATA_WIDTH)
    ) apb_master (

        .PCLK(PCLK),
        .PRESETn(PRESETn),

        .req_valid(apb_req_valid),
        .req_write(apb_req_write),

        .req_addr(apb_req_addr),
        .req_wdata(apb_req_wdata),

        .req_ready(apb_req_ready),

        .resp_valid(apb_resp_valid),
        .resp_rdata(apb_resp_rdata),
        .resp_error(apb_resp_error),

        .PADDR(PADDR),
        .PWDATA(PWDATA),
        .PWRITE(PWRITE),
        .PSEL(PSEL),
        .PENABLE(PENABLE),

        .PRDATA(PRDATA),
        .PREADY(PREADY),
        .PSLVERR(PSLVERR)

    );


    //==================================================
    // CONTROL FSM
    //==================================================

    typedef enum logic [2:0] {

        CTRL_IDLE,
        CTRL_WRITE_WAIT,
        CTRL_READ_START,
        CTRL_WRITE_START,
        CTRL_WAIT_RESPONSE

    } ctrl_state_t;


    ctrl_state_t ctrl_state;


    //==================================================
    // TRANSACTION REGISTERS
    //==================================================

    logic [ADDR_WIDTH-1:0] addr_reg;
    logic [DATA_WIDTH-1:0] wdata_reg;
    logic write_reg;


    //==================================================
    // CONTROL OUTPUTS
    //==================================================

    always_comb begin

        // Default values
        req_ready     = 1'b0;
        wdata_ready   = 1'b0;

        apb_req_valid = 1'b0;

        apb_req_write = write_reg;
        apb_req_addr  = addr_reg;
        apb_req_wdata = wdata_reg;

        busy = 1'b0;


        //================================================
        // IDLE
        //================================================

        if (ctrl_state == CTRL_IDLE) begin

            // READ REQUEST
            if (req_valid && !req_is_write) begin

                req_ready = 1'b1;

            end

            // WRITE REQUEST WITH DATA ALREADY AVAILABLE
            else if (req_valid &&
                     req_is_write &&
                     wdata_valid) begin

                req_ready   = 1'b1;
                wdata_ready = 1'b1;

            end

        end


        //================================================
        // WAITING FOR WRITE DATA
        //================================================

        if (ctrl_state == CTRL_WRITE_WAIT) begin

            busy = 1'b1;

            if (wdata_valid) begin

                // Accept write data
                wdata_ready = 1'b1;

                // IMPORTANT:
                // The write REQUEST is also consumed here.
                req_ready = 1'b1;

            end

        end


        //================================================
        // START APB TRANSACTION
        //================================================

        if ((ctrl_state == CTRL_READ_START) ||
            (ctrl_state == CTRL_WRITE_START)) begin

            busy = 1'b1;

            if (apb_req_ready) begin

                apb_req_valid = 1'b1;

            end

        end


        //================================================
        // WAIT FOR APB RESPONSE
        //================================================

        if (ctrl_state == CTRL_WAIT_RESPONSE) begin

            busy = 1'b1;

        end

    end


    //==================================================
    // CONTROL FSM
    //==================================================

    always_ff @(posedge PCLK or negedge PRESETn) begin

        if (!PRESETn) begin

            ctrl_state <= CTRL_IDLE;

            addr_reg   <= '0;
            wdata_reg  <= '0;
            write_reg  <= 1'b0;

            transaction_done <= 1'b0;

            read_resp_valid <= 1'b0;
            read_resp_data  <= '0;

            write_resp_valid <= 1'b0;
            write_resp_error <= 1'b0;

        end

        else begin

            // One-cycle status pulses
            transaction_done <= 1'b0;
            read_resp_valid  <= 1'b0;
            write_resp_valid <= 1'b0;


            case (ctrl_state)


                //================================================
                // IDLE
                //================================================

                CTRL_IDLE: begin

                    if (req_valid) begin

                        //========================================
                        // WRITE REQUEST
                        //========================================

                        if (req_is_write) begin

                            addr_reg  <= req_addr;
                            write_reg <= 1'b1;


                            // Write data already available
                            if (wdata_valid) begin

                                wdata_reg <= wdata;

                                ctrl_state <= CTRL_WRITE_START;

                            end


                            // Wait for write data
                            else begin

                                ctrl_state <= CTRL_WRITE_WAIT;

                            end

                        end


                        //========================================
                        // READ REQUEST
                        //========================================

                        else begin

                            addr_reg  <= req_addr;
                            write_reg <= 1'b0;

                            ctrl_state <= CTRL_READ_START;

                        end

                    end

                end


                //================================================
                // WAIT FOR WRITE DATA
                //================================================

                CTRL_WRITE_WAIT: begin

                    if (wdata_valid) begin

                        wdata_reg <= wdata;

                        // Request and write data are now both
                        // available, so start APB write.
                        ctrl_state <= CTRL_WRITE_START;


                        $display(
                            "BRIDGE CONTROL: Write data received = %h",
                            wdata
                        );

                    end

                end


                //================================================
                // START APB READ
                //================================================

                CTRL_READ_START: begin

                    if (apb_req_ready) begin

                        $display(
                            "BRIDGE CONTROL: Starting APB READ, ADDR=%h",
                            addr_reg
                        );

                        ctrl_state <= CTRL_WAIT_RESPONSE;

                    end

                end


                //================================================
                // START APB WRITE
                //================================================

                CTRL_WRITE_START: begin

                    if (apb_req_ready) begin

                        $display(
                            "BRIDGE CONTROL: Starting APB WRITE, ADDR=%h DATA=%h",
                            addr_reg,
                            wdata_reg
                        );

                        ctrl_state <= CTRL_WAIT_RESPONSE;

                    end

                end


                //================================================
                // WAIT FOR APB RESPONSE
                //================================================

                CTRL_WAIT_RESPONSE: begin

                    if (apb_resp_valid) begin

                        transaction_done <= 1'b1;


                        //========================================
                        // READ RESPONSE
                        //========================================

                        if (!write_reg) begin

                            read_resp_data  <= apb_resp_rdata;
                            read_resp_valid <= 1'b1;

                        end


                        //========================================
                        // WRITE RESPONSE
                        //========================================

                        else begin

                            write_resp_valid <= 1'b1;
                            write_resp_error <= apb_resp_error;

                        end


                        //========================================
                        // TRANSACTION COMPLETE
                        //========================================

                        ctrl_state <= CTRL_IDLE;

                    end

                end


                //================================================
                // DEFAULT
                //================================================

                default: begin

                    ctrl_state <= CTRL_IDLE;

                end

            endcase

        end

    end


    //==================================================
    // DEBUG MONITOR
    //==================================================

    always @(posedge PCLK) begin

        if (req_valid) begin

            $display(
                "BRIDGE CONTROL: Request received. WRITE=%b ADDR=%h READY=%b",
                req_is_write,
                req_addr,
                req_ready
            );

        end


        if (apb_resp_valid) begin

            $display(
                "BRIDGE CONTROL: APB RESPONSE received. RDATA=%h ERROR=%b",
                apb_resp_rdata,
                apb_resp_error
            );

        end

    end

endmodule