module bridge_control #(
    parameter ADDR_WIDTH = 32,
    parameter DATA_WIDTH = 32
)(
    input logic PCLK,
    input logic PRESETn,

    //==================================================
    // REQUEST FIFO
    //==================================================

    input  logic                  req_fifo_empty,
    output logic                  req_fifo_read_en,

    input logic [ADDR_WIDTH-1:0]  req_addr,
    input logic                  req_is_write,

    //==================================================
    // WRITE DATA FIFO
    //==================================================

    input logic                  wdata_fifo_empty,
    output logic                  wdata_fifo_read_en,

    input logic [DATA_WIDTH-1:0]  wdata_fifo_data,

    //==================================================
    // READBACK FIFO
    //==================================================

    input logic                  readback_fifo_full,
    output logic                 readback_fifo_write_en,

    output logic [DATA_WIDTH-1:0] readback_fifo_data,

    //==================================================
    // APB MASTER REQUEST
    //==================================================

    output logic                  apb_req_valid,
    output logic                  apb_req_write,

    output logic [ADDR_WIDTH-1:0] apb_req_addr,
    output logic [DATA_WIDTH-1:0] apb_req_wdata,

    input logic                   apb_req_ready,

    //==================================================
    // APB MASTER RESPONSE
    //==================================================

    input logic                   apb_resp_valid,
    input logic [DATA_WIDTH-1:0]  apb_resp_rdata,
    input logic                   apb_resp_error,

    //==================================================
    // STATUS
    //==================================================

    output logic                  busy
);


    //==================================================
    // FSM STATES
    //==================================================

    typedef enum logic [3:0] {
        IDLE,
        GET_REQUEST,
        GET_WRITE_DATA,
        START_APB,
        WAIT_APB,
        STORE_READBACK
    } state_t;

    state_t state;


    //==================================================
    // INTERNAL REQUEST REGISTERS
    //==================================================

    logic [ADDR_WIDTH-1:0] req_addr_reg;
    logic                  req_write_reg;

    logic [DATA_WIDTH-1:0] wdata_reg;


    //==================================================
    // NEXT STATE
    //==================================================

    state_t next_state;


    //==================================================
    // COMBINATIONAL CONTROL
    //==================================================

    always_comb begin

        // Default outputs
        req_fifo_read_en       = 1'b0;
        wdata_fifo_read_en     = 1'b0;

        readback_fifo_write_en = 1'b0;
        readback_fifo_data     = apb_resp_rdata;

        apb_req_valid          = 1'b0;
        apb_req_write          = req_write_reg;
        apb_req_addr           = req_addr_reg;
        apb_req_wdata          = wdata_reg;

        next_state             = state;


        case (state)

            //================================================
            // IDLE
            //================================================

            IDLE: begin

                if (!req_fifo_empty)
                    next_state = GET_REQUEST;

            end


            //================================================
            // GET REQUEST
            //================================================

            GET_REQUEST: begin

                // Consume one request
                req_fifo_read_en = 1'b1;

                if (req_is_write)
                    next_state = GET_WRITE_DATA;
                else
                    next_state = START_APB;

            end


            //================================================
            // GET WRITE DATA
            //================================================

            GET_WRITE_DATA: begin

                // Consume corresponding write data
                wdata_fifo_read_en = 1'b1;

                next_state = START_APB;

            end


            //================================================
            // START APB
            //================================================

            START_APB: begin

                apb_req_valid = 1'b1;

                if (apb_req_ready)
                    next_state = WAIT_APB;

            end


            //================================================
            // WAIT FOR APB RESPONSE
            //================================================

            WAIT_APB: begin

                if (apb_resp_valid) begin

                    if (req_write_reg) begin

                        // Write transaction complete
                        next_state = IDLE;

                    end
                    else begin

                        // Read transaction needs readback FIFO
                        next_state = STORE_READBACK;

                    end

                end

            end


            //================================================
            // STORE APB READ DATA
            //================================================

            STORE_READBACK: begin

                if (!readback_fifo_full) begin

                    readback_fifo_write_en = 1'b1;

                    next_state = IDLE;

                end

            end


            //================================================
            // DEFAULT
            //================================================

            default: begin

                next_state = IDLE;

            end

        endcase

    end


    //==================================================
    // SEQUENTIAL LOGIC
    //==================================================

    always_ff @(posedge PCLK or negedge PRESETn) begin

        if (!PRESETn) begin

            state        <= IDLE;

            req_addr_reg <= '0;
            req_write_reg <= 1'b0;

            wdata_reg    <= '0;

        end

        else begin

            state <= next_state;


            //================================================
            // Capture request FIFO information
            //================================================

            if (state == GET_REQUEST) begin

                req_addr_reg  <= req_addr;
                req_write_reg <= req_is_write;

            end


            //================================================
            // Capture write data
            //================================================

            if (state == GET_WRITE_DATA) begin

                wdata_reg <= wdata_fifo_data;

            end

        end

    end


    //==================================================
    // BUSY SIGNAL
    //==================================================

    always_comb begin

        if ((state != IDLE) || !req_fifo_empty)
            busy = 1'b1;
        else
            busy = 1'b0;

    end

endmodule