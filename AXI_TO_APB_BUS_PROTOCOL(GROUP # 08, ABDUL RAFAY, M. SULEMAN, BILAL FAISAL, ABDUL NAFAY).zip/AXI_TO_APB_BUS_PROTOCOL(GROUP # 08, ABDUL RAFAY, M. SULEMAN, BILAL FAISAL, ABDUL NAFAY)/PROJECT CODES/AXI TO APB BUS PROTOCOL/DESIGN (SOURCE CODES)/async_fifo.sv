module async_fifo #(
    parameter DATA_WIDTH = 32,
    parameter DEPTH      = 8
)(
    //==================================================
    // WRITE CLOCK DOMAIN
    //==================================================
    input  logic                  wclk,
    input  logic                  wrst_n,

    input  logic                  write_en,
    input  logic [DATA_WIDTH-1:0] write_data,

    output logic                  full,

    //==================================================
    // READ CLOCK DOMAIN
    //==================================================
    input  logic                  rclk,
    input  logic                  rrst_n,

    input  logic                  read_en,
    output logic [DATA_WIDTH-1:0] read_data,

    output logic                  empty
);

    localparam ADDR_WIDTH = $clog2(DEPTH);

    //==================================================
    // FIFO MEMORY
    //==================================================

    logic [DATA_WIDTH-1:0] memory [0:DEPTH-1];

    //==================================================
    // POINTERS
    //==================================================

    logic [ADDR_WIDTH:0] write_ptr;
    logic [ADDR_WIDTH:0] read_ptr;

    //==================================================
    // SYNCHRONIZED POINTERS
    //==================================================

    logic [ADDR_WIDTH:0] read_ptr_sync1;
    logic [ADDR_WIDTH:0] read_ptr_sync2;

    logic [ADDR_WIDTH:0] write_ptr_sync1;
    logic [ADDR_WIDTH:0] write_ptr_sync2;

    //==================================================
    // WRITE POINTER SYNCHRONIZATION
    // PCLK -> ACLK
    //==================================================

    always_ff @(posedge wclk or negedge wrst_n) begin

        if (!wrst_n) begin

            read_ptr_sync1 <= '0;
            read_ptr_sync2 <= '0;

        end
        else begin

            read_ptr_sync1 <= read_ptr;
            read_ptr_sync2 <= read_ptr_sync1;

        end

    end

    //==================================================
    // READ POINTER SYNCHRONIZATION
    // ACLK -> PCLK
    //==================================================

    always_ff @(posedge rclk or negedge rrst_n) begin

        if (!rrst_n) begin

            write_ptr_sync1 <= '0;
            write_ptr_sync2 <= '0;

        end
        else begin

            write_ptr_sync1 <= write_ptr;
            write_ptr_sync2 <= write_ptr_sync1;

        end

    end

    //==================================================
    // WRITE OPERATION
    //==================================================

    always_ff @(posedge wclk or negedge wrst_n) begin

        if (!wrst_n) begin

            write_ptr <= '0;

        end
        else begin

            if (write_en && !full) begin

                memory[write_ptr[ADDR_WIDTH-1:0]]
                    <= write_data;

                write_ptr <= write_ptr + 1'b1;

            end

        end

    end

    //==================================================
    // READ OPERATION
    //==================================================

    always_ff @(posedge rclk or negedge rrst_n) begin

        if (!rrst_n) begin

            read_ptr  <= '0;
            read_data <= '0;

        end
        else begin

            if (read_en && !empty) begin

                read_data <=
                    memory[read_ptr[ADDR_WIDTH-1:0]];

                read_ptr <= read_ptr + 1'b1;

            end

        end

    end

    //==================================================
    // EMPTY FLAG
    //==================================================

    always_comb begin

        empty = (read_ptr == write_ptr_sync2);

    end

    //==================================================
    // FULL FLAG
    //==================================================

    always_comb begin

        full = ((write_ptr[ADDR_WIDTH-1:0] ==
                 read_ptr_sync2[ADDR_WIDTH-1:0]) &&
                (write_ptr[ADDR_WIDTH] !=
                 read_ptr_sync2[ADDR_WIDTH]));

    end

endmodule