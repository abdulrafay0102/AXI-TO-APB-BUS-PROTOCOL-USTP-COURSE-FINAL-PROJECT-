module axi_master #(
    parameter ADDR_WIDTH = 32,
    parameter DATA_WIDTH = 32
)(
    axi_if axi
);

    // --------------------------------
    // WRITE TASK
    // --------------------------------

    task automatic axi_write(
        input logic [ADDR_WIDTH-1:0] address,
        input logic [DATA_WIDTH-1:0] data
    );

        // Write address
        @(posedge axi.ACLK);

        axi.AWADDR = address;
        axi.AWVALID = 1'b1;

        wait (axi.AWREADY);

        @(posedge axi.ACLK);

        axi.AWVALID = 1'b0;


        // Write data
        axi.WDATA = data;
        axi.WSTRB = 4'b1111;
        axi.WVALID = 1'b1;

        wait (axi.WREADY);

        @(posedge axi.ACLK);

        axi.WVALID = 1'b0;


        // Write response
        axi.BREADY = 1'b1;

        wait (axi.BVALID);

        @(posedge axi.ACLK);

        axi.BREADY = 1'b0;

        $display("------------------------------------");
        $display("AXI WRITE COMPLETED");
        $display("Address = %h", address);
        $display("Data    = %h", data);
        $display("------------------------------------");

    endtask


    // --------------------------------
    // READ TASK
    // --------------------------------

    task automatic axi_read(
        input  logic [ADDR_WIDTH-1:0] address,
        output logic [DATA_WIDTH-1:0] data
    );

        // Read address
        @(posedge axi.ACLK);

        axi.ARADDR = address;
        axi.ARVALID = 1'b1;

        wait (axi.ARREADY);

        @(posedge axi.ACLK);

        axi.ARVALID = 1'b0;


        // Read data
        axi.RREADY = 1'b1;

        wait (axi.RVALID);

        data = axi.RDATA;

        @(posedge axi.ACLK);

        axi.RREADY = 1'b0;

        $display("------------------------------------");
        $display("AXI READ COMPLETED");
        $display("Address = %h", address);
        $display("Data    = %h", data);
        $display("------------------------------------");

    endtask

endmodule