module apb_master #(
    parameter ADDR_WIDTH = 32,
    parameter DATA_WIDTH = 32
)(
    input logic PCLK,
    input logic PRESETn,

    input logic                   start,
    input logic                   write,
    input logic [ADDR_WIDTH-1:0]  addr,
    input logic [DATA_WIDTH-1:0]  wdata,

    output logic [DATA_WIDTH-1:0] rdata,
    output logic                  done,
    output logic                  error,

    output logic [ADDR_WIDTH-1:0] PADDR,
    output logic [DATA_WIDTH-1:0] PWDATA,
    input  logic [DATA_WIDTH-1:0] PRDATA,

    output logic PWRITE,
    output logic PSEL,
    output logic PENABLE,

    input logic PREADY,
    input logic PSLVERR
);

    typedef enum logic [1:0] {
        IDLE,
        SETUP,
        ACCESS
    } state_t;

    state_t state;

    always_ff @(posedge PCLK or negedge PRESETn) begin

        if (!PRESETn) begin

            state   <= IDLE;

            PADDR   <= '0;
            PWDATA  <= '0;
            PWRITE  <= 1'b0;
            PSEL    <= 1'b0;
            PENABLE <= 1'b0;

            rdata   <= '0;
            done    <= 1'b0;
            error   <= 1'b0;

        end
        else begin

            done  <= 1'b0;
            error <= 1'b0;

            case (state)

                IDLE: begin

                    PSEL    <= 1'b0;
                    PENABLE <= 1'b0;

                    if (start) begin

                        PADDR  <= addr;
                        PWDATA <= wdata;
                        PWRITE <= write;

                        state <= SETUP;

                    end

                end

                SETUP: begin

                    PSEL    <= 1'b1;
                    PENABLE <= 1'b0;

                    state <= ACCESS;

                end

                ACCESS: begin

                    PSEL    <= 1'b1;
                    PENABLE <= 1'b1;

                    if (PREADY) begin

                        if (!PWRITE)
                            rdata <= PRDATA;

                        error <= PSLVERR;
                        done  <= 1'b1;

                        PSEL    <= 1'b0;
                        PENABLE <= 1'b0;

                        state <= IDLE;

                    end

                end

                default: begin
                    state <= IDLE;
                end

            endcase
        end
    end

endmodule