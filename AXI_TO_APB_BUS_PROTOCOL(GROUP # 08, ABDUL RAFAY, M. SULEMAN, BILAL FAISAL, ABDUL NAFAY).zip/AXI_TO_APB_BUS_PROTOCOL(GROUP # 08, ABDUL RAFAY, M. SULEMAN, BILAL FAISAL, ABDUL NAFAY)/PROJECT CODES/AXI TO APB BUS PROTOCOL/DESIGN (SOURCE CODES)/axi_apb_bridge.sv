module axi_apb_bridge #(
    parameter ADDR_WIDTH = 32,
    parameter DATA_WIDTH = 32
)(
    axi_if axi,
    apb_if apb
);

    typedef enum logic [2:0] {
        IDLE,
        WRITE_SETUP,
        WRITE_ACCESS,
        WRITE_RESPONSE,
        READ_SETUP,
        READ_ACCESS,
        READ_RESPONSE
    } state_t;

    state_t state;

    logic [ADDR_WIDTH-1:0] addr_reg;
    logic [DATA_WIDTH-1:0] wdata_reg;

    logic aw_received;
    logic w_received;

    //==================================================
    // AXI READY
    //==================================================
    always_comb begin

        axi.AWREADY = 1'b0;
        axi.WREADY  = 1'b0;
        axi.ARREADY = 1'b0;

        if (axi.ARESETn && state == IDLE) begin

            if (!aw_received)
                axi.AWREADY = 1'b1;

            if (!w_received)
                axi.WREADY = 1'b1;

            // Read can be accepted only when no write
            // transaction is being collected.
            if (!aw_received && !w_received)
                axi.ARREADY = 1'b1;

        end
    end

    //==================================================
    // APB OUTPUTS
    //==================================================
    always_comb begin

        apb.PADDR   = addr_reg;
        apb.PWDATA  = wdata_reg;
        apb.PWRITE  = 1'b0;
        apb.PSEL    = 1'b0;
        apb.PENABLE = 1'b0;

        case (state)

            WRITE_SETUP: begin
                apb.PSEL   = 1'b1;
                apb.PWRITE = 1'b1;
            end

            WRITE_ACCESS: begin
                apb.PSEL    = 1'b1;
                apb.PENABLE = 1'b1;
                apb.PWRITE  = 1'b1;
            end

            READ_SETUP: begin
                apb.PSEL   = 1'b1;
                apb.PWRITE = 1'b0;
            end

            READ_ACCESS: begin
                apb.PSEL    = 1'b1;
                apb.PENABLE = 1'b1;
                apb.PWRITE  = 1'b0;
            end

            default: begin
                apb.PSEL    = 1'b0;
                apb.PENABLE = 1'b0;
                apb.PWRITE  = 1'b0;
            end

        endcase
    end

    //==================================================
    // AXI RESPONSES
    //==================================================
    always_comb begin

        axi.BVALID = 1'b0;
        axi.BRESP  = 2'b00;

        axi.RVALID = 1'b0;
        axi.RRESP  = 2'b00;
        axi.RDATA  = apb.PRDATA;

        if (state == WRITE_RESPONSE) begin
            axi.BVALID = 1'b1;

            if (apb.PSLVERR)
                axi.BRESP = 2'b10;
            else
                axi.BRESP = 2'b00;
        end

        if (state == READ_RESPONSE) begin
            axi.RVALID = 1'b1;

            if (apb.PSLVERR)
                axi.RRESP = 2'b10;
            else
                axi.RRESP = 2'b00;
        end

    end

    //==================================================
    // MAIN FSM
    //==================================================
    always_ff @(posedge axi.ACLK or negedge axi.ARESETn) begin

        if (!axi.ARESETn) begin

            state       <= IDLE;
            addr_reg    <= '0;
            wdata_reg   <= '0;

            aw_received <= 1'b0;
            w_received  <= 1'b0;

        end

        else begin

            case (state)

                //======================================
                // IDLE
                //======================================
                IDLE: begin

                    // Capture write address
                    if (axi.AWVALID && axi.AWREADY) begin
                        addr_reg    <= axi.AWADDR;
                        aw_received <= 1'b1;
                    end

                    // Capture write data
                    if (axi.WVALID && axi.WREADY) begin
                        wdata_reg  <= axi.WDATA;
                        w_received <= 1'b1;
                    end

                    // Start WRITE when both are available
                    if ((aw_received || (axi.AWVALID && axi.AWREADY)) &&
                        (w_received  || (axi.WVALID  && axi.WREADY))) begin

                        state <= WRITE_SETUP;
                    end

                    // Start READ
                    else if (axi.ARVALID && axi.ARREADY) begin

                        addr_reg <= axi.ARADDR;
                        state    <= READ_SETUP;
                    end

                end

                //======================================
                // WRITE SETUP
                //======================================
                WRITE_SETUP: begin
                    state <= WRITE_ACCESS;
                end

                //======================================
                // WRITE ACCESS
                //======================================
                WRITE_ACCESS: begin

                    if (apb.PREADY)
                        state <= WRITE_RESPONSE;

                end

                //======================================
                // WRITE RESPONSE
                //======================================
                WRITE_RESPONSE: begin

                    if (axi.BREADY) begin

                        aw_received <= 1'b0;
                        w_received  <= 1'b0;

                        state <= IDLE;
                    end

                end

                //======================================
                // READ SETUP
                //======================================
                READ_SETUP: begin
                    state <= READ_ACCESS;
                end

                //======================================
                // READ ACCESS
                //======================================
                READ_ACCESS: begin

                    if (apb.PREADY)
                        state <= READ_RESPONSE;

                end

                //======================================
                // READ RESPONSE
                //======================================
                READ_RESPONSE: begin

                    if (axi.RREADY) begin
                        state <= IDLE;
                    end

                end

                default: begin
                    state <= IDLE;
                end

            endcase

        end

    end

endmodule
