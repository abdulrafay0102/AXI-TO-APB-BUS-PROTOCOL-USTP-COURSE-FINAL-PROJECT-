module request_fifo #(
    parameter ADDR_WIDTH = 32,
    parameter DEPTH = 8
)(
    input  logic clk,
    input  logic resetn,

    //==================================================
    // WRITE SIDE
    //==================================================

    input  logic                  write_en,
    input  logic [ADDR_WIDTH-1:0] write_addr,
    input  logic                  write_is_write,

    //==================================================
    // READ SIDE
    //==================================================

    input  logic                  read_en,
    output logic [ADDR_WIDTH-1:0] read_addr,
    output logic                  read_is_write,

    //==================================================
    // STATUS
    //==================================================

    output logic full,
    output logic empty,

    output logic [$clog2(DEPTH+1)-1:0] count
);


    //==================================================
    // REQUEST MEMORY
    //==================================================

    logic [ADDR_WIDTH:0] memory [0:DEPTH-1];


    //==================================================
    // POINTERS
    //==================================================

    logic [$clog2(DEPTH)-1:0] write_ptr;
    logic [$clog2(DEPTH)-1:0] read_ptr;

    integer i;


    //==================================================
    // FIFO STATUS
    //==================================================

    assign empty = (count == 0);
    assign full  = (count == DEPTH);


    //==================================================
    // REQUEST OUTPUT
    //==================================================

    assign read_addr    = memory[read_ptr][ADDR_WIDTH-1:0];
    assign read_is_write = memory[read_ptr][ADDR_WIDTH];


    //==================================================
    // FIFO OPERATION
    //==================================================

    always_ff @(posedge clk or negedge resetn) begin

        if (!resetn) begin

            write_ptr <= '0;
            read_ptr  <= '0;
            count     <= '0;

            for (i = 0; i < DEPTH; i = i + 1)
                memory[i] <= '0;

        end

        else begin

            // -----------------------------------------
            // WRITE REQUEST
            // -----------------------------------------

            if (write_en && !full) begin

                memory[write_ptr] <= {
                    write_is_write,
                    write_addr
                };

                if (write_ptr == DEPTH-1)
                    write_ptr <= '0;
                else
                    write_ptr <= write_ptr + 1'b1;

            end


            // -----------------------------------------
            // READ REQUEST
            // -----------------------------------------

            if (read_en && !empty) begin

                if (read_ptr == DEPTH-1)
                    read_ptr <= '0;
                else
                    read_ptr <= read_ptr + 1'b1;

            end


            // -----------------------------------------
            // COUNT
            // -----------------------------------------

            case ({
                write_en && !full,
                read_en && !empty
            })

                2'b10:
                    count <= count + 1'b1;

                2'b01:
                    count <= count - 1'b1;

                default:
                    count <= count;

            endcase

        end

    end

endmodule
