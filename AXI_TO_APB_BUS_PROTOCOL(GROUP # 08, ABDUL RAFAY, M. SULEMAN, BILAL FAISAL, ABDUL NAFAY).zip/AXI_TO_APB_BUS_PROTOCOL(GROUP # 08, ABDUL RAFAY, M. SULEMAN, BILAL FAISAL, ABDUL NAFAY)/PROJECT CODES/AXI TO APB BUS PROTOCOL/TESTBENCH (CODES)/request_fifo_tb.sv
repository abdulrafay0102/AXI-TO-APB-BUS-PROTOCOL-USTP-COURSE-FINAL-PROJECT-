
module request_fifo_tb;

    parameter ADDR_WIDTH = 32;
    parameter DEPTH = 8;

    logic clk;
    logic resetn;

    logic write_en;
    logic read_en;

    logic [ADDR_WIDTH-1:0] write_addr;
    logic write_is_write;

    logic [ADDR_WIDTH-1:0] read_addr;
    logic read_is_write;

    logic full;
    logic empty;

    logic [$clog2(DEPTH+1)-1:0] count;

    logic test_pass;


    //==================================================
    // REQUEST FIFO DUT
    //==================================================

    request_fifo #(
        .ADDR_WIDTH(ADDR_WIDTH),
        .DEPTH(DEPTH)
    ) dut (

        .clk(clk),
        .resetn(resetn),

        .write_en(write_en),
        .write_addr(write_addr),
        .write_is_write(write_is_write),

        .read_en(read_en),
        .read_addr(read_addr),
        .read_is_write(read_is_write),

        .full(full),
        .empty(empty),

        .count(count)
    );


    //==================================================
    // CLOCK
    //==================================================

    initial begin
        clk = 1'b0;
        forever #5 clk = ~clk;
    end


    //==================================================
    // WAVEFORM
    //==================================================

    initial begin
        $dumpfile("dump.vcd");
        $dumpvars(0, request_fifo_tb);
    end


    //==================================================
    // TEST
    //==================================================

    initial begin

        resetn        = 1'b0;
        write_en      = 1'b0;
        read_en       = 1'b0;
        write_addr    = '0;
        write_is_write = 1'b0;

        test_pass = 1'b1;


        //================================================
        // RESET
        //================================================

        #20;

        resetn = 1'b1;

        @(negedge clk);


        //================================================
        // TEST 1: EMPTY
        //================================================

        $display("");
        $display("========================================");
        $display("TEST 1: REQUEST FIFO EMPTY");
        $display("========================================");

        if (empty && count == 0) begin
            $display("Request FIFO is EMPTY.");
        end
        else begin
            $display("ERROR: Request FIFO should be EMPTY!");
            test_pass = 1'b0;
        end


        //================================================
        // TEST 2: WRITE REQUESTS
        //================================================

        $display("");
        $display("========================================");
        $display("TEST 2: WRITE REQUESTS");
        $display("========================================");

        write_en = 1'b1;

        // WRITE request
        write_addr = 32'h00000010;
        write_is_write = 1'b1;

        @(negedge clk);

        // READ request
        write_addr = 32'h00000020;
        write_is_write = 1'b0;

        @(negedge clk);

        // WRITE request
        write_addr = 32'h00000030;
        write_is_write = 1'b1;

        @(negedge clk);

        write_en = 1'b0;

        #1;

        $display("Request FIFO COUNT = %0d", count);

        if (count == 3) begin
            $display("Three requests stored successfully.");
        end
        else begin
            $display("ERROR: Expected COUNT = 3!");
            test_pass = 1'b0;
        end


        //================================================
        // TEST 3: READ REQUEST 1
        //================================================

        $display("");
        $display("========================================");
        $display("TEST 3: READ REQUEST 1");
        $display("========================================");

        read_en = 1'b1;

        #1;

        if ((read_addr == 32'h00000010) &&
            (read_is_write == 1'b1)) begin

            $display("Address = %h", read_addr);
            $display("Operation = WRITE");
            $display("Request 1 PASSED.");

        end
        else begin

            $display("ERROR: Request 1 incorrect!");
            test_pass = 1'b0;

        end


        // Consume request 1
        @(posedge clk);
        #1;


        //================================================
        // TEST 4: READ REQUEST 2
        //================================================

        if ((read_addr == 32'h00000020) &&
            (read_is_write == 1'b0)) begin

            $display("Address = %h", read_addr);
            $display("Operation = READ");
            $display("Request 2 PASSED.");

        end
        else begin

            $display("ERROR: Request 2 incorrect!");
            test_pass = 1'b0;

        end


        // Consume request 2
        @(posedge clk);
        #1;


        //================================================
        // TEST 5: READ REQUEST 3
        //================================================

        if ((read_addr == 32'h00000030) &&
            (read_is_write == 1'b1)) begin

            $display("Address = %h", read_addr);
            $display("Operation = WRITE");
            $display("Request 3 PASSED.");

        end
        else begin

            $display("ERROR: Request 3 incorrect!");
            test_pass = 1'b0;

        end


        // Consume request 3
        @(posedge clk);
        #1;

        read_en = 1'b0;


        //================================================
        // TEST 6: EMPTY AFTER READ
        //================================================

        $display("");
        $display("========================================");
        $display("TEST 6: EMPTY AFTER READ");
        $display("========================================");

        if (empty && count == 0) begin
            $display("Request FIFO is EMPTY.");
        end
        else begin
            $display("ERROR: Request FIFO should be EMPTY!");
            test_pass = 1'b0;
        end


        //================================================
        // FINAL RESULT
        //================================================

        if (test_pass) begin

            $display("");
            $display("========================================");
            $display("     REQUEST FIFO TEST PASSED!");
            $display("========================================");

        end
        else begin

            $display("");
            $display("========================================");
            $display("     REQUEST FIFO TEST FAILED!");
            $display("========================================");

        end


        #20;

        $finish;

    end

endmodule
