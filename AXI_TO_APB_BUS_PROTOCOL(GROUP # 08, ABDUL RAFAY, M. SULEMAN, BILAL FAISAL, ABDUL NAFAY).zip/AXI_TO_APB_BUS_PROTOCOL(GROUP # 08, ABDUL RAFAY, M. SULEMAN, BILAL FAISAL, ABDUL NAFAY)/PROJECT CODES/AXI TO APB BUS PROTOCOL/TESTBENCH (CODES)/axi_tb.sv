module axi_tb;

    parameter ADDR_WIDTH = 32;
    parameter DATA_WIDTH = 32;

    logic ACLK;
    logic ARESETn;

    logic [DATA_WIDTH-1:0] read_data;

    // --------------------------------
    // AXI Interface
    // --------------------------------

    axi_if axi (
        .ACLK(ACLK),
        .ARESETn(ARESETn)
    );


    // --------------------------------
    // AXI Master
    // --------------------------------

    axi_master master (
        .axi(axi)
    );


    // --------------------------------
    // AXI Slave
    // --------------------------------

    axi_slave slave (
        .axi(axi)
    );


    // --------------------------------
    // Clock
    // --------------------------------

    initial begin

        ACLK = 1'b0;

        forever #5 ACLK = ~ACLK;

    end


    // --------------------------------
    // VCD Waveform
    // --------------------------------

    initial begin

        $dumpfile("dump.vcd");
        $dumpvars(0, axi_tb);

    end


    // --------------------------------
    // Test
    // --------------------------------

    initial begin

        // Initial values
        ARESETn = 1'b0;

        axi.AWADDR  = '0;
        axi.AWVALID = 1'b0;

        axi.WDATA   = '0;
        axi.WSTRB   = 4'b0000;
        axi.WVALID  = 1'b0;

        axi.BREADY  = 1'b0;

        axi.ARADDR  = '0;
        axi.ARVALID = 1'b0;

        axi.RREADY  = 1'b0;


        // Reset
        #20;

        ARESETn = 1'b1;


        // --------------------------------
        // AXI WRITE
        // --------------------------------

        master.axi_write(
            32'h00000010,
            32'hAABBCCDD
        );


        // --------------------------------
        // AXI READ
        // --------------------------------

        master.axi_read(
            32'h00000010,
            read_data
        );


        // --------------------------------
        // CHECK RESULT
        // --------------------------------

        if (read_data == 32'hAABBCCDD) begin

            $display("====================================");
            $display("        AXI TEST PASSED!");
            $display("====================================");

        end

        else begin

            $display("====================================");
            $display("        AXI TEST FAILED!");
            $display("====================================");

        end


        #20;

        $finish;

    end
    // --------------------------------
    // VCD Waveform
    // --------------------------------

    initial begin
        $dumpfile("dump.vcd");
        $dumpvars(0, axi_tb);
    end

endmodule