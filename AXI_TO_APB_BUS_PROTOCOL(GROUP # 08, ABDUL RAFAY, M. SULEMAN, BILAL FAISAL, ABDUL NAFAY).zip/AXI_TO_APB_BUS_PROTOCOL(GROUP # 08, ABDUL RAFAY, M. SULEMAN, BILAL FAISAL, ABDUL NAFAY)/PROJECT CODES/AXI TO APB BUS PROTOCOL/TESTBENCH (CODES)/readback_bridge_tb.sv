module readback_bridge_tb;

    // ------------------------------------------------
    // CLOCKS
    // ------------------------------------------------

    logic ACLK;
    logic PCLK;

    initial ACLK = 0;
    always #5 ACLK = ~ACLK;

    initial PCLK = 0;
    always #7 PCLK = ~PCLK;


    // ------------------------------------------------
    // RESETS
    // ------------------------------------------------

    logic ARESETn;
    logic PRESETn;

    // ------------------------------------------------
    // PCLK SIDE
    // ------------------------------------------------

    logic        read_data_valid;
    logic [31:0] read_data;
    logic        read_data_ready;

    // ------------------------------------------------
    // ACLK SIDE
    // ------------------------------------------------

    logic        axi_read_valid;
    logic [31:0] axi_read_data;
    logic        axi_read_ready;

    // ------------------------------------------------
    // DUT
    // ------------------------------------------------

    readback_bridge dut (

        .PCLK(PCLK),
        .PRESETn(PRESETn),

        .read_data_valid(read_data_valid),
        .read_data(read_data),
        .read_data_ready(read_data_ready),

        .ACLK(ACLK),
        .ARESETn(ARESETn),

        .axi_read_valid(axi_read_valid),
        .axi_read_data(axi_read_data),
        .axi_read_ready(axi_read_ready)

    );

    // ------------------------------------------------
    // SEND READ DATA
    // ------------------------------------------------

    task send_read_data(input logic [31:0] data);

        begin

            @(posedge PCLK);

            wait(read_data_ready);

            read_data <= data;
            read_data_valid <= 1'b1;

            @(posedge PCLK);

            read_data_valid <= 1'b0;

            $display("PCLK: Read data sent = %h", data);

        end

    endtask


    // ------------------------------------------------
    // TEST
    // ------------------------------------------------

    initial begin

        read_data_valid = 1'b0;
        read_data = '0;

        axi_read_ready = 1'b1;

        ARESETn = 1'b0;
        PRESETn = 1'b0;

        #30;

        ARESETn = 1'b1;
        PRESETn = 1'b1;

        #30;

        $display("");
        $display("========================================");
        $display("       READBACK FIFO TEST");
        $display("========================================");

        // --------------------------------------------
        // TEST 1
        // --------------------------------------------

        $display("");
        $display("TEST 1: READ DATA");

        send_read_data(32'hCAFEBABE);

        wait(axi_read_valid);

        $display("ACLK: Read data received = %h",
                 axi_read_data);

        if (axi_read_data == 32'hCAFEBABE) begin

            $display("PASS: Read data transferred correctly.");

        end
        else begin

            $display("FAIL: Read data mismatch.");

        end

        @(posedge ACLK);

        // --------------------------------------------
        // TEST 2
        // --------------------------------------------

        $display("");
        $display("TEST 2: SECOND READ DATA");

        send_read_data(32'h11223344);

        wait(axi_read_valid);

        $display("ACLK: Read data received = %h",
                 axi_read_data);

        if (axi_read_data == 32'h11223344) begin

            $display("PASS: Second read data transferred correctly.");

        end
        else begin

            $display("FAIL: Second read data mismatch.");

        end

        @(posedge ACLK);

        // --------------------------------------------
        // TEST 3
        // --------------------------------------------

        $display("");
        $display("TEST 3: THIRD READ DATA");

        send_read_data(32'h55667788);

        wait(axi_read_valid);

        $display("ACLK: Read data received = %h",
                 axi_read_data);

        if (axi_read_data == 32'h55667788) begin

            $display("PASS: Third read data transferred correctly.");

        end
        else begin

            $display("FAIL: Third read data mismatch.");

        end

        // --------------------------------------------
        // COMPLETE
        // --------------------------------------------

        $display("");
        $display("========================================");
        $display(" READBACK FIFO TEST PASSED!");
        $display("========================================");

        #30;

        $finish;

    end

endmodule