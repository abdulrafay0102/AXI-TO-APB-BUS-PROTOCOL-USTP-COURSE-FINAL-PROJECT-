`ifndef AXI_TRANSACTION_SV
`define AXI_TRANSACTION_SV

class axi_transaction extends uvm_sequence_item;

    // ============================================================
    // TRANSACTION FIELDS
    // ============================================================

    rand bit [31:0] addr;
    rand bit [31:0] data;
    rand bit        is_write;
    rand bit        separate_aw_w;


    // ============================================================
    // ADDRESS CONSTRAINT
    // ============================================================

    constraint address_constraint {

        addr inside {
            32'h00000010,
            32'h00000020,
            32'h00000030,
            32'h00000040,
            32'h00000050,
            32'h00000060,
            32'h00000070,
            32'h00000080
        };

        addr[1:0] == 2'b00;
    }


    // ============================================================
    // READ / WRITE CONSTRAINT
    // ============================================================

    constraint operation_constraint {

        is_write dist {
            1 := 50,
            0 := 50
        };

    }


    // ============================================================
    // SEPARATE AW/W CONSTRAINT
    // ============================================================

    constraint separate_constraint {

        separate_aw_w dist {
            1 := 30,
            0 := 70
        };

    }


    // ============================================================
    // UVM FACTORY REGISTRATION
    // ============================================================

    `uvm_object_utils(axi_transaction)


    // ============================================================
    // CONSTRUCTOR
    // ============================================================

    function new(string name = "axi_transaction");

        super.new(name);

    endfunction


    // ============================================================
    // PRINT TRANSACTION
    // ============================================================

    function void do_print(uvm_printer printer);

        super.do_print(printer);

        printer.print_field_int(
            "addr",
            addr,
            32,
            UVM_HEX
        );

        printer.print_field_int(
            "data",
            data,
            32,
            UVM_HEX
        );

        printer.print_field_int(
            "is_write",
            is_write,
            1,
            UVM_BIN
        );

        printer.print_field_int(
            "separate_aw_w",
            separate_aw_w,
            1,
            UVM_BIN
        );

    endfunction

endclass

`endif