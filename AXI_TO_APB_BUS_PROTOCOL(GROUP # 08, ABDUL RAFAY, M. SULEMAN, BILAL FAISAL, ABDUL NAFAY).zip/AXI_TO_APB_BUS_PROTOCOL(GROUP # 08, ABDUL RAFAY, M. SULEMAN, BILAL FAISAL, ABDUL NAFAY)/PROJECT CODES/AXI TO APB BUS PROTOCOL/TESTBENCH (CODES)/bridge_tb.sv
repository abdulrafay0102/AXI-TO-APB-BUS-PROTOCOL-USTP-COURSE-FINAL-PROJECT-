module bridge_tb;

    parameter ADDR_WIDTH = 32;
    parameter DATA_WIDTH = 32;

    logic ACLK;
    logic PCLK;

    logic ARESETn;
    logic PRESETn;

    //==================================================
    // AXI INTERFACE
    //==================================================

    axi_if axi (
        .ACLK(ACLK),
        .ARESETn(ARESETn)
    );

    //==================================================
    // APB INTERFACE
    //==================================================

    apb_if apb (
        .PCLK(PCLK),
        .PRESETn(PRESETn)
    );

    //==================================================
    // AXI-APB BRIDGE
    //==================================================

    axi_apb_bridge bridge (
        .axi(axi),
        .apb(apb)
    );

    //==================================================
    // APB SRAM
    //==================================================

    apb_sram memory (

        .PCLK(PCLK),
        .PRESETn(PRESETn),

        .PADDR(apb.PADDR),
        .PWDATA(apb.PWDATA),
        .PRDATA(apb.PRDATA),

        .PWRITE(apb.PWRITE),
        .PSEL(apb.PSEL),
        .PENABLE(apb.PENABLE),

        .PREADY(apb.PREADY),
        .PSLVERR(apb.PSLVERR)
    );

    //==================================================
    // AXI CLOCK
    //==================================================

    initial begin
        ACLK = 1'b0;
        forever #5 ACLK = ~ACLK;
    end

    //==================================================
    // APB CLOCK
    //==================================================

    initial begin
        PCLK = 1'b0;
        forever #5 PCLK = ~PCLK;
    end

    //==================================================
    // WAVEFORM
    //==================================================

    initial begin
        $dumpfile("dump.vcd");
        $dumpvars(0, bridge_tb);
    end

    //==================================================
    // TEST
    //==================================================

    initial begin

        //================================================
        // INITIAL VALUES
        //================================================

        ARESETn = 1'b0;
        PRESETn = 1'b0;

        axi.AWADDR  = '0;
        axi.AWVALID = 1'b0;

        axi.WDATA   = '0;
        axi.WSTRB   = 4'b0000;
        axi.WVALID  = 1'b0;

        axi.BREADY  = 1'b0;

        axi.ARADDR  = '0;
        axi.ARVALID = 1'b0;

        axi.RREADY  = 1'b0;


        //================================================
        // RESET
        //================================================

        #20;

        ARESETn = 1'b1;
        PRESETn = 1'b1;

        @(negedge ACLK);


        //================================================
        // AXI WRITE
        //================================================

        $display("");
        $display("Starting AXI WRITE...");

        // -----------------------------------------------
        // Write Address
        // -----------------------------------------------

        axi.AWADDR  = 32'h00000010;
        axi.AWVALID = 1'b1;

        @(posedge ACLK);

        // Allow DUT to process handshake
        #1;

        axi.AWVALID = 1'b0;


        // -----------------------------------------------
        // Write Data
        // -----------------------------------------------

        @(negedge ACLK);

        axi.WDATA  = 32'hDEADBEEF;
        axi.WSTRB  = 4'b1111;
        axi.WVALID = 1'b1;

        @(posedge ACLK);

        #1;

        axi.WVALID = 1'b0;


        // -----------------------------------------------
        // Write Response
        // -----------------------------------------------

        @(negedge ACLK);

        axi.BREADY = 1'b1;

        wait (axi.BVALID == 1'b1);

        @(posedge ACLK);

        #1;

        axi.BREADY = 1'b0;


        $display("----------------------------------------");
        $display("AXI -> APB WRITE COMPLETED");
        $display("Address = %h", 32'h00000010);
        $display("Data    = %h", 32'hDEADBEEF);
        $display("----------------------------------------");


        //================================================
        // WAIT FOR BRIDGE TO RETURN TO IDLE
        //================================================

        @(negedge ACLK);


        //================================================
        // AXI READ
        //================================================

        $display("");
        $display("Starting AXI READ...");

        axi.ARADDR  = 32'h00000010;
        axi.ARVALID = 1'b1;

        // Wait for read address acceptance
        wait (axi.ARREADY == 1'b1);

        @(posedge ACLK);

        #1;

        axi.ARVALID = 1'b0;


        // -----------------------------------------------
        // Read Response
        // -----------------------------------------------

        @(negedge ACLK);

        axi.RREADY = 1'b1;

        wait (axi.RVALID == 1'b1);

        @(posedge ACLK);

        #1;

        axi.RREADY = 1'b0;


        $display("----------------------------------------");
        $display("AXI -> APB READ COMPLETED");
        $display("Address = %h", 32'h00000010);
        $display("Data    = %h", axi.RDATA);
        $display("----------------------------------------");


        //================================================
        // CHECK RESULT
        //================================================

        if (axi.RDATA == 32'hDEADBEEF) begin

            $display("");
            $display("========================================");
            $display("      AXI-APB BRIDGE TEST PASSED!");
            $display("========================================");
            $display("");

        end

        else begin

            $display("");
            $display("========================================");
            $display("      AXI-APB BRIDGE TEST FAILED!");
            $display("========================================");
            $display("");

        end


        #20;

        $finish;

    end

endmodule