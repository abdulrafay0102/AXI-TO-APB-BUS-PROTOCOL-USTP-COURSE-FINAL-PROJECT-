class axi_sequence extends uvm_sequence #(axi_transaction);

    `uvm_object_utils(axi_sequence)


    // ============================================================
    // CONSTRUCTOR
    // ============================================================

    function new(string name = "axi_sequence");

        super.new(name);

    endfunction


    // ============================================================
    // BODY
    // ============================================================

    virtual task body();

        axi_transaction tr;


        // --------------------------------------------------------
        // Generate 20 randomized transactions
        // --------------------------------------------------------

        repeat (20) begin

            tr = axi_transaction::type_id::create("tr");


            // ----------------------------------------------------
            // Start transaction
            // ----------------------------------------------------

            start_item(tr);


            // ----------------------------------------------------
            // Randomize
            // ----------------------------------------------------

            if (!tr.randomize()) begin

                `uvm_error(
                    "RANDFAIL",
                    "AXI transaction randomization failed."
                )

            end


            // ----------------------------------------------------
            // Finish transaction
            // ----------------------------------------------------

            finish_item(tr);


            // ----------------------------------------------------
            // Display transaction
            // ----------------------------------------------------

            `uvm_info(
                "AXI_SEQ",
                $sformatf(
                    "Generated transaction: WRITE=%0b ADDR=%08h DATA=%08h SEPARATE_AW_W=%0b",
                    tr.is_write,
                    tr.addr,
                    tr.data,
                    tr.separate_aw_w
                ),
                UVM_MEDIUM
            )

        end

    endtask

endclass