module apb_tb;

    logic PCLK;
    logic PRESETn;

    logic                   start;
    logic                   write;
    logic [31:0]            addr;
    logic [31:0]            wdata;

    logic [31:0]            rdata;
    logic                   done;
    logic                   error;

    logic [31:0]            PADDR;
    logic [31:0]            PWDATA;
    logic [31:0]            PRDATA;

    logic PWRITE;
    logic PSEL;
    logic PENABLE;

    logic PREADY;
    logic PSLVERR;


    // Clock generation
    initial begin
        PCLK = 0;
        forever #5 PCLK = ~PCLK;
    end


    // APB Master
    apb_master master (
        .PCLK(PCLK),
        .PRESETn(PRESETn),

        .start(start),
        .write(write),
        .addr(addr),
        .wdata(wdata),

        .rdata(rdata),
        .done(done),
        .error(error),

        .PADDR(PADDR),
        .PWDATA(PWDATA),
        .PRDATA(PRDATA),

        .PWRITE(PWRITE),
        .PSEL(PSEL),
        .PENABLE(PENABLE),

        .PREADY(PREADY),
        .PSLVERR(PSLVERR)
    );


    // APB SRAM
    apb_sram memory (
        .PCLK(PCLK),
        .PRESETn(PRESETn),

        .PADDR(PADDR),
        .PWDATA(PWDATA),
        .PRDATA(PRDATA),

        .PWRITE(PWRITE),
        .PSEL(PSEL),
        .PENABLE(PENABLE),

        .PREADY(PREADY),
        .PSLVERR(PSLVERR)
    );


    // Test
    initial begin

        start = 0;
        write = 0;
        addr  = 0;
        wdata = 0;

        PRESETn = 0;

        #20;
        PRESETn = 1;

        // -------------------------
        // WRITE TEST
        // -------------------------

        @(posedge PCLK);

        addr  = 32'h0000_0010;
        wdata = 32'h1234_5678;
        write = 1;
        start = 1;

        @(posedge PCLK);
        start = 0;

        wait(done);

        $display("------------------------------------");
        $display("APB WRITE COMPLETED");
        $display("Address = %h", addr);
        $display("Data    = %h", wdata);
        $display("------------------------------------");


        // -------------------------
        // READ TEST
        // -------------------------

        @(posedge PCLK);

        addr  = 32'h0000_0010;
        write = 0;
        start = 1;

        @(posedge PCLK);
        start = 0;

        wait(done);

        $display("------------------------------------");
        $display("APB READ COMPLETED");
        $display("Address = %h", addr);
        $display("Data    = %h", rdata);
        $display("------------------------------------");


        if (rdata == 32'h1234_5678)
            $display("TEST PASSED!");
        else
            $display("TEST FAILED!");

        #20;

        $finish;

    end
    initial begin
      $dumpfile("dump.vcd");
      $dumpvars(0, apb_tb);
  	end

endmodule