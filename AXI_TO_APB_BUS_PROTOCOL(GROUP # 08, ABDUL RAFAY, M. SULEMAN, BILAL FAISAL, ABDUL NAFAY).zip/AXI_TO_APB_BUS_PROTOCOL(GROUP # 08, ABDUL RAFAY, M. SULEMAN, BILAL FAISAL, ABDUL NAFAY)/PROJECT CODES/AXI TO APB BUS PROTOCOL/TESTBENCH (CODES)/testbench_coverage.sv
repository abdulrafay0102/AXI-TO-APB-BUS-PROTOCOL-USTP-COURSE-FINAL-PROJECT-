`timescale 1ns/1ns

module full_bridge_coverage_tb;

    // ============================================================
    // PARAMETERS
    // ============================================================

    parameter ADDR_WIDTH = 32;
    parameter DATA_WIDTH = 32;

    // ============================================================
    // CLOCKS AND RESETS
    // ============================================================

    logic ACLK;
    logic PCLK;

    logic ARESETn;
    logic PRESETn;

    // ============================================================
    // AXI INTERFACE
    // ============================================================

    axi_if #(
        .ADDR_WIDTH(ADDR_WIDTH),
        .DATA_WIDTH(DATA_WIDTH)
    ) axi (
        .ACLK   (ACLK),
        .ARESETn (ARESETn)
    );

    // ============================================================
    // APB SIGNALS
    // ============================================================

    logic [ADDR_WIDTH-1:0] APB_ADDR;
    logic [DATA_WIDTH-1:0] APB_WDATA;
    logic                  APB_WRITE;
    logic                  APB_SEL;
    logic                  APB_ENABLE;

    logic [DATA_WIDTH-1:0] APB_RDATA;
    logic                  APB_READY;
    logic                  APB_ERROR;

    logic transaction_done;

    // ============================================================
    // APB MEMORY MODEL
    // ============================================================

    logic [DATA_WIDTH-1:0] apb_memory [0:255];

    integer pass_count;
    integer fail_count;

    // ============================================================
    // BRIDGE DUT
    // ============================================================

    full_bridge #(
        .ADDR_WIDTH(ADDR_WIDTH),
        .DATA_WIDTH(DATA_WIDTH)
    ) dut (
        .axi(axi),

        .PCLK(PCLK),
        .PRESETn(PRESETn),

        .APB_ADDR(APB_ADDR),
        .APB_WDATA(APB_WDATA),
        .APB_WRITE(APB_WRITE),
        .APB_SEL(APB_SEL),
        .APB_ENABLE(APB_ENABLE),

        .APB_RDATA(APB_RDATA),
        .APB_READY(APB_READY),
        .APB_ERROR(APB_ERROR),

        .transaction_done(transaction_done)
    );

    // ============================================================
    // CLOCK GENERATION
    // ACLK = 10 ns
    // PCLK = 14 ns
    // ============================================================

    initial begin
        ACLK = 1'b0;
        forever #5 ACLK = ~ACLK;
    end

    initial begin
        PCLK = 1'b0;
        forever #7 PCLK = ~PCLK;
    end

    // ============================================================
    // APB MEMORY MODEL
    // ============================================================

    assign APB_READY = 1'b1;
    assign APB_ERROR = 1'b0;

    always_comb begin
        APB_RDATA = '0;

        if (APB_SEL && !APB_WRITE) begin
            if ((APB_ADDR >> 2) < 256)
                APB_RDATA = apb_memory[APB_ADDR >> 2];
        end
    end

    always_ff @(posedge PCLK or negedge PRESETn) begin
        if (!PRESETn) begin
            for (int j = 0; j < 256; j = j + 1) begin
                apb_memory[j] <= '0;
            end
        end
        else begin
            if (APB_SEL && APB_ENABLE && APB_WRITE) begin
                if ((APB_ADDR >> 2) < 256) begin
                    apb_memory[APB_ADDR >> 2] <= APB_WDATA;

                    $display(
                        "APB MEMORY: WRITE ADDR=%h DATA=%h",
                        APB_ADDR,
                        APB_WDATA
                    );
                end
            end
        end
    end

    // ============================================================
    // FUNCTIONAL COVERAGE VARIABLES
    // ============================================================

    logic coverage_is_write;
    logic [ADDR_WIDTH-1:0] coverage_addr;
    logic [DATA_WIDTH-1:0] coverage_data;
    logic aw_w_separated;

    // ============================================================
    // COVERGROUP
    // ============================================================

    covergroup axi_apb_coverage @(posedge ACLK);

        // --------------------------------------------------------
        // COVERPOINT 1: READ / WRITE OPERATION
        // --------------------------------------------------------

        cp_operation: coverpoint coverage_is_write {

            bins read_operation  = {0};
            bins write_operation = {1};

        }

        // --------------------------------------------------------
        // COVERPOINT 2: ADDRESS
        // --------------------------------------------------------

        cp_address: coverpoint coverage_addr {

            bins addr_10 = {32'h00000010};
            bins addr_20 = {32'h00000020};
            bins addr_30 = {32'h00000030};
            bins addr_40 = {32'h00000040};
            bins addr_50 = {32'h00000050};
            bins addr_60 = {32'h00000060};
            bins addr_70 = {32'h00000070};
            bins other_addresses = default;

        }

        // --------------------------------------------------------
        // COVERPOINT 3: DATA PATTERNS
        // --------------------------------------------------------

        cp_data: coverpoint coverage_data {

            bins zero_data = {32'h00000000};

            bins all_ones = {32'hFFFFFFFF};

            bins pattern_aa = {32'hAAAAAAAA};

            bins pattern_55 = {32'h55555555};

            bins pattern_dead = {32'hDEADBEEF};

            bins pattern_cafe = {32'hCAFEBABE};

            bins other_data = default;

        }

        // --------------------------------------------------------
        // COVERPOINT 4: SEPARATE AW AND W
        // --------------------------------------------------------

        cp_aw_w: coverpoint aw_w_separated {

            bins same_time = {0};
            bins separated = {1};

        }

        // --------------------------------------------------------
        // CROSS 1:
        // READ/WRITE × ADDRESS
        // --------------------------------------------------------

        operation_address_cross:
            cross cp_operation, cp_address;

        // --------------------------------------------------------
        // CROSS 2:
        // WRITE × DATA
        // --------------------------------------------------------

        write_data_cross:
            cross cp_operation, cp_data;

    endgroup

    // ============================================================
    // CREATE COVERAGE OBJECT
    // ============================================================

    axi_apb_coverage coverage_inst = new();

    // ============================================================
    // RESET TASK
    // ============================================================

    task reset_dut;

        begin

            axi.AWVALID = 1'b0;
            axi.AWADDR  = '0;

            axi.WVALID  = 1'b0;
            axi.WDATA   = '0;
            axi.WSTRB   = '1;

            axi.BREADY  = 1'b1;

            axi.ARVALID = 1'b0;
            axi.ARADDR  = '0;

            axi.RREADY  = 1'b1;

            ARESETn = 1'b0;
            PRESETn = 1'b0;

            repeat (5) @(posedge ACLK);

            ARESETn = 1'b1;
            PRESETn = 1'b1;

            repeat (3) @(posedge ACLK);

            $display("");
            $display("==============================================");
            $display("RESET COMPLETE");
            $display("==============================================");
            $display("");

        end

    endtask

    // ============================================================
    // AXI WRITE TASK
    // ============================================================

    task axi_write(
        input logic [ADDR_WIDTH-1:0] addr,
        input logic [DATA_WIDTH-1:0] data
    );

        begin

            $display("");
            $display("----------------------------------------------");
            $display("COVERAGE TEST: AXI WRITE");
            $display("Address = %h", addr);
            $display("Data    = %h", data);
            $display("----------------------------------------------");

            // Coverage information
            coverage_is_write = 1'b1;
            coverage_addr     = addr;
            coverage_data     = data;
            aw_w_separated    = 1'b0;

            // ----------------------------------------------------
            // AW CHANNEL
            // ----------------------------------------------------

            @(posedge ACLK);

            axi.AWADDR  <= addr;
            axi.AWVALID <= 1'b1;

            while (!axi.AWREADY)
                @(posedge ACLK);

            @(posedge ACLK);

            axi.AWVALID <= 1'b0;

            // ----------------------------------------------------
            // W CHANNEL
            // ----------------------------------------------------

            axi.WDATA  <= data;
            axi.WSTRB  <= '1;
            axi.WVALID <= 1'b1;

            while (!axi.WREADY)
                @(posedge ACLK);

            @(posedge ACLK);

            axi.WVALID <= 1'b0;

            // ----------------------------------------------------
            // WAIT FOR TRANSACTION COMPLETE
            // ----------------------------------------------------

            wait (transaction_done);

            repeat (2) @(posedge PCLK);

            if (apb_memory[addr >> 2] == data) begin

                pass_count = pass_count + 1;

                $display(
                    "PASS: Memory[%0d] = %h",
                    addr >> 2,
                    apb_memory[addr >> 2]
                );

            end
            else begin

                fail_count = fail_count + 1;

                $display(
                    "FAIL: Expected %h, Got %h",
                    data,
                    apb_memory[addr >> 2]
                );

            end

        end

    endtask

    // ============================================================
    // AXI WRITE TASK WITH SEPARATE AW / W
    // ============================================================

    task axi_write_separate(
        input logic [ADDR_WIDTH-1:0] addr,
        input logic [DATA_WIDTH-1:0] data,
        input integer delay_cycles
    );

        begin

            $display("");
            $display("----------------------------------------------");
            $display("COVERAGE TEST: SEPARATE AW / W");
            $display("Address = %h", addr);
            $display("Data    = %h", data);
            $display("Delay   = %0d ACLK cycles", delay_cycles);
            $display("----------------------------------------------");

            // Coverage information
            coverage_is_write = 1'b1;
            coverage_addr     = addr;
            coverage_data     = data;
            aw_w_separated    = 1'b1;

            // ----------------------------------------------------
            // AW CHANNEL
            // ----------------------------------------------------

            @(posedge ACLK);

            axi.AWADDR  <= addr;
            axi.AWVALID <= 1'b1;

            while (!axi.AWREADY)
                @(posedge ACLK);

            @(posedge ACLK);

            axi.AWVALID <= 1'b0;

            // ----------------------------------------------------
            // DELAY BETWEEN AW AND W
            // ----------------------------------------------------

            repeat (delay_cycles) @(posedge ACLK);

            // ----------------------------------------------------
            // W CHANNEL
            // ----------------------------------------------------

            axi.WDATA  <= data;
            axi.WSTRB  <= '1;
            axi.WVALID <= 1'b1;

            while (!axi.WREADY)
                @(posedge ACLK);

            @(posedge ACLK);

            axi.WVALID <= 1'b0;

            // ----------------------------------------------------
            // WAIT FOR TRANSACTION COMPLETE
            // ----------------------------------------------------

            wait (transaction_done);

            repeat (2) @(posedge PCLK);

            if (apb_memory[addr >> 2] == data) begin

                pass_count = pass_count + 1;

                $display(
                    "PASS: Separate AW/W transaction completed."
                );

            end
            else begin

                fail_count = fail_count + 1;

                $display(
                    "FAIL: Separate AW/W transaction failed."
                );

            end

        end

    endtask

    // ============================================================
    // AXI READ TASK
    // ============================================================

    task axi_read(
        input logic [ADDR_WIDTH-1:0] addr,
        input logic [DATA_WIDTH-1:0] expected_data
    );

        logic [DATA_WIDTH-1:0] received_data;

        begin

            $display("");
            $display("----------------------------------------------");
            $display("COVERAGE TEST: AXI READ");
            $display("Address  = %h", addr);
            $display("Expected = %h", expected_data);
            $display("----------------------------------------------");

            // Coverage information
            coverage_is_write = 1'b0;
            coverage_addr     = addr;
            coverage_data     = expected_data;
            aw_w_separated    = 1'b0;

            // ----------------------------------------------------
            // AR CHANNEL
            // ----------------------------------------------------

            @(posedge ACLK);

            axi.ARADDR  <= addr;
            axi.ARVALID <= 1'b1;

            while (!axi.ARREADY)
                @(posedge ACLK);

            @(posedge ACLK);

            axi.ARVALID <= 1'b0;

            // ----------------------------------------------------
            // WAIT FOR READ RESPONSE
            // ----------------------------------------------------

            wait (axi.RVALID);

            received_data = axi.RDATA;

            if (received_data == expected_data) begin

                pass_count = pass_count + 1;

                $display(
                    "PASS: AXI READ returned %h",
                    received_data
                );

            end
            else begin

                fail_count = fail_count + 1;

                $display(
                    "FAIL: AXI READ expected %h, got %h",
                    expected_data,
                    received_data
                );

            end

            @(posedge ACLK);

        end

    endtask

    // ============================================================
    // MAIN TEST
    // ============================================================

    initial begin

        pass_count = 0;
        fail_count = 0;

        reset_dut();

        $display("");
        $display("==============================================");
        $display("      STEP 3.4 FUNCTIONAL COVERAGE");
        $display("==============================================");
        $display("");

        // ========================================================
        // BASIC WRITE / READ
        // ========================================================

        axi_write(
            32'h00000010,
            32'hDEADBEEF
        );

        axi_read(
            32'h00000010,
            32'hDEADBEEF
        );

        // ========================================================
        // SECOND ADDRESS
        // ========================================================

        axi_write(
            32'h00000020,
            32'hCAFEBABE
        );

        axi_read(
            32'h00000020,
            32'hCAFEBABE
        );

        // ========================================================
        // ZERO DATA
        // ========================================================

        axi_write(
            32'h00000030,
            32'h00000000
        );

        axi_read(
            32'h00000030,
            32'h00000000
        );

        // ========================================================
        // ALL ONES
        // ========================================================

        axi_write(
            32'h00000040,
            32'hFFFFFFFF
        );

        axi_read(
            32'h00000040,
            32'hFFFFFFFF
        );

        // ========================================================
        // AA PATTERN
        // ========================================================

        axi_write(
            32'h00000050,
            32'hAAAAAAAA
        );

        axi_read(
            32'h00000050,
            32'hAAAAAAAA
        );

        // ========================================================
        // 55 PATTERN
        // ========================================================

        axi_write(
            32'h00000060,
            32'h55555555
        );

        axi_read(
            32'h00000060,
            32'h55555555
        );

        // ========================================================
        // SEPARATE AW / W
        // ========================================================

        axi_write_separate(
            32'h00000070,
            32'h12345678,
            3
        );

        axi_read(
            32'h00000070,
            32'h12345678
        );

        // ========================================================
        // ADDITIONAL ADDRESS / DATA COMBINATION
        // ========================================================

        axi_write(
            32'h00000080,
            32'h11223344
        );

        axi_read(
            32'h00000080,
            32'h11223344
        );

        // ========================================================
        // WAIT FOR COVERAGE TO UPDATE
        // ========================================================

        repeat (5) @(posedge ACLK);

        // ========================================================
        // DISPLAY RESULTS
        // ========================================================

        $display("");
        $display("==============================================");
        $display("       STEP 3.4 TEST SUMMARY");
        $display("==============================================");

        $display(
            "Total PASS = %0d",
            pass_count
        );

        $display(
            "Total FAIL = %0d",
            fail_count
        );

        $display(
            "Functional Coverage = %0.2f%%",
            coverage_inst.get_coverage()
        );

        $display("==============================================");

        if (fail_count == 0) begin

            $display("");
            $display(
                "STEP 3.4 FUNCTIONAL COVERAGE TEST PASSED!"
            );
            $display("");
            $display(
                "All functional tests completed successfully."
            );

        end
        else begin

            $display("");
            $display(
                "STEP 3.4 FUNCTIONAL COVERAGE TEST FAILED!"
            );
            $display("");
            $display(
                "Please check the failed transactions."
            );

        end

        $display("==============================================");
        $display("");

        $finish;

    end

    // ============================================================
    // VCD WAVEFORM
    // ============================================================

    initial begin

        $dumpfile("step3_4_coverage.vcd");
        $dumpvars(0, full_bridge_coverage_tb);

    end

endmodule
