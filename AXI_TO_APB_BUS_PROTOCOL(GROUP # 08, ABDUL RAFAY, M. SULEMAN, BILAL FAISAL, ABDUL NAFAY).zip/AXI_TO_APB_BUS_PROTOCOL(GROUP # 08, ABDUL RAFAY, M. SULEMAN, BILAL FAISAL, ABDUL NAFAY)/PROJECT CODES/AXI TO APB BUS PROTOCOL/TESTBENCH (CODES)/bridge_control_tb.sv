module bridge_control_tb;

    parameter ADDR_WIDTH = 32;
    parameter DATA_WIDTH = 32;
    parameter DEPTH = 8;

    logic PCLK;
    logic PRESETn;

    // =================================================
    // REQUEST FIFO SIGNALS
    // =================================================

    logic req_write_en;
    logic [ADDR_WIDTH-1:0] req_write_addr;
    logic req_write_is_write;

    logic req_read_en;

    logic [ADDR_WIDTH-1:0] req_read_addr;
    logic req_read_is_write;

    logic req_full;
    logic req_empty;

    logic [$clog2(DEPTH+1)-1:0] req_count;

    // =================================================
    // WRITE DATA FIFO SIGNALS
    // =================================================

    logic wdata_write_en;
    logic [DATA_WIDTH-1:0] wdata_write_data;

    logic wdata_read_en;
    logic [DATA_WIDTH-1:0] wdata_read_data;

    logic wdata_full;
    logic wdata_empty;

    logic [$clog2(DEPTH+1)-1:0] wdata_count;

    // =================================================
    // READBACK FIFO SIGNALS
    // =================================================

    logic readback_write_en;
    logic [DATA_WIDTH-1:0] readback_write_data;

    logic readback_read_en;
    logic [DATA_WIDTH-1:0] readback_read_data;

    logic readback_full;
    logic readback_empty;

    logic [$clog2(DEPTH+1)-1:0] readback_count;

    // =================================================
    // APB MASTER REQUEST
    // =================================================

    logic apb_req_valid;
    logic apb_req_write;

    logic [ADDR_WIDTH-1:0] apb_req_addr;
    logic [DATA_WIDTH-1:0] apb_req_wdata;

    logic apb_req_ready;

    // =================================================
    // APB MASTER RESPONSE
    // =================================================

    logic apb_resp_valid;
    logic [DATA_WIDTH-1:0] apb_resp_rdata;
    logic apb_resp_error;

    logic busy;

    // =================================================
    // APB SIGNALS
    // =================================================

    logic [ADDR_WIDTH-1:0] PADDR;
    logic [DATA_WIDTH-1:0] PWDATA;

    logic PWRITE;
    logic PSEL;
    logic PENABLE;

    logic [DATA_WIDTH-1:0] PRDATA;
    logic PREADY;
    logic PSLVERR;

    // =================================================
    // REQUEST FIFO
    // =================================================

    request_fifo #(
        .ADDR_WIDTH(ADDR_WIDTH),
        .DEPTH(DEPTH)
    ) request_fifo_inst (

        .clk(PCLK),
        .resetn(PRESETn),

        .write_en(req_write_en),
        .write_addr(req_write_addr),
        .write_is_write(req_write_is_write),

        .read_en(req_read_en),
        .read_addr(req_read_addr),
        .read_is_write(req_read_is_write),

        .full(req_full),
        .empty(req_empty),
        .count(req_count)
    );

    // =================================================
    // WRITE DATA FIFO
    // =================================================

    write_data_fifo #(
        .DATA_WIDTH(DATA_WIDTH),
        .DEPTH(DEPTH)
    ) write_data_fifo_inst (

        .clk(PCLK),
        .resetn(PRESETn),

        .write_en(wdata_write_en),
        .write_data(wdata_write_data),

        .read_en(wdata_read_en),
        .read_data(wdata_read_data),

        .full(wdata_full),
        .empty(wdata_empty),
        .count(wdata_count)
    );

    // =================================================
    // READBACK FIFO
    // =================================================

    readback_fifo #(
        .DATA_WIDTH(DATA_WIDTH),
        .DEPTH(DEPTH)
    ) readback_fifo_inst (

        .clk(PCLK),
        .resetn(PRESETn),

        .write_en(readback_write_en),
        .write_data(readback_write_data),

        .read_en(readback_read_en),
        .read_data(readback_read_data),

        .full(readback_full),
        .empty(readback_empty),
        .count(readback_count)
    );

    // =================================================
    // BRIDGE CONTROL
    // =================================================

    bridge_control #(
        .ADDR_WIDTH(ADDR_WIDTH),
        .DATA_WIDTH(DATA_WIDTH)
    ) bridge_control_inst (

        .PCLK(PCLK),
        .PRESETn(PRESETn),

        .req_fifo_empty(req_empty),
        .req_fifo_read_en(req_read_en),

        .req_addr(req_read_addr),
        .req_is_write(req_read_is_write),

        .wdata_fifo_empty(wdata_empty),
        .wdata_fifo_read_en(wdata_read_en),

        .wdata_fifo_data(wdata_read_data),

        .readback_fifo_full(readback_full),
        .readback_fifo_write_en(readback_write_en),

        .readback_fifo_data(readback_write_data),

        .apb_req_valid(apb_req_valid),
        .apb_req_write(apb_req_write),
        .apb_req_addr(apb_req_addr),
        .apb_req_wdata(apb_req_wdata),

        .apb_req_ready(apb_req_ready),

        .apb_resp_valid(apb_resp_valid),
        .apb_resp_rdata(apb_resp_rdata),
        .apb_resp_error(apb_resp_error),

        .busy(busy)
    );

    // =================================================
    // APB MASTER FSM
    // =================================================

    apb_master_fsm #(
        .ADDR_WIDTH(ADDR_WIDTH),
        .DATA_WIDTH(DATA_WIDTH)
    ) apb_master_inst (

        .PCLK(PCLK),
        .PRESETn(PRESETn),

        .req_valid(apb_req_valid),
        .req_write(apb_req_write),
        .req_addr(apb_req_addr),
        .req_wdata(apb_req_wdata),

        .req_ready(apb_req_ready),

        .resp_valid(apb_resp_valid),
        .resp_rdata(apb_resp_rdata),
        .resp_error(apb_resp_error),

        .PADDR(PADDR),
        .PWDATA(PWDATA),
        .PWRITE(PWRITE),
        .PSEL(PSEL),
        .PENABLE(PENABLE),

        .PRDATA(PRDATA),
        .PREADY(PREADY),
        .PSLVERR(PSLVERR)
    );

    // =================================================
    // CLOCK
    // =================================================

    initial begin

        PCLK = 1'b0;

        forever #5 PCLK = ~PCLK;

    end

    // =================================================
    // SIMPLE APB MEMORY
    // =================================================

    logic [DATA_WIDTH-1:0] memory [0:255];

    always_ff @(posedge PCLK or negedge PRESETn) begin

        if (!PRESETn) begin

            PREADY  <= 1'b0;
            PRDATA  <= '0;
            PSLVERR <= 1'b0;

        end
        else begin

            PREADY  <= 1'b0;
            PSLVERR <= 1'b0;

            if (PSEL && PENABLE) begin

                PREADY <= 1'b1;

                if (PWRITE) begin

                    memory[PADDR[9:2]] <= PWDATA;

                end
                else begin

                    PRDATA <= memory[PADDR[9:2]];

                end

            end

        end

    end

    // =================================================
    // WAVEFORM
    // =================================================

    initial begin

        $dumpfile("dump.vcd");
        $dumpvars(0, bridge_control_tb);

    end

    // =================================================
    // RESET
    // =================================================

    task reset_dut;

        begin

            PRESETn = 1'b0;

            req_write_en = 1'b0;
            req_write_addr = '0;
            req_write_is_write = 1'b0;

            wdata_write_en = 1'b0;
            wdata_write_data = '0;

            readback_read_en = 1'b0;

            #20;

            PRESETn = 1'b1;

            #10;

        end

    endtask

    // =================================================
    // WRITE REQUEST INTO FIFOS
    // =================================================

    task send_write_request(
        input logic [ADDR_WIDTH-1:0] address,
        input logic [DATA_WIDTH-1:0] data
    );

        begin

            @(negedge PCLK);

            req_write_addr     = address;
            req_write_is_write = 1'b1;
            req_write_en       = 1'b1;

            wdata_write_data   = data;
            wdata_write_en     = 1'b1;

            @(negedge PCLK);

            req_write_en       = 1'b0;
            wdata_write_en     = 1'b0;

        end

    endtask

    // =================================================
    // SEND READ REQUEST
    // =================================================

    task send_read_request(
        input logic [ADDR_WIDTH-1:0] address
    );

        begin

            @(negedge PCLK);

            req_write_addr     = address;
            req_write_is_write = 1'b0;
            req_write_en       = 1'b1;

            @(negedge PCLK);

            req_write_en       = 1'b0;

        end

    endtask

    // =================================================
    // MAIN TEST
    // =================================================

    initial begin

        $display("");
        $display("========================================");
        $display("      BRIDGE CONTROL TEST");
        $display("========================================");

        reset_dut();

        // ------------------------------------------------
        // TEST 1: WRITE
        // ------------------------------------------------

        $display("");
        $display("TEST 1: WRITE REQUEST");

        send_write_request(
            32'h00000010,
            32'hDEADBEEF
        );

        wait (!busy);

        $display("WRITE TRANSACTION COMPLETED");

        // ------------------------------------------------
        // TEST 2: READ
        // ------------------------------------------------

        $display("");
        $display("TEST 2: READ REQUEST");

        send_read_request(
            32'h00000010
        );

        wait (!busy);

        // Give FIFO time to contain read data
        #10;

        if (!readback_empty) begin

            // Data is already available at the FIFO output
            $display("Readback Data Before Pop = %h", readback_read_data);

            if (readback_read_data == 32'hDEADBEEF) begin
                $display("READ DATA CHECK PASSED");
            end
            else begin
                $display("READ DATA CHECK FAILED");
            end

            // Now remove the data from FIFO
            @(negedge PCLK);
            readback_read_en = 1'b1;

            @(negedge PCLK);
            readback_read_en = 1'b0;

        end
        else begin

            $display("ERROR: Readback FIFO is EMPTY");

        end

        // ------------------------------------------------
        // FINAL RESULT
        // ------------------------------------------------

        #20;

        $display("");
        $display("========================================");
        $display("    BRIDGE CONTROL TEST COMPLETED");
        $display("========================================");

        $finish;

    end

endmodule