`ifndef AXI_DRIVER_SV
`define AXI_DRIVER_SV

class axi_driver extends uvm_driver #(axi_transaction);

    `uvm_component_utils(axi_driver)

    virtual axi_if axi_vif;
    int completed_transactions = 0;

    // ============================================================
    // CONSTRUCTOR
    // ============================================================

    function new(
        string name = "axi_driver",
        uvm_component parent = null
    );

        super.new(name, parent);

    endfunction


    // ============================================================
    // BUILD PHASE
    // ============================================================

    virtual function void build_phase(
        uvm_phase phase
    );

        super.build_phase(phase);

        if (!uvm_config_db#(virtual axi_if)::get(
                this,
                "",
                "axi_vif",
                axi_vif
            )) begin

            `uvm_fatal(
                "NOVIF",
                "AXI virtual interface was not found."
            )

        end

    endfunction


    // ============================================================
    // RUN PHASE
    // ============================================================

    virtual task run_phase(
        uvm_phase phase
    );

        axi_transaction tr;

        // Initialize AXI outputs

        axi_vif.AWVALID = 1'b0;
        axi_vif.WVALID  = 1'b0;
        axi_vif.BREADY  = 1'b0;

        axi_vif.ARVALID = 1'b0;
        axi_vif.RREADY  = 1'b0;

        wait (axi_vif.ARESETn == 1'b1);


        forever begin

            seq_item_port.get_next_item(tr);

            `uvm_info(
                "AXI_DRV",
                $sformatf(
                    "Driving transaction: WRITE=%0b ADDR=%08h DATA=%08h SEPARATE_AW_W=%0b",
                    tr.is_write,
                    tr.addr,
                    tr.data,
                    tr.separate_aw_w
                ),
                UVM_MEDIUM
            )


            if (tr.is_write) begin

                drive_write(tr);

            end
            else begin

                drive_read(tr);

            end

            completed_transactions++;

            `uvm_info(
                "AXI_DRV",
                $sformatf(
                    "Transaction completed. Total completed = %0d",
                    completed_transactions
                ),
                UVM_LOW
            )

            seq_item_port.item_done();

        end

    endtask


    // ============================================================
    // WRITE TASK
    // ============================================================

    virtual task drive_write(
        axi_transaction tr
    );


        // --------------------------------------------------------
        // CASE 1: AW and W together
        // --------------------------------------------------------

        if (!tr.separate_aw_w) begin

            // Drive signals before rising edge

            @(negedge axi_vif.ACLK);

            axi_vif.AWADDR  = tr.addr;
            axi_vif.AWVALID = 1'b1;

            axi_vif.WDATA   = tr.data;
            axi_vif.WSTRB   = 4'b1111;
            axi_vif.WVALID  = 1'b1;


            // Wait for handshake

            while (!(axi_vif.AWREADY && axi_vif.WREADY)) begin

                @(posedge axi_vif.ACLK);
                @(negedge axi_vif.ACLK);

            end

            // Allow the handshake clock edge to occur

            @(posedge axi_vif.ACLK);

            axi_vif.AWVALID = 1'b0;
            axi_vif.WVALID  = 1'b0;

        end


        // --------------------------------------------------------
        // CASE 2: AW and W separately
        // --------------------------------------------------------

        else begin

            // ----------------------------------------------------
            // Send address
            // ----------------------------------------------------

            @(negedge axi_vif.ACLK);

            axi_vif.AWADDR  = tr.addr;
            axi_vif.AWVALID = 1'b1;


            while (!axi_vif.AWREADY) begin

                @(posedge axi_vif.ACLK);
                @(negedge axi_vif.ACLK);

            end


            @(posedge axi_vif.ACLK);

            axi_vif.AWVALID = 1'b0;


            // ----------------------------------------------------
            // Send write data
            // ----------------------------------------------------

            @(negedge axi_vif.ACLK);

            axi_vif.WDATA   = tr.data;
            axi_vif.WSTRB   = 4'b1111;
            axi_vif.WVALID  = 1'b1;


            while (!axi_vif.WREADY) begin

                @(posedge axi_vif.ACLK);
                @(negedge axi_vif.ACLK);

            end


            @(posedge axi_vif.ACLK);

            axi_vif.WVALID = 1'b0;

        end


        // --------------------------------------------------------
        // Wait for write response
        // --------------------------------------------------------

        @(negedge axi_vif.ACLK);
        axi_vif.BREADY = 1'b1;

        while (!(axi_vif.BVALID && axi_vif.BREADY)) begin
            @(posedge axi_vif.ACLK);
        end

        if (axi_vif.BRESP != 2'b00) begin
            `uvm_error("AXI_DRV",
                $sformatf(
                    "WRITE RESPONSE ERROR: BRESP=%02b",
                    axi_vif.BRESP
                ))
        end
        else begin
            `uvm_info("AXI_DRV", $sformatf(
                "WRITE completed: ADDR=%08h DATA=%08h",
                tr.addr,
                tr.data
            ), UVM_MEDIUM)
        end

        @(negedge axi_vif.ACLK);
        axi_vif.BREADY = 1'b0;

    endtask


    // ============================================================
    // READ TASK
    // ============================================================

    virtual task drive_read(
        axi_transaction tr
    );

        // --------------------------------------------------------
        // Drive read address BEFORE rising edge
        // --------------------------------------------------------

        @(negedge axi_vif.ACLK);

        axi_vif.ARADDR  = tr.addr;
        axi_vif.ARVALID = 1'b1;


        // --------------------------------------------------------
        // Wait for AR handshake
        // --------------------------------------------------------

        while (!axi_vif.ARREADY) begin

            @(posedge axi_vif.ACLK);
            @(negedge axi_vif.ACLK);

        end


        // Actual handshake occurs here

        @(posedge axi_vif.ACLK);


        // Remove VALID after handshake

        axi_vif.ARVALID = 1'b0;


        // --------------------------------------------------------
        // Wait for read response
        // --------------------------------------------------------

        @(negedge axi_vif.ACLK);
        axi_vif.RREADY = 1'b1;

        while (!(axi_vif.RVALID && axi_vif.RREADY)) begin
            @(posedge axi_vif.ACLK);
        end

        if (axi_vif.RRESP != 2'b00) begin
            `uvm_error("AXI_DRV",
                $sformatf(
                    "READ RESPONSE ERROR: RRESP=%02b",
                    axi_vif.RRESP
                ))
        end
        else begin
            `uvm_info("AXI_DRV",
                $sformatf(
                    "READ completed: ADDR=%08h DATA=%08h RRESP=%02b",
                    tr.addr,
                    axi_vif.RDATA,
                    axi_vif.RRESP
                ),
                UVM_MEDIUM)
        end

        @(negedge axi_vif.ACLK);
        axi_vif.RREADY = 1'b0;

    endtask


endclass

`endif