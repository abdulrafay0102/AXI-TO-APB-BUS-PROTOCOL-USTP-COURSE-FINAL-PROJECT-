`timescale 1ns/1ps

module bridge_control_integration_tb;

    //==================================================
    // CLOCKS
    //==================================================

    logic ACLK;
    logic PCLK;

    //==================================================
    // RESETS
    //==================================================

    logic ARESETn;
    logic PRESETn;

    //==================================================
    // AXI INTERFACE
    //==================================================

    axi_if axi (
        .ACLK    (ACLK),
        .ARESETn (ARESETn)
    );

    //==================================================
    // APB SIGNALS
    //==================================================

    logic [31:0] PADDR;
    logic [31:0] PWDATA;
    logic        PWRITE;
    logic        PSEL;
    logic        PENABLE;

    logic [31:0] PRDATA;
    logic        PREADY;
    logic        PSLVERR;

    //==================================================
    // STATUS
    //==================================================

    logic busy;
    logic transaction_done;

    logic test_passed;

    //==================================================
    // DUT
    //==================================================

    bridge_control_integration dut (

        .axi              (axi),

        .PCLK             (PCLK),
        .PRESETn          (PRESETn),

        .PADDR            (PADDR),
        .PWDATA           (PWDATA),
        .PWRITE           (PWRITE),
        .PSEL             (PSEL),
        .PENABLE          (PENABLE),

        .PRDATA           (PRDATA),
        .PREADY           (PREADY),
        .PSLVERR          (PSLVERR),

        .busy             (busy),
        .transaction_done(transaction_done)

    );

    //==================================================
    // SIMPLE APB MEMORY
    //==================================================

    logic [31:0] memory [0:255];

    integer i;

    //==================================================
    // CLOCK GENERATION
    //==================================================

    initial begin

        ACLK = 1'b0;

        forever #5 ACLK = ~ACLK;

    end

    initial begin

        PCLK = 1'b0;

        forever #7 PCLK = ~PCLK;

    end

    //==================================================
    // APB MEMORY MODEL
    //==================================================

    always_ff @(posedge PCLK or negedge PRESETn) begin

        if (!PRESETn) begin

            PRDATA  <= '0;
            PREADY  <= 1'b0;
            PSLVERR <= 1'b0;

            for (i = 0; i < 256; i = i + 1)
                memory[i] <= '0;

        end

        else begin

            PREADY  <= 1'b0;
            PSLVERR <= 1'b0;

            if (PSEL && PENABLE) begin

                PREADY <= 1'b1;

                if (PWRITE) begin

                    memory[PADDR[9:2]] <= PWDATA;

                end

                else begin

                    PRDATA <= memory[PADDR[9:2]];

                end

            end

        end

    end

    //==================================================
    // VCD
    //==================================================

    initial begin

        $dumpfile("dump.vcd");
        $dumpvars(0, bridge_control_integration_tb);

    end

    //==================================================
    // MAIN TEST
    //==================================================

    initial begin

        ARESETn = 1'b0;
        PRESETn = 1'b0;

        axi.AWVALID = 1'b0;
        axi.AWADDR  = '0;

        axi.ARVALID = 1'b0;
        axi.ARADDR  = '0;

        axi.WVALID  = 1'b0;
        axi.WDATA   = '0;
        axi.WSTRB   = '0;

        axi.BREADY  = 1'b0;
        axi.RREADY  = 1'b0;

        test_passed = 1'b1;

        //================================================
        // RESET
        //================================================

        #30;

        ARESETn = 1'b1;
        PRESETn = 1'b1;

        #20;

        //================================================
        // HEADER
        //================================================

        $display("");
        $display("========================================");
        $display("     BRIDGE CONTROL INTEGRATION TEST");
        $display("========================================");

        //================================================
        // TEST 1: AXI WRITE
        //================================================

        $display("");
        $display("TEST 1: AXI WRITE");

        $display("Sending Address = 00000010");

        send_write_address(32'h00000010);

        // Deliberately wait before sending data
        #30;

        $display("Sending Data    = DEADBEEF");

        send_write_data(32'hDEADBEEF);

        // Wait for APB transaction
        wait (transaction_done == 1'b1);

        $display("");
        $display("APB WRITE COMPLETED");

        //================================================
        // CHECK MEMORY
        //================================================

        if (memory[32'h10 >> 2] == 32'hDEADBEEF) begin

            $display("Address = 00000010");
            $display("Data    = %h", memory[32'h10 >> 2]);
            $display("PASS: APB memory contains correct data.");

        end

        else begin

            $display("ERROR: APB memory data incorrect.");
            $display("Expected = DEADBEEF");
            $display("Actual   = %h", memory[32'h10 >> 2]);

            test_passed = 1'b0;

        end

        //================================================
        // FINISH
        //================================================

        #40;

        $display("");

        if (test_passed) begin

            $display("========================================");
            $display(" BRIDGE CONTROL TEST PASSED!");
            $display("========================================");

        end

        else begin

            $display("========================================");
            $display(" BRIDGE CONTROL TEST FAILED!");
            $display("========================================");

        end

        $finish;

    end

    //==================================================
    // SEND AXI WRITE ADDRESS
    //==================================================

    task send_write_address(
        input logic [31:0] address
    );

        begin

            @(negedge ACLK);

            axi.AWADDR  = address;
            axi.AWVALID = 1'b1;

            while (!(axi.AWVALID && axi.AWREADY))
                @(negedge ACLK);

            @(negedge ACLK);

            axi.AWVALID = 1'b0;
            axi.AWADDR  = '0;

        end

    endtask

    //==================================================
    // SEND AXI WRITE DATA
    //==================================================

    task send_write_data(
        input logic [31:0] data
    );

        begin

            @(negedge ACLK);

            axi.WDATA  = data;
            axi.WVALID = 1'b1;

            while (!(axi.WVALID && axi.WREADY))
                @(negedge ACLK);

            @(negedge ACLK);

            axi.WVALID = 1'b0;
            axi.WDATA  = '0;

        end

    endtask

endmodule