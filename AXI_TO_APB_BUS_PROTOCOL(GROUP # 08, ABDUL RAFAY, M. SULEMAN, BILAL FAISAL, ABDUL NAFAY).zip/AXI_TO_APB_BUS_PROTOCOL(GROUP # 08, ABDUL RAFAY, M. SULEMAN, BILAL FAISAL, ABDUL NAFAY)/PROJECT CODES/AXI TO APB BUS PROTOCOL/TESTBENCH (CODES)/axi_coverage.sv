`ifndef AXI_COVERAGE_SV
`define AXI_COVERAGE_SV

class axi_coverage extends uvm_subscriber #(axi_transaction);

    `uvm_component_utils(axi_coverage)

    bit [31:0] cov_addr;
    bit        cov_is_write;


    // Operation Coverage
    covergroup axi_operation_cg;

        cp_operation: coverpoint cov_is_write {

            bins WRITE = {1'b1};
            bins READ  = {1'b0};

        }

    endgroup


    // Address Coverage
    covergroup axi_address_cg;

        cp_address: coverpoint cov_addr {

            bins ADDR_10 = {32'h00000010};
            bins ADDR_20 = {32'h00000020};
            bins ADDR_30 = {32'h00000030};
            bins ADDR_40 = {32'h00000040};
            bins ADDR_50 = {32'h00000050};
            bins ADDR_60 = {32'h00000060};
            bins ADDR_70 = {32'h00000070};
            bins ADDR_80 = {32'h00000080};

        }

    endgroup


    // Operation × Address Coverage
    covergroup axi_cross_cg;

        cp_operation: coverpoint cov_is_write {

            bins WRITE = {1'b1};
            bins READ  = {1'b0};

        }

        cp_address: coverpoint cov_addr {

            bins ADDR_10 = {32'h00000010};
            bins ADDR_20 = {32'h00000020};
            bins ADDR_30 = {32'h00000030};
            bins ADDR_40 = {32'h00000040};
            bins ADDR_50 = {32'h00000050};
            bins ADDR_60 = {32'h00000060};
            bins ADDR_70 = {32'h00000070};
            bins ADDR_80 = {32'h00000080};

        }

        operation_address:
            cross cp_operation, cp_address;

    endgroup


    function new(
        string name = "axi_coverage",
        uvm_component parent = null
    );

        super.new(name, parent);

        axi_operation_cg = new();
        axi_address_cg   = new();
        axi_cross_cg     = new();

    endfunction


    virtual function void write(
        axi_transaction t
    );

        if (t.addr == 32'h00000000)
            return;

        cov_addr     = t.addr;
        cov_is_write = t.is_write;

        axi_operation_cg.sample();
        axi_address_cg.sample();
        axi_cross_cg.sample();

        `uvm_info(
            "COVERAGE",
            $sformatf(
                "Coverage sampled: WRITE=%0b ADDR=%08h",
                cov_is_write,
                cov_addr
            ),
            UVM_LOW
        )

    endfunction


    virtual function void report_phase(
        uvm_phase phase
    );

        `uvm_info(
            "COVERAGE",
            "==============================================",
            UVM_LOW
        )

        `uvm_info(
            "COVERAGE",
            "UVM FUNCTIONAL COVERAGE RESULTS",
            UVM_LOW
        )

        `uvm_info(
            "COVERAGE",
            $sformatf(
                "Operation Coverage = %0.2f%%",
                axi_operation_cg.get_coverage()
            ),
            UVM_LOW
        )

        `uvm_info(
            "COVERAGE",
            $sformatf(
                "Address Coverage = %0.2f%%",
                axi_address_cg.get_coverage()
            ),
            UVM_LOW
        )

        `uvm_info(
            "COVERAGE",
            $sformatf(
                "Operation x Address Coverage = %0.2f%%",
                axi_cross_cg.get_coverage()
            ),
            UVM_LOW
        )

        `uvm_info(
            "COVERAGE",
            "==============================================",
            UVM_LOW
        )

    endfunction

endclass

`endif