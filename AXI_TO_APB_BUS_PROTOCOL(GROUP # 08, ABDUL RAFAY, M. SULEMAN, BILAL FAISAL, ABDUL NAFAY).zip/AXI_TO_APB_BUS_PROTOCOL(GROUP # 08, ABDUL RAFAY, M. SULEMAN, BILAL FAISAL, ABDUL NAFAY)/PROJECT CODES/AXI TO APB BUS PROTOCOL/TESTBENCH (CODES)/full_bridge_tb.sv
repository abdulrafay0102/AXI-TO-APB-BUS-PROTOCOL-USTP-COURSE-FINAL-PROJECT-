module full_bridge_tb;

    //==================================================
    // CLOCKS
    //==================================================

    logic ACLK;
    logic PCLK;

    initial ACLK = 1'b0;
    always #5 ACLK = ~ACLK;

    initial PCLK = 1'b0;
    always #7 PCLK = ~PCLK;


    //==================================================
    // RESETS
    //==================================================

    logic ARESETn;
    logic PRESETn;


    //==================================================
    // AXI INTERFACE
    //==================================================

    axi_if axi (
        .ACLK(ACLK),
        .ARESETn(ARESETn)
    );


    //==================================================
    // APB SIGNALS
    //==================================================

    logic [31:0] APB_ADDR;
    logic [31:0] APB_WDATA;
    logic        APB_WRITE;
    logic        APB_SEL;
    logic        APB_ENABLE;

    logic [31:0] APB_RDATA;
    logic        APB_READY;
    logic        APB_ERROR;


    //==================================================
    // TRANSACTION STATUS
    //==================================================

    logic transaction_done;


    //==================================================
    // TEST STATUS
    //==================================================

    logic test_passed;


    //==================================================
    // TRANSACTION COUNTER
    //==================================================

    integer transaction_count;


    //==================================================
    // DUT
    //==================================================

    full_bridge dut (

        .axi(axi),

        .PCLK(PCLK),
        .PRESETn(PRESETn),

        .APB_ADDR(APB_ADDR),
        .APB_WDATA(APB_WDATA),
        .APB_WRITE(APB_WRITE),
        .APB_SEL(APB_SEL),
        .APB_ENABLE(APB_ENABLE),

        .APB_RDATA(APB_RDATA),
        .APB_READY(APB_READY),
        .APB_ERROR(APB_ERROR),

        .transaction_done(transaction_done)

    );


    //==================================================
    // APB MEMORY
    //==================================================

    apb_memory memory (

        .PCLK(PCLK),
        .PRESETn(PRESETn),

        .PADDR(APB_ADDR),
        .PWDATA(APB_WDATA),
        .PRDATA(APB_RDATA),

        .PWRITE(APB_WRITE),
        .PSEL(APB_SEL),
        .PENABLE(APB_ENABLE),

        .PREADY(APB_READY),
        .PSLVERR(APB_ERROR)

    );


    //==================================================
    // AXI WRITE TASK
    //==================================================

    task automatic axi_write(
        input logic [31:0] address,
        input logic [31:0] data
    );

        begin

            @(posedge ACLK);

            axi.AWADDR  <= address;
            axi.AWVALID <= 1'b1;

            wait(axi.AWREADY);

            @(posedge ACLK);

            axi.AWVALID <= 1'b0;

            $display(
                "AXI WRITE: Address accepted = %h",
                address
            );


            @(posedge ACLK);

            axi.WDATA  <= data;
            axi.WVALID <= 1'b1;

            wait(axi.WREADY);

            @(posedge ACLK);

            axi.WVALID <= 1'b0;

            $display(
                "AXI WRITE: Data accepted = %h",
                data
            );


            wait(transaction_done);

            transaction_count = transaction_count + 1;

            $display(
                "AXI WRITE: Transaction completed"
            );

        end

    endtask


    //==================================================
    // AXI READ TASK
    //==================================================

    task automatic axi_read(
        input logic [31:0] address,
        input logic [31:0] expected_data
    );

        logic [31:0] received_data;

        begin

            @(posedge ACLK);

            axi.ARADDR  <= address;
            axi.ARVALID <= 1'b1;

            wait(axi.ARREADY);

            @(posedge ACLK);

            axi.ARVALID <= 1'b0;

            $display(
                "AXI READ: Address accepted = %h",
                address
            );


            axi.RREADY <= 1'b1;

            wait(axi.RVALID);

            received_data = axi.RDATA;

            $display(
                "AXI READ: Data received = %h",
                received_data
            );


            if (received_data == expected_data) begin

                $display(
                    "PASS: Read data matches expected value"
                );

            end

            else begin

                $display(
                    "FAIL: Read data = %h, Expected = %h",
                    received_data,
                    expected_data
                );

                test_passed = 1'b0;

            end


            @(posedge ACLK);

            axi.RREADY <= 1'b0;

            transaction_count = transaction_count + 1;

            $display(
                "AXI READ: Transaction completed"
            );

        end

    endtask


    //==================================================
    // FINAL MEMORY CHECK
    //==================================================

    task automatic check_memory(
        input logic [31:0] address,
        input logic [31:0] expected_data
    );

        logic [31:0] actual_data;

        begin

            actual_data = memory.memory[address >> 2];

            if (actual_data == expected_data) begin

                $display(
                    "PASS: Memory[%h] = %h",
                    address,
                    actual_data
                );

            end

            else begin

                $display(
                    "FAIL: Memory[%h] = %h, Expected = %h",
                    address,
                    actual_data,
                    expected_data
                );

                test_passed = 1'b0;

            end

        end

    endtask


    //==================================================
    // MAIN TEST
    //==================================================

    initial begin

        test_passed      = 1'b1;
        transaction_count = 0;


        //================================================
        // AXI DEFAULT VALUES
        //================================================

        axi.AWADDR  = '0;
        axi.AWVALID = 1'b0;

        axi.WDATA   = '0;
        axi.WSTRB   = 4'b1111;
        axi.WVALID  = 1'b0;

        axi.BREADY  = 1'b0;

        axi.ARADDR  = '0;
        axi.ARVALID = 1'b0;

        axi.RREADY  = 1'b0;


        //================================================
        // RESET
        //================================================

        ARESETn = 1'b0;
        PRESETn = 1'b0;

        #40;

        ARESETn = 1'b1;
        PRESETn = 1'b1;

        #30;


        //================================================
        // HEADER
        //================================================

        $display("");
        $display("==============================================");
        $display("        STEP 4.9.9 FINAL RTL INTEGRATION");
        $display("==============================================");

        $display("");
        $display("ACLK = 10 ns");
        $display("PCLK = 14 ns");


        //================================================
        // TEST 1
        //================================================

        $display("");
        $display("----------------------------------------------");
        $display("TEST 1: WRITE ADDRESS 0x10");
        $display("----------------------------------------------");

        axi_write(
            32'h00000010,
            32'hDEADBEEF
        );


        //================================================
        // TEST 2
        //================================================

        $display("");
        $display("----------------------------------------------");
        $display("TEST 2: WRITE ADDRESS 0x20");
        $display("----------------------------------------------");

        axi_write(
            32'h00000020,
            32'hCAFEBABE
        );


        //================================================
        // TEST 3
        //================================================

        $display("");
        $display("----------------------------------------------");
        $display("TEST 3: READ ADDRESS 0x10");
        $display("----------------------------------------------");

        axi_read(
            32'h00000010,
            32'hDEADBEEF
        );


        //================================================
        // TEST 4
        //================================================

        $display("");
        $display("----------------------------------------------");
        $display("TEST 4: READ ADDRESS 0x20");
        $display("----------------------------------------------");

        axi_read(
            32'h00000020,
            32'hCAFEBABE
        );


        //================================================
        // TEST 5
        //================================================

        $display("");
        $display("----------------------------------------------");
        $display("TEST 5: WRITE ADDRESS 0x30");
        $display("----------------------------------------------");

        axi_write(
            32'h00000030,
            32'h12345678
        );


        //================================================
        // TEST 6
        //================================================

        $display("");
        $display("----------------------------------------------");
        $display("TEST 6: READ ADDRESS 0x30");
        $display("----------------------------------------------");

        axi_read(
            32'h00000030,
            32'h12345678
        );


        //================================================
        // FINAL MEMORY VERIFICATION
        //================================================

        $display("");
        $display("----------------------------------------------");
        $display("FINAL APB MEMORY CHECK");
        $display("----------------------------------------------");

        check_memory(
            32'h00000010,
            32'hDEADBEEF
        );

        check_memory(
            32'h00000020,
            32'hCAFEBABE
        );

        check_memory(
            32'h00000030,
            32'h12345678
        );


        //================================================
        // FINAL RESULT
        //================================================

        $display("");
        $display("==============================================");

        if (test_passed && (transaction_count == 6)) begin

            $display(
                "STEP 4.9.9 FINAL RTL INTEGRATION PASSED!"
            );

            $display(
                "All 6 AXI transactions completed successfully."
            );

        end

        else begin

            $display(
                "STEP 4.9.9 FINAL RTL INTEGRATION FAILED!"
            );

            $display(
                "Completed transactions = %0d",
                transaction_count
            );

        end

        $display("==============================================");


        #30;

        $finish;

    end


    //==================================================
    // APB DEBUG MONITOR
    //==================================================

    always @(posedge PCLK) begin

        if (APB_SEL && APB_ENABLE) begin

            $display(
                "APB ACCESS: WRITE=%b ADDR=%h WDATA=%h",
                APB_WRITE,
                APB_ADDR,
                APB_WDATA
            );

        end


        if (transaction_done) begin

            $display(
                "APB TRANSACTION DONE"
            );

        end

    end


    //==================================================
    // AXI DEBUG MONITOR
    //==================================================

    always @(posedge ACLK) begin

        if (axi.AWVALID && axi.AWREADY) begin

            $display(
                "AXI MONITOR: AW handshake, ADDR=%h",
                axi.AWADDR
            );

        end


        if (axi.WVALID && axi.WREADY) begin

            $display(
                "AXI MONITOR: W handshake, DATA=%h",
                axi.WDATA
            );

        end


        if (axi.ARVALID && axi.ARREADY) begin

            $display(
                "AXI MONITOR: AR handshake, ADDR=%h",
                axi.ARADDR
            );

        end


        if (axi.RVALID && axi.RREADY) begin

            $display(
                "AXI MONITOR: R handshake, DATA=%h",
                axi.RDATA
            );

        end

    end


    //==================================================
    // WAVEFORM DUMP
    //==================================================

    initial begin

        $dumpfile("dump.vcd");
        $dumpvars(0, full_bridge_tb);

    end

endmodule