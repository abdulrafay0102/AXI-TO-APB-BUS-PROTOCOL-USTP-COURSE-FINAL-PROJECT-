axi_if #(
    .ADDR_WIDTH(ADDR_WIDTH),
    .DATA_WIDTH(DATA_WIDTH)
) axi (
    .ACLK   (ACLK),
    .ARESETn (ARESETn)
);