`timescale 1ns/1ps

module readback_fifo_tb;

    parameter DATA_WIDTH = 32;
    parameter DEPTH = 8;

    logic clk;
    logic resetn;

    logic                  write_en;
    logic [DATA_WIDTH-1:0] write_data;

    logic                  read_en;
    logic [DATA_WIDTH-1:0] read_data;

    logic full;
    logic empty;
    logic [$clog2(DEPTH+1)-1:0] count;

    logic test_pass;

    //==================================================
    // DUT
    //==================================================

    readback_fifo #(
        .DATA_WIDTH(DATA_WIDTH),
        .DEPTH(DEPTH)
    ) dut (
        .clk(clk),
        .resetn(resetn),

        .write_en(write_en),
        .write_data(write_data),

        .read_en(read_en),
        .read_data(read_data),

        .full(full),
        .empty(empty),
        .count(count)
    );

    //==================================================
    // CLOCK
    //==================================================

    initial begin
        clk = 1'b0;

        forever #5 clk = ~clk;
    end

    //==================================================
    // VCD
    //==================================================

    initial begin
        $dumpfile("dump.vcd");
        $dumpvars(0, readback_fifo_tb);
    end

    //==================================================
    // TEST
    //==================================================

    initial begin

        test_pass = 1'b1;

        write_en   = 1'b0;
        write_data = '0;
        read_en    = 1'b0;

        //==================================================
        // RESET
        //==================================================

        resetn = 1'b0;

        #12;

        resetn = 1'b1;


        //==================================================
        // TEST 1: EMPTY CONDITION
        //==================================================

        $display("");
        $display("========================================");
        $display("TEST 1: READBACK FIFO EMPTY");
        $display("========================================");

        if (empty && count == 0) begin
            $display("Readback FIFO is EMPTY.");
        end
        else begin
            $display("ERROR: FIFO should be EMPTY.");
            test_pass = 1'b0;
        end


        //==================================================
        // TEST 2: STORE APB READ DATA
        //==================================================

        $display("");
        $display("========================================");
        $display("TEST 2: STORE READ DATA");
        $display("========================================");

        // First APB read data
        @(negedge clk);

        write_en   = 1'b1;
        write_data = 32'hCAFEBABE;

        @(posedge clk);
        #1;

        // Second APB read data
        @(negedge clk);

        write_data = 32'h11223344;

        @(posedge clk);
        #1;

        // Third APB read data
        @(negedge clk);

        write_data = 32'h55667788;

        @(posedge clk);
        #1;

        // Stop writing
        @(negedge clk);

        write_en   = 1'b0;
        write_data = '0;

        #1;

        $display("FIFO COUNT = %0d", count);

        if (count == 3) begin
            $display("Three APB read data values stored successfully.");
        end
        else begin
            $display("ERROR: Expected COUNT = 3.");
            test_pass = 1'b0;
        end


        //==================================================
        // TEST 3: READ DATA
        //==================================================

        $display("");
        $display("========================================");
        $display("TEST 3: READBACK DATA");
        $display("========================================");

        // First data
        @(negedge clk);

        if (read_data == 32'hCAFEBABE) begin
            $display("Read Data = %h", read_data);
        end
        else begin
            $display("ERROR: Expected CAFEBABE, got %h",
                     read_data);
            test_pass = 1'b0;
        end

        read_en = 1'b1;

        @(posedge clk);
        #1;


        // Second data
        @(negedge clk);

        if (read_data == 32'h11223344) begin
            $display("Read Data = %h", read_data);
        end
        else begin
            $display("ERROR: Expected 11223344, got %h",
                     read_data);
            test_pass = 1'b0;
        end

        @(posedge clk);
        #1;


        // Third data
        @(negedge clk);

        if (read_data == 32'h55667788) begin
            $display("Read Data = %h", read_data);
        end
        else begin
            $display("ERROR: Expected 55667788, got %h",
                     read_data);
            test_pass = 1'b0;
        end

        @(posedge clk);
        #1;


        // Stop reading
        @(negedge clk);

        read_en = 1'b0;

        #1;


        //==================================================
        // TEST 4: EMPTY AFTER READ
        //==================================================

        $display("");
        $display("========================================");
        $display("TEST 4: EMPTY AFTER READ");
        $display("========================================");

        if (empty && count == 0) begin
            $display("Readback FIFO is EMPTY after all reads.");
        end
        else begin
            $display("ERROR: FIFO should be EMPTY.");
            test_pass = 1'b0;
        end


        //==================================================
        // FINAL RESULT
        //==================================================

        $display("");
        $display("========================================");

        if (test_pass) begin
            $display("      READBACK FIFO TEST PASSED!");
        end
        else begin
            $display("      READBACK FIFO TEST FAILED!");
        end

        $display("========================================");

        $finish;

    end

endmodule