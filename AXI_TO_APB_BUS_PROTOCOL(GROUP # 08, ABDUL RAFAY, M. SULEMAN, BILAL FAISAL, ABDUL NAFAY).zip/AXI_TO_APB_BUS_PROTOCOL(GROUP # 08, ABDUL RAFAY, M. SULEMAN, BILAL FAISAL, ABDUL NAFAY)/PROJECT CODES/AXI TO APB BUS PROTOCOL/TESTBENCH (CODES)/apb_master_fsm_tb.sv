module apb_master_fsm_tb;

    parameter ADDR_WIDTH = 32;
    parameter DATA_WIDTH = 32;

    logic PCLK;
    logic PRESETn;

    // ------------------------------------------------
    // MASTER REQUEST SIDE
    // ------------------------------------------------

    logic                  req_valid;
    logic                  req_write;
    logic [ADDR_WIDTH-1:0] req_addr;
    logic [DATA_WIDTH-1:0] req_wdata;

    logic                  req_ready;
    logic                  resp_valid;
    logic [DATA_WIDTH-1:0] resp_rdata;
    logic                  resp_error;

    // ------------------------------------------------
    // APB SIGNALS
    // ------------------------------------------------

    logic [ADDR_WIDTH-1:0] PADDR;
    logic [DATA_WIDTH-1:0] PWDATA;
    logic                  PWRITE;
    logic                  PSEL;
    logic                  PENABLE;

    logic [DATA_WIDTH-1:0] PRDATA;
    logic                  PREADY;
    logic                  PSLVERR;

    // ------------------------------------------------
    // SIMPLE APB MEMORY
    // ------------------------------------------------

    logic [DATA_WIDTH-1:0] memory [0:255];

    // ------------------------------------------------
    // DUT
    // ------------------------------------------------

    apb_master_fsm #(
        .ADDR_WIDTH(ADDR_WIDTH),
        .DATA_WIDTH(DATA_WIDTH)
    ) dut (

        .PCLK(PCLK),
        .PRESETn(PRESETn),

        .req_valid(req_valid),
        .req_write(req_write),
        .req_addr(req_addr),
        .req_wdata(req_wdata),

        .req_ready(req_ready),
        .resp_valid(resp_valid),
        .resp_rdata(resp_rdata),
        .resp_error(resp_error),

        .PADDR(PADDR),
        .PWDATA(PWDATA),
        .PWRITE(PWRITE),
        .PSEL(PSEL),
        .PENABLE(PENABLE),

        .PRDATA(PRDATA),
        .PREADY(PREADY),
        .PSLVERR(PSLVERR)
    );

    // ------------------------------------------------
    // CLOCK
    // ------------------------------------------------

    initial begin
        PCLK = 1'b0;

        forever #5 PCLK = ~PCLK;
    end

    // ------------------------------------------------
    // SIMPLE APB SLAVE MODEL
    // ------------------------------------------------

    always_ff @(posedge PCLK or negedge PRESETn) begin

        if (!PRESETn) begin

            PREADY  <= 1'b0;
            PRDATA  <= '0;
            PSLVERR <= 1'b0;

        end
        else begin

            PREADY  <= 1'b0;
            PSLVERR <= 1'b0;

            if (PSEL && PENABLE) begin

                PREADY <= 1'b1;

                if (PWRITE) begin

                    memory[PADDR[9:2]] <= PWDATA;

                end
                else begin

                    PRDATA <= memory[PADDR[9:2]];

                end

            end

        end

    end

    // ------------------------------------------------
    // WAVEFORM
    // ------------------------------------------------

    initial begin

        $dumpfile("dump.vcd");
        $dumpvars(0, apb_master_fsm_tb);

    end

    // ------------------------------------------------
    // RESET
    // ------------------------------------------------

    task reset_dut;

        begin

            PRESETn   = 1'b0;

            req_valid = 1'b0;
            req_write = 1'b0;
            req_addr  = '0;
            req_wdata = '0;

            #20;

            PRESETn = 1'b1;

            #10;

        end

    endtask

    // ------------------------------------------------
    // APB WRITE TASK
    // ------------------------------------------------

    task apb_write(
        input logic [ADDR_WIDTH-1:0] address,
        input logic [DATA_WIDTH-1:0] data
    );

        begin

            $display("");
            $display("----------------------------------------");
            $display("Starting APB WRITE");
            $display("Address = %h", address);
            $display("Data    = %h", data);
            $display("----------------------------------------");

            @(negedge PCLK);

            req_addr  = address;
            req_wdata = data;
            req_write = 1'b1;
            req_valid = 1'b1;

            @(negedge PCLK);

            req_valid = 1'b0;

            wait (resp_valid);

            @(negedge PCLK);

            if (resp_error) begin

                $display("WRITE FAILED!");

            end
            else begin

                $display("APB WRITE COMPLETED");

            end

        end

    endtask

    // ------------------------------------------------
    // APB READ TASK
    // ------------------------------------------------

    task apb_read(
        input logic [ADDR_WIDTH-1:0] address,
        output logic [DATA_WIDTH-1:0] data
    );

        begin

            $display("");
            $display("----------------------------------------");
            $display("Starting APB READ");
            $display("Address = %h", address);
            $display("----------------------------------------");

            @(negedge PCLK);

            req_addr  = address;
            req_wdata = '0;
            req_write = 1'b0;
            req_valid = 1'b1;

            @(negedge PCLK);

            req_valid = 1'b0;

            wait (resp_valid);

            data = resp_rdata;

            @(negedge PCLK);

            if (resp_error) begin

                $display("READ FAILED!");

            end
            else begin

                $display("APB READ COMPLETED");
                $display("Address = %h", address);
                $display("Data    = %h", data);

            end

        end

    endtask

    // ------------------------------------------------
    // MAIN TEST
    // ------------------------------------------------

    logic [DATA_WIDTH-1:0] read_data;

    initial begin

        $display("");
        $display("========================================");
        $display("       APB MASTER FSM TEST");
        $display("========================================");

        reset_dut();

        // --------------------------------------------
        // WRITE
        // --------------------------------------------

        apb_write(
            32'h00000010,
            32'hDEADBEEF
        );

        // --------------------------------------------
        // READ
        // --------------------------------------------

        apb_read(
            32'h00000010,
            read_data
        );

        // --------------------------------------------
        // CHECK
        // --------------------------------------------

        if (read_data == 32'hDEADBEEF) begin

            $display("");
            $display("========================================");
            $display("       APB MASTER FSM TEST PASSED!");
            $display("========================================");

        end
        else begin

            $display("");
            $display("========================================");
            $display("       APB MASTER FSM TEST FAILED!");
            $display("========================================");

            $display("Expected = DEADBEEF");
            $display("Received = %h", read_data);

        end

        #20;

        $finish;

    end

endmodule