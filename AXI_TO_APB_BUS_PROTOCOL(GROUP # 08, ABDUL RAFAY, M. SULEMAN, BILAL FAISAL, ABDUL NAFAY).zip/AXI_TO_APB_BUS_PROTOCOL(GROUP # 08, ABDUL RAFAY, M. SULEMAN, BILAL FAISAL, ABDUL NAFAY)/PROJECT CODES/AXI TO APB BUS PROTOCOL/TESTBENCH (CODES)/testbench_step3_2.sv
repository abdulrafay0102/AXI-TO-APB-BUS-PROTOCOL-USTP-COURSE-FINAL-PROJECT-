`timescale 1ns/1ns

//============================================================
// STEP 3.2
// DIRECTED AXI/APB VERIFICATION
// AXI4-Lite -> APB BRIDGE
//============================================================

module full_bridge_tb;

    parameter ADDR_WIDTH = 32;
    parameter DATA_WIDTH = 32;

    //============================================================
    // CLOCKS AND RESETS
    //============================================================

    logic ACLK;
    logic PCLK;

    logic ARESETn;
    logic PRESETn;

    //============================================================
    // AXI INTERFACE
    //============================================================

    axi_if #(
        .ADDR_WIDTH(ADDR_WIDTH),
        .DATA_WIDTH(DATA_WIDTH)
    ) axi (
        .ACLK   (ACLK),
        .ARESETn (ARESETn)
    );

    //============================================================
    // APB SIGNALS
    //============================================================

    logic [ADDR_WIDTH-1:0] APB_ADDR;
    logic [DATA_WIDTH-1:0] APB_WDATA;
    logic                  APB_WRITE;
    logic                  APB_SEL;
    logic                  APB_ENABLE;

    logic [DATA_WIDTH-1:0] APB_RDATA;
    logic                  APB_READY;
    logic                  APB_ERROR;

    logic transaction_done;

    //============================================================
    // TEST STATUS
    //============================================================

    integer pass_count;
    integer fail_count;

    //============================================================
    // REFERENCE MEMORY
    // Used by testbench to store expected values
    //============================================================

    logic [DATA_WIDTH-1:0] expected_memory [0:255];

    //============================================================
    // APB MEMORY
    // Simple APB memory model for verification
    //============================================================

    logic [DATA_WIDTH-1:0] apb_memory [0:255];

    integer memory_index;

    //============================================================
    // DUT
    //============================================================

    full_bridge #(
        .ADDR_WIDTH(ADDR_WIDTH),
        .DATA_WIDTH(DATA_WIDTH)
    ) dut (

        .axi(axi),

        .PCLK(PCLK),
        .PRESETn(PRESETn),

        .APB_ADDR(APB_ADDR),
        .APB_WDATA(APB_WDATA),
        .APB_WRITE(APB_WRITE),
        .APB_SEL(APB_SEL),
        .APB_ENABLE(APB_ENABLE),

        .APB_RDATA(APB_RDATA),
        .APB_READY(APB_READY),
        .APB_ERROR(APB_ERROR),

        .transaction_done(transaction_done)
    );

    //============================================================
    // APB MEMORY RESPONSE
    //============================================================

    always_comb begin

        APB_READY = 1'b0;
        APB_ERROR = 1'b0;
        APB_RDATA = '0;

        memory_index = APB_ADDR[9:2];

        if (APB_SEL && APB_ENABLE) begin

            APB_READY = 1'b1;

            if (!APB_WRITE) begin
                APB_RDATA = apb_memory[memory_index];
            end

        end

    end

    //============================================================
    // APB MEMORY WRITE
    //============================================================

    always_ff @(posedge PCLK or negedge PRESETn) begin

        if (!PRESETn) begin

            // FIX:
            // Use a local loop variable instead of global "i"
            for (int j = 0; j < 256; j = j + 1) begin
                apb_memory[j] <= '0;
            end

        end

        else begin

            if (APB_SEL &&
                APB_ENABLE &&
                APB_WRITE &&
                APB_READY) begin

                apb_memory[memory_index] <= APB_WDATA;

                $display(
                    "APB MEMORY: WRITE ADDR=%h DATA=%h",
                    APB_ADDR,
                    APB_WDATA
                );

            end

        end

    end

    //============================================================
    // CLOCK GENERATION
    //============================================================

    // ACLK = 10 ns
    initial begin

        ACLK = 1'b0;

        forever #5 ACLK = ~ACLK;

    end

    // PCLK = 14 ns
    initial begin

        PCLK = 1'b0;

        forever #7 PCLK = ~PCLK;

    end

    //============================================================
    // RESET
    //============================================================

    initial begin

        ARESETn = 1'b0;
        PRESETn = 1'b0;

        #40;

        ARESETn = 1'b1;
        PRESETn = 1'b1;

        $display("");
        $display("==============================================");
        $display("RESET COMPLETE");
        $display("==============================================");
        $display("");

    end

    //============================================================
    // INITIAL AXI VALUES
    //============================================================

    initial begin

        axi.AWVALID = 1'b0;
        axi.AWADDR  = '0;

        axi.WVALID  = 1'b0;
        axi.WDATA   = '0;
        axi.WSTRB   = '1;

        axi.BREADY  = 1'b1;

        axi.ARVALID = 1'b0;
        axi.ARADDR  = '0;

        axi.RREADY  = 1'b1;

    end

    //============================================================
    // INITIALIZE REFERENCE MEMORY
    //============================================================

    initial begin

        // FIX:
        // Use another local loop variable
        for (int j = 0; j < 256; j = j + 1) begin
            expected_memory[j] = '0;
        end

    end

    //============================================================
    // AXI WRITE TASK
    //============================================================

    task automatic axi_write(
        input logic [ADDR_WIDTH-1:0] addr,
        input logic [DATA_WIDTH-1:0] data
    );

        integer index;

        begin

            index = addr[9:2];

            $display("");
            $display("----------------------------------------------");
            $display("DIRECTED TEST: AXI WRITE");
            $display("Address = %h", addr);
            $display("Data    = %h", data);
            $display("----------------------------------------------");

            //================================================
            // SEND ADDRESS
            //================================================

            @(posedge ACLK);

            axi.AWADDR  <= addr;
            axi.AWVALID <= 1'b1;

            wait (axi.AWREADY == 1'b1);

            @(posedge ACLK);

            axi.AWVALID <= 1'b0;

            $display(
                "AXI: AW handshake ADDR=%h",
                addr
            );

            //================================================
            // SEND DATA
            //================================================

            @(posedge ACLK);

            axi.WDATA  <= data;
            axi.WVALID <= 1'b1;

            wait (axi.WREADY == 1'b1);

            @(posedge ACLK);

            axi.WVALID <= 1'b0;

            $display(
                "AXI: W handshake DATA=%h",
                data
            );

            //================================================
            // UPDATE REFERENCE MEMORY
            //================================================

            expected_memory[index] = data;

            //================================================
            // WAIT FOR TRANSACTION COMPLETE
            //================================================

            wait (transaction_done == 1'b1);

            @(posedge PCLK);

            //================================================
            // CHECK APB MEMORY
            //================================================

            if (apb_memory[index] == data) begin

                pass_count = pass_count + 1;

                $display(
                    "PASS: APB memory[%0d] = %h",
                    index,
                    apb_memory[index]
                );

            end

            else begin

                fail_count = fail_count + 1;

                $display(
                    "FAIL: APB memory[%0d] expected=%h actual=%h",
                    index,
                    data,
                    apb_memory[index]
                );

            end

        end

    endtask

    //============================================================
    // AXI READ TASK
    //============================================================

    task automatic axi_read(
        input logic [ADDR_WIDTH-1:0] addr
    );

        logic [DATA_WIDTH-1:0] received_data;
        logic [DATA_WIDTH-1:0] expected_data;

        integer index;

        begin

            index = addr[9:2];

            expected_data = expected_memory[index];

            $display("");
            $display("----------------------------------------------");
            $display("DIRECTED TEST: AXI READ");
            $display("Address  = %h", addr);
            $display("Expected = %h", expected_data);
            $display("----------------------------------------------");

            //================================================
            // SEND READ ADDRESS
            //================================================

            @(posedge ACLK);

            axi.ARADDR  <= addr;
            axi.ARVALID <= 1'b1;

            wait (axi.ARREADY == 1'b1);

            @(posedge ACLK);

            axi.ARVALID <= 1'b0;

            $display(
                "AXI: AR handshake ADDR=%h",
                addr
            );

            //================================================
            // WAIT FOR READ RESPONSE
            //================================================

            wait (axi.RVALID == 1'b1);

            received_data = axi.RDATA;

            $display(
                "AXI: RVALID=1 RDATA=%h",
                received_data
            );

            //================================================
            // CHECK READ RESULT
            //================================================

            if (received_data == expected_data) begin

                pass_count = pass_count + 1;

                $display(
                    "PASS: Read data matches expected value."
                );

            end

            else begin

                fail_count = fail_count + 1;

                $display(
                    "FAIL: Read mismatch."
                );

                $display(
                    "Expected = %h",
                    expected_data
                );

                $display(
                    "Received = %h",
                    received_data
                );

            end

            @(posedge ACLK);

        end

    endtask

    //============================================================
    // SEPARATE AW AND W TEST
    //============================================================

    task automatic axi_write_separate(
        input logic [ADDR_WIDTH-1:0] addr,
        input logic [DATA_WIDTH-1:0] data,
        input integer delay_cycles
    );

        integer index;

        begin

            index = addr[9:2];

            $display("");
            $display("----------------------------------------------");
            $display("DIRECTED TEST: SEPARATE AW / W");
            $display("Address = %h", addr);
            $display("Data    = %h", data);
            $display("Delay   = %0d ACLK cycles", delay_cycles);
            $display("----------------------------------------------");

            //================================================
            // ADDRESS CHANNEL
            //================================================

            @(posedge ACLK);

            axi.AWADDR  <= addr;
            axi.AWVALID <= 1'b1;

            wait (axi.AWREADY == 1'b1);

            @(posedge ACLK);

            axi.AWVALID <= 1'b0;

            $display(
                "AXI: AW handshake completed."
            );

            //================================================
            // DELAY BEFORE WRITE DATA
            //================================================

            repeat (delay_cycles)
                @(posedge ACLK);

            //================================================
            // WRITE DATA CHANNEL
            //================================================

            axi.WDATA  <= data;
            axi.WVALID <= 1'b1;

            wait (axi.WREADY == 1'b1);

            @(posedge ACLK);

            axi.WVALID <= 1'b0;

            $display(
                "AXI: W handshake completed."
            );

            expected_memory[index] = data;

            //================================================
            // WAIT FOR COMPLETE
            //================================================

            wait (transaction_done == 1'b1);

            @(posedge PCLK);

            //================================================
            // CHECK
            //================================================

            if (apb_memory[index] == data) begin

                pass_count = pass_count + 1;

                $display(
                    "PASS: Separate AW/W transaction completed."
                );

            end

            else begin

                fail_count = fail_count + 1;

                $display(
                    "FAIL: Separate AW/W transaction failed."
                );

                $display(
                    "Expected = %h",
                    data
                );

                $display(
                    "Actual   = %h",
                    apb_memory[index]
                );

            end

        end

    endtask

    //============================================================
    // APB MONITOR
    //============================================================

    always @(posedge PCLK) begin

        if (PRESETn) begin

            if (APB_SEL &&
                APB_ENABLE &&
                APB_READY) begin

                $display("");
                $display(
                    "APB MONITOR: ACCESS"
                );

                $display(
                    "WRITE = %b",
                    APB_WRITE
                );

                $display(
                    "ADDR  = %h",
                    APB_ADDR
                );

                $display(
                    "WDATA = %h",
                    APB_WDATA
                );

                $display(
                    "RDATA = %h",
                    APB_RDATA
                );

            end

        end

    end

    //============================================================
    // MAIN DIRECTED TEST
    //============================================================

    initial begin

        pass_count = 0;
        fail_count = 0;

        //========================================================
        // WAIT FOR RESET
        //========================================================

        wait (ARESETn == 1'b1);
        wait (PRESETn == 1'b1);

        repeat (3)
            @(posedge ACLK);

        $display("");
        $display("==============================================");
        $display("     STEP 3.2 DIRECTED AXI/APB VERIFICATION");
        $display("==============================================");

        //========================================================
        // TEST 1
        // BASIC WRITE
        //========================================================

        axi_write(
            32'h00000010,
            32'hDEADBEEF
        );

        //========================================================
        // TEST 2
        // BASIC READ
        //========================================================

        axi_read(
            32'h00000010
        );

        //========================================================
        // TEST 3
        // SECOND WRITE
        //========================================================

        axi_write(
            32'h00000020,
            32'hCAFEBABE
        );

        //========================================================
        // TEST 4
        // SECOND READ
        //========================================================

        axi_read(
            32'h00000020
        );

        //========================================================
        // TEST 5
        // ZERO DATA
        //========================================================

        axi_write(
            32'h00000030,
            32'h00000000
        );

        axi_read(
            32'h00000030
        );

        //========================================================
        // TEST 6
        // ALL ONES
        //========================================================

        axi_write(
            32'h00000040,
            32'hFFFFFFFF
        );

        axi_read(
            32'h00000040
        );

        //========================================================
        // TEST 7
        // ALTERNATING PATTERN A
        //========================================================

        axi_write(
            32'h00000050,
            32'hAAAAAAAA
        );

        axi_read(
            32'h00000050
        );

        //========================================================
        // TEST 8
        // ALTERNATING PATTERN B
        //========================================================

        axi_write(
            32'h00000060,
            32'h55555555
        );

        axi_read(
            32'h00000060
        );

        //========================================================
        // TEST 9
        // SEPARATE AW AND W
        //========================================================

        axi_write_separate(
            32'h00000070,
            32'h12345678,
            3
        );

        axi_read(
            32'h00000070
        );

        //========================================================
        // TEST 10
        // BACK-TO-BACK WRITE
        //========================================================

        axi_write(
            32'h00000080,
            32'h11223344
        );

        axi_write(
            32'h00000090,
            32'h55667788
        );

        //========================================================
        // TEST 11
        // BACK-TO-BACK READ
        //========================================================

        axi_read(
            32'h00000080
        );

        axi_read(
            32'h00000090
        );

        //========================================================
        // FINAL RESULT
        //========================================================

        #50;

        $display("");
        $display("==============================================");
        $display("        STEP 3.2 TEST SUMMARY");
        $display("==============================================");

        $display(
            "Total PASS = %0d",
            pass_count
        );

        $display(
            "Total FAIL = %0d",
            fail_count
        );

        if (fail_count == 0) begin

            $display("");
            $display("==============================================");
            $display("STEP 3.2 DIRECTED VERIFICATION PASSED!");
            $display("==============================================");
            $display("");

            $display(
                "All directed AXI/APB tests completed successfully."
            );

        end

        else begin

            $display("");
            $display("==============================================");
            $display("STEP 3.2 DIRECTED VERIFICATION FAILED!");
            $display("==============================================");

        end

        $display("");

        $finish;

    end

    //============================================================
    // WAVEFORM
    //============================================================

    initial begin

        $dumpfile("step3_2.vcd");
        $dumpvars(0, full_bridge_tb);

    end

endmodule