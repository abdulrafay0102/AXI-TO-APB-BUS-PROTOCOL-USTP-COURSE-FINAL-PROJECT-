`timescale 1ns/1ps

module async_fifo_tb;

    parameter DATA_WIDTH = 32;
    parameter DEPTH      = 8;

    //==================================================
    // CLOCKS
    //==================================================

    logic wclk;
    logic rclk;

    //==================================================
    // RESETS
    //==================================================

    logic wrst_n;
    logic rrst_n;

    //==================================================
    // WRITE SIDE
    //==================================================

    logic                  write_en;
    logic [DATA_WIDTH-1:0] write_data;
    logic                  full;

    //==================================================
    // READ SIDE
    //==================================================

    logic                  read_en;
    logic [DATA_WIDTH-1:0] read_data;
    logic                  empty;

    integer errors;

    //==================================================
    // DUT
    //==================================================

    async_fifo #(
        .DATA_WIDTH(DATA_WIDTH),
        .DEPTH(DEPTH)
    ) dut (

        .wclk(wclk),
        .wrst_n(wrst_n),

        .write_en(write_en),
        .write_data(write_data),

        .full(full),

        .rclk(rclk),
        .rrst_n(rrst_n),

        .read_en(read_en),
        .read_data(read_data),

        .empty(empty)
    );

    //==================================================
    // WRITE CLOCK
    //==================================================

    initial begin

        wclk = 1'b0;

        forever #5 wclk = ~wclk;

    end

    //==================================================
    // READ CLOCK
    //==================================================

    initial begin

        rclk = 1'b0;

        forever #7 rclk = ~rclk;

    end

    //==================================================
    // WAVEFORM
    //==================================================

    initial begin

        $dumpfile("dump.vcd");
        $dumpvars(0, async_fifo_tb);

    end

    //==================================================
    // TEST
    //==================================================

    initial begin

        errors = 0;

        write_en  = 1'b0;
        write_data = '0;

        read_en = 1'b0;

        wrst_n = 1'b0;
        rrst_n = 1'b0;

        //================================================
        // RESET
        //================================================

        #30;

        wrst_n = 1'b1;
        rrst_n = 1'b1;

        //================================================
        // TEST 1
        //================================================

        $display("");
        $display("========================================");
        $display("TEST 1: RESET / EMPTY");
        $display("========================================");

        repeat (3)
            @(posedge rclk);

        if (empty) begin

            $display("PASS: Async FIFO is EMPTY.");

        end
        else begin

            $display("ERROR: FIFO should be EMPTY.");

            errors = errors + 1;

        end

        //================================================
        // TEST 2
        //================================================

        $display("");
        $display("========================================");
        $display("TEST 2: WRITE FOUR VALUES");
        $display("========================================");

        @(negedge wclk);

        write_en   = 1'b1;
        write_data = 32'h11111111;

        @(negedge wclk);

        write_data = 32'h22222222;

        @(negedge wclk);

        write_data = 32'h33333333;

        @(negedge wclk);

        write_data = 32'h44444444;

        @(negedge wclk);

        write_en   = 1'b0;
        write_data = '0;

        $display("PASS: Four values written in ACLK domain.");

        //================================================
        // ALLOW CDC SYNCHRONIZATION
        //================================================

        repeat (5)
            @(posedge rclk);

        //================================================
        // TEST 3
        //================================================

        $display("");
        $display("========================================");
        $display("TEST 3: READ FOUR VALUES");
        $display("========================================");

        // Enable read
        @(negedge rclk);

        read_en = 1'b1;

        // First read
        @(posedge rclk);

        #1;

        if (read_data == 32'h11111111) begin

            $display("Read Data = %h", read_data);

        end
        else begin

            $display("ERROR: Expected 11111111, Got %h",
                     read_data);

            errors = errors + 1;

        end

        // Second read
        @(posedge rclk);

        #1;

        if (read_data == 32'h22222222) begin

            $display("Read Data = %h", read_data);

        end
        else begin

            $display("ERROR: Expected 22222222, Got %h",
                     read_data);

            errors = errors + 1;

        end

        // Third read
        @(posedge rclk);

        #1;

        if (read_data == 32'h33333333) begin

            $display("Read Data = %h", read_data);

        end
        else begin

            $display("ERROR: Expected 33333333, Got %h",
                     read_data);

            errors = errors + 1;

        end

        // Fourth read
        @(posedge rclk);

        #1;

        if (read_data == 32'h44444444) begin

            $display("Read Data = %h", read_data);

        end
        else begin

            $display("ERROR: Expected 44444444, Got %h",
                     read_data);

            errors = errors + 1;

        end

        @(negedge rclk);

        read_en = 1'b0;

        //================================================
        // ALLOW POINTER SYNCHRONIZATION
        //================================================

        repeat (5)
            @(posedge rclk);

        //================================================
        // TEST 4
        //================================================

        $display("");
        $display("========================================");
        $display("TEST 4: EMPTY AFTER READ");
        $display("========================================");

        if (empty) begin

            $display("PASS: FIFO is EMPTY after all reads.");

        end
        else begin

            $display("ERROR: FIFO should be EMPTY.");

            errors = errors + 1;

        end

        //================================================
        // FINAL RESULT
        //================================================

        $display("");
        $display("========================================");

        if (errors == 0) begin

            $display("       ASYNC FIFO TEST PASSED!");

        end
        else begin

            $display("       ASYNC FIFO TEST FAILED!");
            $display("       Errors = %0d", errors);

        end

        $display("========================================");

        #20;

        $finish;

    end

endmodule