class axi_uvm_test extends uvm_test;

    `uvm_component_utils(axi_uvm_test)


    // ============================================================
    // UVM ENVIRONMENT
    // ============================================================

    axi_env env;
    axi_sequence seq;


    // ============================================================
    // CONSTRUCTOR
    // ============================================================

    function new(
        string name = "axi_uvm_test",
        uvm_component parent = null
    );

        super.new(name, parent);

    endfunction


    // ============================================================
    // BUILD PHASE
    // ============================================================

    virtual function void build_phase(
        uvm_phase phase
    );

        super.build_phase(phase);


        // --------------------------------------------------------
        // Create UVM environment
        // --------------------------------------------------------

        env = axi_env::type_id::create(
            "env",
            this
        );

    endfunction


    // ============================================================
    // RUN PHASE
    // ============================================================

    virtual task run_phase(
        uvm_phase phase
    );

        phase.raise_objection(this);


        `uvm_info(
            "TEST",
            "==============================================",
            UVM_LOW
        )

        `uvm_info(
            "TEST",
            "STEP 3.9 FINAL UVM REGRESSION",
            UVM_LOW
        )

        `uvm_info(
            "TEST",
            "Starting Final AXI UVM Regression",
            UVM_LOW
        )


        // --------------------------------------------------------
        // Create sequence
        // --------------------------------------------------------

        seq = axi_sequence::type_id::create(
            "seq"
        );


        // --------------------------------------------------------
        // Start sequence on agent sequencer
        // --------------------------------------------------------

        seq.start(
            env.agent.sequencer
        );


        `uvm_info(
            "TEST",
            "Sequence completed. Checking driver transaction count...",
            UVM_LOW
        )


        if (env.agent.driver.completed_transactions == 20) begin

            `uvm_info(
                "TEST",
                $sformatf(
                    "All 20 AXI transactions completed successfully. Driver count = %0d",
                    env.agent.driver.completed_transactions
                ),
                UVM_LOW
            )

        end
        else begin

            `uvm_error(
                "TEST",
                $sformatf(
                    "Transaction completion mismatch! Expected = 20, Completed = %0d",
                    env.agent.driver.completed_transactions
                )
            )

        end


        `uvm_info(
            "TEST",
            "Final AXI UVM Regression Completed",
            UVM_LOW
        )


        phase.drop_objection(this);

    endtask

endclass