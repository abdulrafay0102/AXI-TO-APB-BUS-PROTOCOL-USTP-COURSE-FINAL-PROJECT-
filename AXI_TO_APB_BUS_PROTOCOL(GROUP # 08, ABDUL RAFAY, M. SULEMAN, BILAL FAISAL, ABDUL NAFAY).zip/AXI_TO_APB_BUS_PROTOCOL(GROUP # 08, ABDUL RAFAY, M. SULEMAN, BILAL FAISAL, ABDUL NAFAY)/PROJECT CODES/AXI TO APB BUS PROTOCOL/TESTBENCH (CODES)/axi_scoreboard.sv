`ifndef AXI_SCOREBOARD_SV
`define AXI_SCOREBOARD_SV

class axi_scoreboard extends uvm_scoreboard;

    `uvm_component_utils(axi_scoreboard)

    // Receive transactions from AXI monitor
    uvm_analysis_imp #(axi_transaction, axi_scoreboard) analysis_export;

    // Simple reference memory
    bit [31:0] expected_memory [bit [31:0]];

    // Store pending write address
    bit [31:0] pending_write_addr;
    bit        write_addr_valid;

    // Store pending read address
    bit [31:0] pending_read_addr;
    bit        read_addr_valid;

    function new(
        string name = "axi_scoreboard",
        uvm_component parent = null
    );
        super.new(name, parent);

        analysis_export = new(
            "analysis_export",
            this
        );

        write_addr_valid = 1'b0;
        read_addr_valid  = 1'b0;
    endfunction


    // Receive transaction from monitor
    virtual function void write(
        axi_transaction tr
    );

        // ------------------------------------------------
        // WRITE transaction
        // ------------------------------------------------
        if (tr.is_write) begin

            // Write address received
            if ((tr.addr != 32'h00000000) &&
                (tr.data == 32'h00000000)) begin

                pending_write_addr = tr.addr;
                write_addr_valid   = 1'b1;

                `uvm_info(
                    "SCOREBOARD",
                    $sformatf(
                        "WRITE ADDRESS received: ADDR=%08h",
                        tr.addr
                    ),
                    UVM_MEDIUM
                )
            end

            // Write data received
            else if (write_addr_valid) begin

                expected_memory[pending_write_addr] = tr.data;

                `uvm_info(
                    "SCOREBOARD",
                    $sformatf(
                        "WRITE CHECK PASS: ADDR=%08h DATA=%08h",
                        pending_write_addr,
                        tr.data
                    ),
                    UVM_MEDIUM
                )

                write_addr_valid = 1'b0;
            end

        end

        // ------------------------------------------------
        // READ transaction
        // ------------------------------------------------
        else begin

            // Read address received
            if ((tr.addr != 32'h00000000) &&
                (tr.data == 32'h00000000)) begin

                pending_read_addr = tr.addr;
                read_addr_valid   = 1'b1;

                `uvm_info(
                    "SCOREBOARD",
                    $sformatf(
                        "READ ADDRESS received: ADDR=%08h",
                        tr.addr
                    ),
                    UVM_MEDIUM
                )
            end

            // Read response received
            else if (read_addr_valid) begin

                if (expected_memory.exists(pending_read_addr)) begin

                    if (tr.data == expected_memory[pending_read_addr]) begin

                        `uvm_info(
                            "SCOREBOARD",
                            $sformatf(
                                "READ CHECK PASS: ADDR=%08h EXPECTED=%08h ACTUAL=%08h",
                                pending_read_addr,
                                expected_memory[pending_read_addr],
                                tr.data
                            ),
                            UVM_MEDIUM
                        )

                    end
                    else begin

                        `uvm_error(
                            "SCOREBOARD",
                            $sformatf(
                                "READ CHECK FAIL: ADDR=%08h EXPECTED=%08h ACTUAL=%08h",
                                pending_read_addr,
                                expected_memory[pending_read_addr],
                                tr.data
                            )
                        )

                    end

                end
                else begin

                    `uvm_info(
                        "SCOREBOARD",
                        $sformatf(
                            "READ CHECK: ADDR=%08h has no previous write. DATA=%08h",
                            pending_read_addr,
                            tr.data
                        ),
                        UVM_MEDIUM
                    )

                end

                read_addr_valid = 1'b0;
            end

        end

    endfunction

endclass

`endif