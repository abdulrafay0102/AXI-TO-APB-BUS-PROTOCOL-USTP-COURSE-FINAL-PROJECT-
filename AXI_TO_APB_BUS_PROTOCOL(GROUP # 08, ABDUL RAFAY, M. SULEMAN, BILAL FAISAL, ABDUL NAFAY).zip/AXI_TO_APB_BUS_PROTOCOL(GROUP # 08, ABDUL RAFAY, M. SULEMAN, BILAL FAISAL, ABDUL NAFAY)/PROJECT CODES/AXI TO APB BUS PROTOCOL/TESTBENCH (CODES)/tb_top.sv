module tb_top;

    // ============================================================
    // CLOCKS
    // ============================================================

    logic ACLK;
    logic PCLK;


    // ============================================================
    // RESETS
    // ============================================================

    logic ARESETn;
    logic PRESETn;


    // ============================================================
    // PARAMETERS
    // ============================================================

    parameter ADDR_WIDTH = 32;
    parameter DATA_WIDTH = 32;


    // ============================================================
    // AXI INTERFACE
    // ============================================================

    axi_if #(
        .ADDR_WIDTH(ADDR_WIDTH),
        .DATA_WIDTH(DATA_WIDTH)
    ) axi (
        .ACLK   (ACLK),
        .ARESETn (ARESETn)
    );


    // ============================================================
    // APB SIGNALS
    // ============================================================

    logic [ADDR_WIDTH-1:0] APB_ADDR;
    logic [DATA_WIDTH-1:0] APB_WDATA;

    logic APB_WRITE;
    logic APB_SEL;
    logic APB_ENABLE;

    logic [DATA_WIDTH-1:0] APB_RDATA;

    logic APB_READY;
    logic APB_ERROR;

    logic transaction_done;


    // ============================================================
    // DUT
    // ============================================================

    full_bridge #(
        .ADDR_WIDTH(ADDR_WIDTH),
        .DATA_WIDTH(DATA_WIDTH)
    ) dut (

        .axi(axi),

        .PCLK(PCLK),
        .PRESETn(PRESETn),

        .APB_ADDR(APB_ADDR),
        .APB_WDATA(APB_WDATA),
        .APB_WRITE(APB_WRITE),
        .APB_SEL(APB_SEL),
        .APB_ENABLE(APB_ENABLE),

        .APB_RDATA(APB_RDATA),
        .APB_READY(APB_READY),
        .APB_ERROR(APB_ERROR),

        .transaction_done(transaction_done)

    );


    // ============================================================
    // APB MEMORY
    // ============================================================

    apb_memory #(
        .ADDR_WIDTH(ADDR_WIDTH),
        .DATA_WIDTH(DATA_WIDTH),
        .DEPTH(256)
    ) memory (

        .PCLK(PCLK),
        .PRESETn(PRESETn),

        .PADDR(APB_ADDR),
        .PWDATA(APB_WDATA),
        .PRDATA(APB_RDATA),

        .PWRITE(APB_WRITE),
        .PSEL(APB_SEL),
        .PENABLE(APB_ENABLE),

        .PREADY(APB_READY),
        .PSLVERR(APB_ERROR)

    );


    // ============================================================
    // CLOCK GENERATION
    // ============================================================

    initial begin

        ACLK = 1'b0;

        forever #5 ACLK = ~ACLK;

    end


    initial begin

        PCLK = 1'b0;

        forever #7 PCLK = ~PCLK;

    end


    // ============================================================
    // RESET
    // ============================================================

    initial begin

        ARESETn = 1'b0;
        PRESETn = 1'b0;

        repeat (5)
            @(posedge ACLK);

        ARESETn = 1'b1;
        PRESETn = 1'b1;

    end


    initial begin
        // ------------------------------------------------------------
        // Pass AXI virtual interface to UVM
        // ------------------------------------------------------------

        uvm_config_db#(virtual axi_if)::set(
            null,
            "*",
            "axi_vif",
            axi
        );


        // ------------------------------------------------------------
        // Start UVM test
        // ------------------------------------------------------------

        run_test("axi_uvm_test");

    end


    // ============================================================
    // WAVEFORM
    // ============================================================

    initial begin

        $dumpfile("step3_6_uvm.vcd");

        $dumpvars(
            0,
            tb_top
        );

    end

endmodule