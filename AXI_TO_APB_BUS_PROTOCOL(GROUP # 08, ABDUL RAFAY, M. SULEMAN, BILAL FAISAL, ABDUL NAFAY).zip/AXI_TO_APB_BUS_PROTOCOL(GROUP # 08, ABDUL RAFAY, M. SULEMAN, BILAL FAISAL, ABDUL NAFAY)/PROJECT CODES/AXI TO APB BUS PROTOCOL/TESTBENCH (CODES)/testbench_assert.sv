`timescale 1ns/1ns

//============================================================
// STEP 3.3
// ASSERTION-BASED VERIFICATION
// AXI4-Lite -> APB BRIDGE
//============================================================

module full_bridge_assert_tb;

    parameter ADDR_WIDTH = 32;
    parameter DATA_WIDTH = 32;

    //============================================================
    // CLOCKS AND RESETS
    //============================================================

    logic ACLK;
    logic PCLK;

    logic ARESETn;
    logic PRESETn;

    //============================================================
    // AXI INTERFACE
    //============================================================

    axi_if #(
        .ADDR_WIDTH(ADDR_WIDTH),
        .DATA_WIDTH(DATA_WIDTH)
    ) axi (
        .ACLK   (ACLK),
        .ARESETn (ARESETn)
    );

    //============================================================
    // APB SIGNALS
    //============================================================

    logic [ADDR_WIDTH-1:0] APB_ADDR;
    logic [DATA_WIDTH-1:0] APB_WDATA;

    logic APB_WRITE;
    logic APB_SEL;
    logic APB_ENABLE;

    logic [DATA_WIDTH-1:0] APB_RDATA;
    logic APB_READY;
    logic APB_ERROR;

    logic transaction_done;

    //============================================================
    // APB TEST MEMORY
    //============================================================

    logic [DATA_WIDTH-1:0] apb_memory [0:255];

    integer memory_index;

    //============================================================
    // DUT
    //============================================================

    full_bridge #(
        .ADDR_WIDTH(ADDR_WIDTH),
        .DATA_WIDTH(DATA_WIDTH)
    ) dut (

        .axi(axi),

        .PCLK(PCLK),
        .PRESETn(PRESETn),

        .APB_ADDR(APB_ADDR),
        .APB_WDATA(APB_WDATA),
        .APB_WRITE(APB_WRITE),
        .APB_SEL(APB_SEL),
        .APB_ENABLE(APB_ENABLE),

        .APB_RDATA(APB_RDATA),
        .APB_READY(APB_READY),
        .APB_ERROR(APB_ERROR),

        .transaction_done(transaction_done)
    );

    //============================================================
    // APB MEMORY MODEL
    //============================================================

    always_comb begin

        APB_READY = 1'b0;
        APB_ERROR = 1'b0;
        APB_RDATA = '0;

        memory_index = APB_ADDR[9:2];

        if (APB_SEL && APB_ENABLE) begin

            APB_READY = 1'b1;

            if (!APB_WRITE)
                APB_RDATA = apb_memory[memory_index];

        end

    end

    //============================================================
    // APB MEMORY WRITE
    //============================================================

    always_ff @(posedge PCLK or negedge PRESETn) begin

        if (!PRESETn) begin

            for (int j = 0; j < 256; j = j + 1)
                apb_memory[j] <= '0;

        end

        else begin

            if (APB_SEL &&
                APB_ENABLE &&
                APB_WRITE &&
                APB_READY) begin

                apb_memory[memory_index] <= APB_WDATA;

                $display(
                    "APB MEMORY: WRITE ADDR=%h DATA=%h",
                    APB_ADDR,
                    APB_WDATA
                );

            end

        end

    end

    //============================================================
    // CLOCK GENERATION
    //============================================================

    // ACLK = 10 ns
    initial begin

        ACLK = 1'b0;

        forever #5 ACLK = ~ACLK;

    end

    // PCLK = 14 ns
    initial begin

        PCLK = 1'b0;

        forever #7 PCLK = ~PCLK;

    end

    //============================================================
    // RESET
    //============================================================

    initial begin

        ARESETn = 1'b0;
        PRESETn = 1'b0;

        #40;

        ARESETn = 1'b1;
        PRESETn = 1'b1;

        $display("");
        $display("==============================================");
        $display("RESET COMPLETE");
        $display("==============================================");
        $display("");

    end

    //============================================================
    // INITIAL AXI VALUES
    //============================================================

    initial begin

        axi.AWVALID = 1'b0;
        axi.AWADDR  = '0;

        axi.WVALID  = 1'b0;
        axi.WDATA   = '0;
        axi.WSTRB   = '1;

        axi.BREADY  = 1'b1;

        axi.ARVALID = 1'b0;
        axi.ARADDR  = '0;

        axi.RREADY  = 1'b1;

    end

    //============================================================
    //============================================================
    // ASSERTION SECTION
    //============================================================
    //============================================================


    //============================================================
    // ASSERTION 1
    // AXI WRITE ADDRESS STABILITY
    //============================================================

    property axi_awaddr_stable;

        @(posedge ACLK)

        disable iff (!ARESETn)

        axi.AWVALID && !axi.AWREADY
        |=> $stable(axi.AWADDR);

    endproperty

    assert property (axi_awaddr_stable)

        else $error(
            "ASSERTION FAILED: AXI AWADDR changed while AWVALID=1 and AWREADY=0"
        );


    //============================================================
    // ASSERTION 2
    // AXI WRITE DATA STABILITY
    //============================================================

    property axi_wdata_stable;

        @(posedge ACLK)

        disable iff (!ARESETn)

        axi.WVALID && !axi.WREADY
        |=> $stable(axi.WDATA);

    endproperty

    assert property (axi_wdata_stable)

        else $error(
            "ASSERTION FAILED: AXI WDATA changed while WVALID=1 and WREADY=0"
        );


    //============================================================
    // ASSERTION 3
    // AXI READ ADDRESS STABILITY
    //============================================================

    property axi_araddr_stable;

        @(posedge ACLK)

        disable iff (!ARESETn)

        axi.ARVALID && !axi.ARREADY
        |=> $stable(axi.ARADDR);

    endproperty

    assert property (axi_araddr_stable)

        else $error(
            "ASSERTION FAILED: AXI ARADDR changed while ARVALID=1 and ARREADY=0"
        );


    //============================================================
    // ASSERTION 4
    // AXI READ DATA STABILITY
    //============================================================

    property axi_rdata_stable;

        @(posedge ACLK)

        disable iff (!ARESETn)

        axi.RVALID && !axi.RREADY
        |=> $stable(axi.RDATA);

    endproperty

    assert property (axi_rdata_stable)

        else $error(
            "ASSERTION FAILED: AXI RDATA changed while RVALID=1 and RREADY=0"
        );


    //============================================================
    // ASSERTION 5
    // APB PENABLE REQUIRES PSEL
    //============================================================

    property apb_enable_requires_select;

        @(posedge PCLK)

        disable iff (!PRESETn)

        APB_ENABLE |-> APB_SEL;

    endproperty

    assert property (apb_enable_requires_select)

        else $error(
            "ASSERTION FAILED: APB PENABLE is active without PSEL"
        );


    //============================================================
    // ASSERTION 6
    // APB ADDRESS STABILITY DURING ACCESS
    //============================================================

    property apb_addr_stable;

        @(posedge PCLK)

        disable iff (!PRESETn)

        APB_SEL && APB_ENABLE
        |=> $stable(APB_ADDR);

    endproperty

    assert property (apb_addr_stable)

        else $error(
            "ASSERTION FAILED: APB address changed during ACCESS phase"
        );


    //============================================================
    // ASSERTION 7
    // APB ACCESS SHOULD HAVE READY
    //============================================================

    property apb_access_ready;

        @(posedge PCLK)

        disable iff (!PRESETn)

        APB_SEL && APB_ENABLE
        |-> APB_READY;

    endproperty

    assert property (apb_access_ready)

        else $error(
            "ASSERTION FAILED: APB ACCESS active without PREADY"
        );


    //============================================================
    // ASSERTION 8
    // APB ERROR SHOULD BE LOW
    //============================================================

    property apb_no_error;

        @(posedge PCLK)

        disable iff (!PRESETn)

        APB_SEL && APB_ENABLE
        |-> !APB_ERROR;

    endproperty

    assert property (apb_no_error)

        else $error(
            "ASSERTION FAILED: APB ERROR detected during normal access"
        );


    //============================================================
    // ASSERTION 9
    // AXI READ RESPONSE MUST BE VALID WITH READY
    //============================================================

    property axi_read_response_handshake;

        @(posedge ACLK)

        disable iff (!ARESETn)

        axi.RVALID |-> axi.RREADY;

    endproperty

    assert property (axi_read_response_handshake)

        else $error(
            "ASSERTION FAILED: AXI RVALID active while RREADY is low"
        );


    //============================================================
    // ASSERTION 10
    // TRANSACTION DONE SHOULD BE A PULSE
    //============================================================

    property transaction_done_pulse;

        @(posedge PCLK)

        disable iff (!PRESETn)

        transaction_done |=> !transaction_done;

    endproperty

    assert property (transaction_done_pulse)

        else $error(
            "ASSERTION FAILED: transaction_done remained high"
        );


    //============================================================
    // DIRECTED WRITE
    //============================================================

    task automatic axi_write(
        input logic [ADDR_WIDTH-1:0] addr,
        input logic [DATA_WIDTH-1:0] data
    );

        begin

            $display("");
            $display("----------------------------------------------");
            $display("ASSERTION TEST: AXI WRITE");
            $display("Address = %h", addr);
            $display("Data    = %h", data);
            $display("----------------------------------------------");

            @(posedge ACLK);

            axi.AWADDR  <= addr;
            axi.AWVALID <= 1'b1;

            wait (axi.AWREADY == 1'b1);

            @(posedge ACLK);

            axi.AWVALID <= 1'b0;

            @(posedge ACLK);

            axi.WDATA  <= data;
            axi.WVALID <= 1'b1;

            wait (axi.WREADY == 1'b1);

            @(posedge ACLK);

            axi.WVALID <= 1'b0;

            wait (transaction_done == 1'b1);

            @(posedge PCLK);

            if (apb_memory[addr[9:2]] == data) begin

                $display(
                    "PASS: AXI WRITE completed correctly."
                );

            end

            else begin

                $display(
                    "FAIL: AXI WRITE memory mismatch."
                );

            end

        end

    endtask


    //============================================================
    // DIRECTED READ
    //============================================================

    task automatic axi_read(
        input logic [ADDR_WIDTH-1:0] addr,
        input logic [DATA_WIDTH-1:0] expected
    );

        logic [DATA_WIDTH-1:0] received;

        begin

            $display("");
            $display("----------------------------------------------");
            $display("ASSERTION TEST: AXI READ");
            $display("Address  = %h", addr);
            $display("Expected = %h", expected);
            $display("----------------------------------------------");

            @(posedge ACLK);

            axi.ARADDR  <= addr;
            axi.ARVALID <= 1'b1;

            wait (axi.ARREADY == 1'b1);

            @(posedge ACLK);

            axi.ARVALID <= 1'b0;

            wait (axi.RVALID == 1'b1);

            received = axi.RDATA;

            if (received == expected) begin

                $display(
                    "PASS: AXI READ returned %h",
                    received
                );

            end

            else begin

                $display(
                    "FAIL: AXI READ expected=%h received=%h",
                    expected,
                    received
                );

            end

            @(posedge ACLK);

        end

    endtask


    //============================================================
    // MAIN ASSERTION TEST
    //============================================================

    initial begin

        wait (ARESETn == 1'b1);
        wait (PRESETn == 1'b1);

        repeat (3)
            @(posedge ACLK);

        $display("");
        $display("==============================================");
        $display("      STEP 3.3 ASSERTION VERIFICATION");
        $display("==============================================");
        $display("");

        //========================================================
        // TEST 1
        // WRITE
        //========================================================

        axi_write(
            32'h00000010,
            32'hDEADBEEF
        );

        //========================================================
        // TEST 2
        // READ
        //========================================================

        axi_read(
            32'h00000010,
            32'hDEADBEEF
        );

        //========================================================
        // TEST 3
        // SECOND WRITE
        //========================================================

        axi_write(
            32'h00000020,
            32'hCAFEBABE
        );

        //========================================================
        // TEST 4
        // SECOND READ
        //========================================================

        axi_read(
            32'h00000020,
            32'hCAFEBABE
        );

        //========================================================
        // FINAL
        //========================================================

        #100;

        $display("");
        $display("==============================================");
        $display("     STEP 3.3 ASSERTION TEST COMPLETE");
        $display("==============================================");
        $display("");
        $display("No assertion failures should be reported above.");
        $display("Directed AXI/APB transactions completed.");
        $display("");

        $finish;

    end


    //============================================================
    // WAVEFORM
    //============================================================

    initial begin

        $dumpfile("step3_3_assertions.vcd");

        $dumpvars(
            0,
            full_bridge_assert_tb
        );

    end

endmodule