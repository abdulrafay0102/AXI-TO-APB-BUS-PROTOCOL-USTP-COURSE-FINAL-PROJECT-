`timescale 1ns/1ps

module axi_request_bridge_tb;

    //==================================================
    // CLOCKS
    //==================================================

    logic ACLK;
    logic PCLK;

    //==================================================
    // RESETS
    //==================================================

    logic ARESETn;
    logic PRESETn;

    //==================================================
    // AXI INTERFACE
    //==================================================

    axi_if axi (
        .ACLK    (ACLK),
        .ARESETn (ARESETn)
    );

    //==================================================
    // REQUEST OUTPUTS
    //==================================================

    logic                  req_valid;
    logic [31:0]           req_addr;
    logic                  req_is_write;
    logic                  req_ready;

    //==================================================
    // TEST RESULT
    //==================================================

    logic test_passed;

    //==================================================
    // DUT
    //==================================================

    axi_request_bridge dut (

        .axi          (axi),

        .PCLK         (PCLK),
        .PRESETn      (PRESETn),

        .req_valid    (req_valid),
        .req_addr     (req_addr),
        .req_is_write (req_is_write),

        .req_ready    (req_ready)

    );

    //==================================================
    // CLOCK GENERATION
    //==================================================

    initial begin
        ACLK = 1'b0;
        forever #5 ACLK = ~ACLK;
    end

    initial begin
        PCLK = 1'b0;
        forever #7 PCLK = ~PCLK;
    end

    //==================================================
    // VCD
    //==================================================

    initial begin

        $dumpfile("dump.vcd");
        $dumpvars(0, axi_request_bridge_tb);

    end

    //==================================================
    // TEST
    //==================================================

    initial begin

        // Initial values
        ARESETn = 1'b0;
        PRESETn = 1'b0;

        axi.AWVALID = 1'b0;
        axi.AWADDR  = '0;

        axi.ARVALID = 1'b0;
        axi.ARADDR  = '0;

        axi.WVALID  = 1'b0;
        axi.WDATA   = '0;
        axi.WSTRB   = '0;

        axi.BREADY  = 1'b0;
        axi.RREADY  = 1'b0;

        req_ready = 1'b0;

        test_passed = 1'b1;

        //================================================
        // RESET
        //================================================

        #30;

        ARESETn = 1'b1;
        PRESETn = 1'b1;

        #20;

        //================================================
        // TEST HEADER
        //================================================

        $display("");
        $display("========================================");
        $display("   AXI REQUEST FIFO INTEGRATION TEST");
        $display("========================================");

        //================================================
        // TEST 1: WRITE REQUEST
        //================================================

        $display("");
        $display("TEST 1: AXI WRITE REQUEST");

        send_write_request(32'h00000010);

        // Wait until request becomes available
        wait (req_valid == 1'b1);

        $display("Address   = %h", req_addr);

        if (req_is_write)
            $display("Operation = WRITE");
        else
            $display("Operation = READ");

        if ((req_addr == 32'h00000010) &&
            (req_is_write == 1'b1)) begin

            $display("PASS: Write request transferred.");

        end
        else begin

            $display("ERROR: Write request data incorrect.");
            test_passed = 1'b0;

        end

        // Consume request
        @(negedge PCLK);
        req_ready = 1'b1;

        @(negedge PCLK);
        req_ready = 1'b0;

        //================================================
        // TEST 2: READ REQUEST
        //================================================

        $display("");
        $display("TEST 2: AXI READ REQUEST");

        send_read_request(32'h00000020);

        // Wait until request becomes available
        wait (req_valid == 1'b1);

        $display("Address   = %h", req_addr);

        if (req_is_write)
            $display("Operation = WRITE");
        else
            $display("Operation = READ");

        if ((req_addr == 32'h00000020) &&
            (req_is_write == 1'b0)) begin

            $display("PASS: Read request transferred.");

        end
        else begin

            $display("ERROR: Read request data incorrect.");
            test_passed = 1'b0;

        end

        // Consume request
        @(negedge PCLK);
        req_ready = 1'b1;

        @(negedge PCLK);
        req_ready = 1'b0;

        //================================================
        // FINAL RESULT
        //================================================

        #30;

        $display("");

        if (test_passed) begin

            $display("========================================");
            $display(" AXI REQUEST FIFO TEST PASSED!");
            $display("========================================");

        end
        else begin

            $display("========================================");
            $display(" AXI REQUEST FIFO TEST FAILED!");
            $display("========================================");

        end

        $finish;

    end

    //==================================================
    // AXI WRITE REQUEST TASK
    //==================================================

    task send_write_request(
        input logic [31:0] address
    );

        begin

            @(negedge ACLK);

            axi.AWADDR  = address;
            axi.AWVALID = 1'b1;

            // Wait for AXI handshake
            while (!(axi.AWVALID && axi.AWREADY))
                @(negedge ACLK);

            @(negedge ACLK);

            axi.AWVALID = 1'b0;
            axi.AWADDR  = '0;

        end

    endtask

    //==================================================
    // AXI READ REQUEST TASK
    //==================================================

    task send_read_request(
        input logic [31:0] address
    );

        begin

            @(negedge ACLK);

            axi.ARADDR  = address;
            axi.ARVALID = 1'b1;

            // Wait for AXI handshake
            while (!(axi.ARVALID && axi.ARREADY))
                @(negedge ACLK);

            @(negedge ACLK);

            axi.ARVALID = 1'b0;
            axi.ARADDR  = '0;

        end

    endtask

endmodule