`ifndef AXI_MONITOR_SV
`define AXI_MONITOR_SV

class axi_monitor extends uvm_monitor;

    `uvm_component_utils(axi_monitor)

    //========================================================
    // Virtual Interface
    //========================================================
    virtual axi_if axi_vif;

    //========================================================
    // Analysis Port
    // Sends monitored transactions to scoreboard/coverage
    //========================================================
    uvm_analysis_port #(axi_transaction) analysis_port;


    //========================================================
    // Constructor
    //========================================================
    function new(
        string name = "axi_monitor",
        uvm_component parent = null
    );
        super.new(name, parent);

        analysis_port = new(
            "analysis_port",
            this
        );
    endfunction


    //========================================================
    // Build Phase
    //========================================================
    virtual function void build_phase(
        uvm_phase phase
    );

        super.build_phase(phase);

        if (!uvm_config_db#(virtual axi_if)::get(
                this,
                "",
                "axi_vif",
                axi_vif
            )) begin

            `uvm_fatal(
                "NOVIF",
                "AXI virtual interface was not found."
            )

        end

    endfunction


    //========================================================
    // Run Phase
    //========================================================
    virtual task run_phase(
        uvm_phase phase
    );

        wait (axi_vif.ARESETn == 1'b1);

        fork

            monitor_write_address();

            monitor_write_data();

            monitor_write_response();

            monitor_read_address();

            monitor_read_response();

        join_none

    endtask


    //========================================================
    // Monitor Write Address
    //========================================================
    virtual task monitor_write_address();

        axi_transaction tr;

        forever begin

            @(posedge axi_vif.AWVALID);

            if (axi_vif.AWREADY) begin

                tr = axi_transaction::type_id::create(
                    "write_addr_tr"
                );

                tr.addr     = axi_vif.AWADDR;
                tr.data     = '0;
                tr.is_write = 1'b1;

                `uvm_info(
                    "AXI_MON",
                    $sformatf(
                        "WRITE ADDRESS: ADDR=%08h",
                        axi_vif.AWADDR
                    ),
                    UVM_MEDIUM
                )

                analysis_port.write(tr);

            end
            else begin

                while (!axi_vif.AWREADY) begin
                    @(posedge axi_vif.ACLK);
                end

                tr = axi_transaction::type_id::create(
                    "write_addr_tr"
                );

                tr.addr     = axi_vif.AWADDR;
                tr.data     = '0;
                tr.is_write = 1'b1;

                `uvm_info(
                    "AXI_MON",
                    $sformatf(
                        "WRITE ADDRESS: ADDR=%08h",
                        axi_vif.AWADDR
                    ),
                    UVM_MEDIUM
                )

                analysis_port.write(tr);

            end

        end

    endtask


    //========================================================
    // Monitor Write Data
    //========================================================
    virtual task monitor_write_data();

        axi_transaction tr;

        forever begin

            @(posedge axi_vif.WVALID);

            if (axi_vif.WREADY) begin

                tr = axi_transaction::type_id::create(
                    "write_data_tr"
                );

                tr.addr      = '0;
                tr.data      = axi_vif.WDATA;
                tr.is_write  = 1'b1;

                `uvm_info(
                    "AXI_MON",
                    $sformatf(
                        "WRITE DATA: DATA=%08h WSTRB=%h",
                        axi_vif.WDATA,
                        axi_vif.WSTRB
                    ),
                    UVM_MEDIUM
                )

                analysis_port.write(tr);

            end
            else begin

                while (!axi_vif.WREADY) begin
                    @(posedge axi_vif.ACLK);
                end

                tr = axi_transaction::type_id::create(
                    "write_data_tr"
                );

                tr.addr      = '0;
                tr.data      = axi_vif.WDATA;
                tr.is_write  = 1'b1;

                `uvm_info(
                    "AXI_MON",
                    $sformatf(
                        "WRITE DATA: DATA=%08h WSTRB=%h",
                        axi_vif.WDATA,
                        axi_vif.WSTRB
                    ),
                    UVM_MEDIUM
                )

                analysis_port.write(tr);

            end

        end

    endtask


    //========================================================
    // Monitor Write Response
    //========================================================
    virtual task monitor_write_response();

        axi_transaction tr;

        forever begin

            @(posedge axi_vif.BVALID);

            if (axi_vif.BREADY) begin

                tr = axi_transaction::type_id::create(
                    "write_response_tr"
                );

                tr.addr     = '0;
                tr.data     = '0;
                tr.is_write = 1'b1;

                `uvm_info(
                    "AXI_MON",
                    $sformatf(
                        "WRITE RESPONSE: BRESP=%02b",
                        axi_vif.BRESP
                    ),
                    UVM_MEDIUM
                )

                analysis_port.write(tr);

            end
            else begin

                while (!axi_vif.BREADY) begin
                    @(posedge axi_vif.ACLK);
                end

                tr = axi_transaction::type_id::create(
                    "write_response_tr"
                );

                tr.addr     = '0;
                tr.data     = '0;
                tr.is_write = 1'b1;

                `uvm_info(
                    "AXI_MON",
                    $sformatf(
                        "WRITE RESPONSE: BRESP=%02b",
                        axi_vif.BRESP
                    ),
                    UVM_MEDIUM
                )

                analysis_port.write(tr);

            end

        end

    endtask


    //========================================================
    // Monitor Read Address
    //========================================================
    virtual task monitor_read_address();

        axi_transaction tr;

        forever begin

            @(posedge axi_vif.ARVALID);

            if (axi_vif.ARREADY) begin

                tr = axi_transaction::type_id::create(
                    "read_addr_tr"
                );

                tr.addr      = axi_vif.ARADDR;
                tr.data      = '0;
                tr.is_write  = 1'b0;

                `uvm_info(
                    "AXI_MON",
                    $sformatf(
                        "READ ADDRESS: ADDR=%08h",
                        axi_vif.ARADDR
                    ),
                    UVM_MEDIUM
                )

                // Send read request
                analysis_port.write(tr);

            end
            else begin

                while (!axi_vif.ARREADY) begin
                    @(posedge axi_vif.ACLK);
                end

                tr = axi_transaction::type_id::create(
                    "read_addr_tr"
                );

                tr.addr      = axi_vif.ARADDR;
                tr.data      = '0;
                tr.is_write  = 1'b0;

                `uvm_info(
                    "AXI_MON",
                    $sformatf(
                        "READ ADDRESS: ADDR=%08h",
                        axi_vif.ARADDR
                    ),
                    UVM_MEDIUM
                )

                analysis_port.write(tr);

            end

        end

    endtask


    //========================================================
    // Monitor Read Response
    //========================================================
    virtual task monitor_read_response();

        axi_transaction tr;

        forever begin

            @(posedge axi_vif.RVALID);

            if (axi_vif.RREADY) begin

                tr = axi_transaction::type_id::create(
                    "read_response_tr"
                );

                tr.addr      = '0;
                tr.data      = axi_vif.RDATA;
                tr.is_write  = 1'b0;

                `uvm_info(
                    "AXI_MON",
                    $sformatf(
                        "READ RESPONSE: DATA=%08h RRESP=%02b",
                        axi_vif.RDATA,
                        axi_vif.RRESP
                    ),
                    UVM_MEDIUM
                )

                // Send read response
                analysis_port.write(tr);

            end
            else begin

                while (!axi_vif.RREADY) begin
                    @(posedge axi_vif.ACLK);
                end

                tr = axi_transaction::type_id::create(
                    "read_response_tr"
                );

                tr.addr      = '0;
                tr.data      = axi_vif.RDATA;
                tr.is_write  = 1'b0;

                `uvm_info(
                    "AXI_MON",
                    $sformatf(
                        "READ RESPONSE: DATA=%08h RRESP=%02b",
                        axi_vif.RDATA,
                        axi_vif.RRESP
                    ),
                    UVM_MEDIUM
                )

                analysis_port.write(tr);

            end

        end

    endtask


endclass

`endif