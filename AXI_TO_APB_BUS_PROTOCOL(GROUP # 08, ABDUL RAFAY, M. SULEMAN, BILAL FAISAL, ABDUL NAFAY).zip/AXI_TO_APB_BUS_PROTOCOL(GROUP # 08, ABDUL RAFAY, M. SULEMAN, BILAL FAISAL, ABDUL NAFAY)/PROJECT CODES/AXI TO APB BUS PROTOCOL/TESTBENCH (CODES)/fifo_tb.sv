// module fifo_tb;

//     parameter DATA_WIDTH = 32;
//     parameter DEPTH = 8;

//     logic clk;
//     logic resetn;

//     logic write_en;
//     logic read_en;

//     logic [DATA_WIDTH-1:0] data_in;
//     logic [DATA_WIDTH-1:0] data_out;

//     logic full;
//     logic empty;

//     logic [$clog2(DEPTH+1)-1:0] count;

//     logic test_pass;


//     //==================================================
//     // FIFO DUT
//     //==================================================

//     fifo #(
//         .DATA_WIDTH(DATA_WIDTH),
//         .DEPTH(DEPTH)
//     ) dut (
//         .clk(clk),
//         .resetn(resetn),

//         .write_en(write_en),
//         .read_en(read_en),

//         .data_in(data_in),
//         .data_out(data_out),

//         .full(full),
//         .empty(empty),

//         .count(count)
//     );


//     //==================================================
//     // CLOCK
//     //==================================================

//     initial begin
//         clk = 1'b0;
//         forever #5 clk = ~clk;
//     end


//     //==================================================
//     // WAVEFORM
//     //==================================================

//     initial begin
//         $dumpfile("dump.vcd");
//         $dumpvars(0, fifo_tb);
//     end


//     //==================================================
//     // TEST
//     //==================================================

//     initial begin

//         resetn   = 1'b0;
//         write_en = 1'b0;
//         read_en  = 1'b0;
//         data_in  = '0;
//         test_pass = 1'b1;


//         //================================================
//         // RESET
//         //================================================

//         #20;

//         resetn = 1'b1;

//         @(negedge clk);


//         //================================================
//         // WRITE DATA
//         //================================================

//         $display("");
//         $display("Starting FIFO WRITE...");

//         write_en = 1'b1;
//         data_in = 32'h11111111;

//         @(negedge clk);
//         data_in = 32'h22222222;

//         @(negedge clk);
//         data_in = 32'h33333333;

//         @(negedge clk);
//         write_en = 1'b0;

//         $display("FIFO WRITE COMPLETED");
//         $display("FIFO COUNT = %0d", count);


//         //================================================
//         // READ DATA
//         //================================================

//         $display("");
//         $display("Starting FIFO READ...");

//         read_en = 1'b1;


//         // ---------------------------------------------
//         // READ 1
//         // ---------------------------------------------

//         #1;

//         if (data_out == 32'h11111111) begin
//             $display("Read Data = %h", data_out);
//         end
//         else begin
//             $display("ERROR: Expected 11111111, Got %h", data_out);
//             test_pass = 1'b0;
//         end


//         // Consume first data
//         @(posedge clk);
//         #1;


//         // ---------------------------------------------
//         // READ 2
//         // ---------------------------------------------

//         if (data_out == 32'h22222222) begin
//             $display("Read Data = %h", data_out);
//         end
//         else begin
//             $display("ERROR: Expected 22222222, Got %h", data_out);
//             test_pass = 1'b0;
//         end


//         // Consume second data
//         @(posedge clk);
//         #1;


//         // ---------------------------------------------
//         // READ 3
//         // ---------------------------------------------

//         if (data_out == 32'h33333333) begin
//             $display("Read Data = %h", data_out);
//         end
//         else begin
//             $display("ERROR: Expected 33333333, Got %h", data_out);
//             test_pass = 1'b0;
//         end


//         // Consume third data
//         @(posedge clk);
//         #1;

//         read_en = 1'b0;


//         //================================================
//         // FINAL CHECK
//         //================================================

//         if (count != 0) begin
//             $display("ERROR: FIFO COUNT is not zero!");
//             $display("Final COUNT = %0d", count);
//             test_pass = 1'b0;
//         end


//         if (test_pass) begin

//             $display("");
//             $display("========================================");
//             $display("          FIFO TEST PASSED!");
//             $display("========================================");

//         end
//         else begin

//             $display("");
//             $display("========================================");
//             $display("          FIFO TEST FAILED!");
//             $display("========================================");

//         end


//         #20;

//         $finish;

//     end

// endmodule




module fifo_tb;

    parameter DATA_WIDTH = 32;
    parameter DEPTH = 8;

    logic clk;
    logic resetn;

    logic write_en;
    logic read_en;

    logic [DATA_WIDTH-1:0] data_in;
    logic [DATA_WIDTH-1:0] data_out;

    logic full;
    logic empty;

    logic [$clog2(DEPTH+1)-1:0] count;

    logic test_pass;


    //==================================================
    // FIFO DUT
    //==================================================

    fifo #(
        .DATA_WIDTH(DATA_WIDTH),
        .DEPTH(DEPTH)
    ) dut (
        .clk(clk),
        .resetn(resetn),

        .write_en(write_en),
        .read_en(read_en),

        .data_in(data_in),
        .data_out(data_out),

        .full(full),
        .empty(empty),

        .count(count)
    );


    //==================================================
    // CLOCK
    //==================================================

    initial begin
        clk = 1'b0;
        forever #5 clk = ~clk;
    end


    //==================================================
    // WAVEFORM
    //==================================================

    initial begin
        $dumpfile("dump.vcd");
        $dumpvars(0, fifo_tb);
    end


    //==================================================
    // TEST
    //==================================================

    initial begin

        resetn    = 1'b0;
        write_en  = 1'b0;
        read_en   = 1'b0;
        data_in   = '0;
        test_pass = 1'b1;


        //================================================
        // RESET
        //================================================

        #20;

        resetn = 1'b1;

        @(negedge clk);


        //================================================
        // TEST 1: EMPTY CONDITION
        //================================================

        $display("");
        $display("========================================");
        $display("TEST 1: EMPTY CONDITION");
        $display("========================================");

        if (empty && count == 0) begin
            $display("FIFO is EMPTY after reset.");
        end
        else begin
            $display("ERROR: FIFO should be EMPTY!");
            test_pass = 1'b0;
        end


        //================================================
        // TEST 2: FILL FIFO
        //================================================

        $display("");
        $display("========================================");
        $display("TEST 2: FILL FIFO");
        $display("========================================");

        write_en = 1'b1;

        data_in = 32'h10000001;
        @(negedge clk);

        data_in = 32'h10000002;
        @(negedge clk);

        data_in = 32'h10000003;
        @(negedge clk);

        data_in = 32'h10000004;
        @(negedge clk);

        data_in = 32'h10000005;
        @(negedge clk);

        data_in = 32'h10000006;
        @(negedge clk);

        data_in = 32'h10000007;
        @(negedge clk);

        data_in = 32'h10000008;
        @(negedge clk);

        write_en = 1'b0;

        #1;

        $display("FIFO COUNT = %0d", count);

        if (full && count == DEPTH) begin
            $display("FIFO reached FULL condition.");
        end
        else begin
            $display("ERROR: FIFO should be FULL!");
            test_pass = 1'b0;
        end


        //================================================
        // TEST 3: OVERFLOW ATTEMPT
        //================================================

        $display("");
        $display("========================================");
        $display("TEST 3: OVERFLOW ATTEMPT");
        $display("========================================");

        data_in = 32'hFFFFFFFF;
        write_en = 1'b1;

        @(posedge clk);
        #1;

        write_en = 1'b0;

        $display("Attempted write while FIFO was FULL.");
        $display("FIFO COUNT = %0d", count);

        if (count == DEPTH) begin
            $display("Overflow correctly blocked.");
        end
        else begin
            $display("ERROR: FIFO count changed during overflow!");
            test_pass = 1'b0;
        end


        //================================================
        // TEST 4: READ ALL DATA
        //================================================

        $display("");
        $display("========================================");
        $display("TEST 4: READ FIFO DATA");
        $display("========================================");

        read_en = 1'b1;

        #1;

        if (data_out == 32'h10000001)
            $display("Read Data = %h", data_out);
        else begin
            $display("ERROR: Expected 10000001, Got %h", data_out);
            test_pass = 1'b0;
        end

        @(posedge clk);
        #1;

        if (data_out == 32'h10000002)
            $display("Read Data = %h", data_out);
        else begin
            $display("ERROR: Expected 10000002, Got %h", data_out);
            test_pass = 1'b0;
        end

        @(posedge clk);
        #1;

        if (data_out == 32'h10000003)
            $display("Read Data = %h", data_out);
        else begin
            $display("ERROR: Expected 10000003, Got %h", data_out);
            test_pass = 1'b0;
        end

        @(posedge clk);
        #1;

        if (data_out == 32'h10000004)
            $display("Read Data = %h", data_out);
        else begin
            $display("ERROR: Expected 10000004, Got %h", data_out);
            test_pass = 1'b0;
        end

        @(posedge clk);
        #1;

        if (data_out == 32'h10000005)
            $display("Read Data = %h", data_out);
        else begin
            $display("ERROR: Expected 10000005, Got %h", data_out);
            test_pass = 1'b0;
        end

        @(posedge clk);
        #1;

        if (data_out == 32'h10000006)
            $display("Read Data = %h", data_out);
        else begin
            $display("ERROR: Expected 10000006, Got %h", data_out);
            test_pass = 1'b0;
        end

        @(posedge clk);
        #1;

        if (data_out == 32'h10000007)
            $display("Read Data = %h", data_out);
        else begin
            $display("ERROR: Expected 10000007, Got %h", data_out);
            test_pass = 1'b0;
        end

        @(posedge clk);
        #1;

        if (data_out == 32'h10000008)
            $display("Read Data = %h", data_out);
        else begin
            $display("ERROR: Expected 10000008, Got %h", data_out);
            test_pass = 1'b0;
        end

        @(posedge clk);
        #1;

        read_en = 1'b0;

        if (empty && count == 0)
            $display("FIFO is EMPTY after all reads.");
        else begin
            $display("ERROR: FIFO should be EMPTY!");
            test_pass = 1'b0;
        end


        //================================================
        // TEST 5: UNDERFLOW ATTEMPT
        //================================================

        $display("");
        $display("========================================");
        $display("TEST 5: UNDERFLOW ATTEMPT");
        $display("========================================");

        read_en = 1'b1;

        @(posedge clk);
        #1;

        read_en = 1'b0;

        $display("Attempted read while FIFO was EMPTY.");
        $display("FIFO COUNT = %0d", count);

        if (count == 0) begin
            $display("Underflow correctly blocked.");
        end
        else begin
            $display("ERROR: FIFO count changed during underflow!");
            test_pass = 1'b0;
        end


        //================================================
        // TEST 6: POINTER WRAP-AROUND
        //================================================

        $display("");
        $display("========================================");
        $display("TEST 6: POINTER WRAP-AROUND");
        $display("========================================");

        // At this point both pointers have
        // wrapped back to location 0.

        // ---------------------------------------------
        // Write new data after wrap-around
        // ---------------------------------------------

        write_en = 1'b1;
        read_en  = 1'b0;
        data_in  = 32'hAAAA0001;

        // Allow write to occur
        @(posedge clk);
        #1;

        write_en = 1'b0;


        // ---------------------------------------------
        // Check newly written data
        // ---------------------------------------------

        if (data_out == 32'hAAAA0001) begin
            $display("Wrap-around data = %h", data_out);
        end
        else begin
            $display("ERROR: Expected AAAA0001, Got %h", data_out);
            test_pass = 1'b0;
        end


        // ---------------------------------------------
        // Read wrapped data
        // ---------------------------------------------

        read_en = 1'b1;

        @(posedge clk);
        #1;

        read_en = 1'b0;


        if (count == 0 && empty) begin
            $display("Wrap-around read completed correctly.");
        end
        else begin
            $display("ERROR: FIFO should be EMPTY after wrap-around read!");
            test_pass = 1'b0;
        end


        //================================================
        // FINAL CHECK
        //================================================

        #1;

        if (test_pass && empty && !full && count == 0) begin

            $display("");
            $display("========================================");
            $display("      FIFO BOUNDARY TEST PASSED!");
            $display("========================================");

        end
        else begin

            $display("");
            $display("========================================");
            $display("      FIFO BOUNDARY TEST FAILED!");
            $display("========================================");

        end


        #20;

        $finish;

    end

endmodule