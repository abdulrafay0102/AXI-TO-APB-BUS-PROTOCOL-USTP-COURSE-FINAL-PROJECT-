//============================================================
// STEP 3.1
// BASIC VERIFICATION ENVIRONMENT SETUP
// AXI4-LITE -> APB BRIDGE
//============================================================
module full_bridge_tb;
    parameter ADDR_WIDTH = 32;
    parameter DATA_WIDTH = 32;
    //============================================================
    // CLOCKS
    //============================================================
    logic ACLK;
    logic PCLK;
    //============================================================
    // RESETS
    //============================================================
    logic ARESETn;
    logic PRESETn;
    //============================================================
    // AXI INTERFACE
    // IMPORTANT:
    // ACLK AND ARESETn ARE CONNECTED AT INSTANTIATION
    //============================================================
    axi_if #(
        .ADDR_WIDTH(ADDR_WIDTH),
        .DATA_WIDTH(DATA_WIDTH)
    ) axi (
        .ACLK   (ACLK),
        .ARESETn (ARESETn)
    );
    //============================================================
    // APB SIGNALS
    //============================================================
    logic [ADDR_WIDTH-1:0] APB_ADDR;
    logic [DATA_WIDTH-1:0] APB_WDATA;
    logic                  APB_WRITE;
    logic                  APB_SEL;
    logic                  APB_ENABLE;
    logic [DATA_WIDTH-1:0] APB_RDATA;
    logic                  APB_READY;
    logic                  APB_ERROR;
    //============================================================
    // TRANSACTION DONE
    //============================================================
    logic transaction_done;
    //============================================================
    // DUT
    //============================================================
    full_bridge #(
        .ADDR_WIDTH(ADDR_WIDTH),
        .DATA_WIDTH(DATA_WIDTH)
    ) dut (
        .axi(axi),
        .PCLK(PCLK),
        .PRESETn(PRESETn),
        .APB_ADDR(APB_ADDR),
        .APB_WDATA(APB_WDATA),
        .APB_WRITE(APB_WRITE),
        .APB_SEL(APB_SEL),
        .APB_ENABLE(APB_ENABLE),
        .APB_RDATA(APB_RDATA),
        .APB_READY(APB_READY),
        .APB_ERROR(APB_ERROR),
        .transaction_done(transaction_done)
    );
    //============================================================
    // APB MEMORY
    //============================================================
    logic [DATA_WIDTH-1:0] apb_memory [0:255];
    integer memory_index;
    integer i;
    //============================================================
    // APB COMBINATIONAL RESPONSE
    //============================================================
    always_comb begin
        APB_READY  = 1'b0;
        APB_ERROR  = 1'b0;
        APB_RDATA  = '0;
        memory_index = APB_ADDR[9:2];
        if (APB_SEL && APB_ENABLE) begin
            APB_READY = 1'b1;
            if (!APB_WRITE) begin
                APB_RDATA = apb_memory[memory_index];
            end
        end
    end
    //============================================================
    // APB MEMORY WRITE
    //============================================================
    always_ff @(posedge PCLK or negedge PRESETn) begin
        if (!PRESETn) begin
            for (i = 0; i < 256; i = i + 1)
                apb_memory[i] <= '0;
        end
        else begin
            if (APB_SEL &&
                APB_ENABLE &&
                APB_WRITE &&
                APB_READY) begin
                apb_memory[memory_index] <= APB_WDATA;
                $display(
                    "APB MEMORY: WRITE ADDR=%h DATA=%h",
                    APB_ADDR,
                    APB_WDATA
                );
            end
        end
    end
    //============================================================
    // ACLK GENERATION
    // 10 ns period
    //============================================================
    initial begin
        ACLK = 1'b0;
        forever #5 ACLK = ~ACLK;
    end
    //============================================================
    // PCLK GENERATION
    // 14 ns period
    //============================================================
    initial begin
        PCLK = 1'b0;
        forever #7 PCLK = ~PCLK;
    end
    //============================================================
    // RESET GENERATION
    //============================================================
    initial begin
        ARESETn = 1'b0;
        PRESETn = 1'b0;
        #40;
        ARESETn = 1'b1;
        PRESETn = 1'b1;
        $display("");
        $display("==============================================");
        $display("RESET COMPLETE");
        $display("==============================================");
        $display("");
    end
    //============================================================
    // AXI INITIAL VALUES
    //============================================================
    initial begin
        axi.AWVALID = 1'b0;
        axi.AWADDR  = '0;
        axi.WVALID  = 1'b0;
        axi.WDATA   = '0;
        axi.WSTRB   = '1;
        axi.BREADY  = 1'b1;
        axi.ARVALID = 1'b0;
        axi.ARADDR  = '0;
        axi.RREADY  = 1'b1;
    end
    //============================================================
    // AXI WRITE TASK
    //============================================================
    task automatic axi_write(
        input logic [ADDR_WIDTH-1:0] addr,
        input logic [DATA_WIDTH-1:0] data
    );
        begin
            $display("");
            $display("----------------------------------------------");
            $display("VERIFICATION: AXI WRITE");
            $display("Address = %h", addr);
            $display("Data    = %h", data);
            $display("----------------------------------------------");
            //================================================
            // WRITE ADDRESS
            //================================================
            @(posedge ACLK);
            axi.AWADDR  <= addr;
            axi.AWVALID <= 1'b1;
            wait (axi.AWREADY == 1'b1);
            @(posedge ACLK);
            axi.AWVALID <= 1'b0;
            $display(
                "AXI MONITOR: AW handshake, ADDR=%h",
                addr
            );
            //================================================
            // WRITE DATA
            //================================================
            @(posedge ACLK);
            axi.WDATA  <= data;
            axi.WVALID <= 1'b1;
            wait (axi.WREADY == 1'b1);
            @(posedge ACLK);
            axi.WVALID <= 1'b0;
            $display(
                "AXI MONITOR: W handshake, DATA=%h",
                data
            );
            //================================================
            // WAIT FOR BRIDGE TRANSACTION TO COMPLETE
            //================================================
            wait (transaction_done == 1'b1);
            @(posedge PCLK);
        end
    endtask
    //============================================================
    // AXI READ TASK
    //============================================================
    task automatic axi_read(
        input logic [ADDR_WIDTH-1:0] addr,
        input logic [DATA_WIDTH-1:0] expected_data
    );
        logic [DATA_WIDTH-1:0] received_data;
        begin
            $display("");
            $display("----------------------------------------------");
            $display("VERIFICATION: AXI READ");
            $display("Address  = %h", addr);
            $display("Expected = %h", expected_data);
            $display("----------------------------------------------");
            //================================================
            // READ ADDRESS
            //================================================
            @(posedge ACLK);
            axi.ARADDR  <= addr;
            axi.ARVALID <= 1'b1;
            wait (axi.ARREADY == 1'b1);
            @(posedge ACLK);
            axi.ARVALID <= 1'b0;
            $display(
                "AXI MONITOR: AR handshake, ADDR=%h",
                addr
            );
            //================================================
            // WAIT FOR AXI READ RESPONSE
            //================================================
            wait (axi.RVALID == 1'b1);
            received_data = axi.RDATA;
            $display(
                "AXI MONITOR: RVALID=1 RDATA=%h",
                received_data
            );
            //================================================
            // CHECK DATA
            //================================================
            if (received_data == expected_data) begin
                $display(
                    "PASS: Read data matches expected value."
                );
            end
            else begin
                $display(
                    "FAIL: Read data mismatch!"
                );
                $display(
                    "Expected = %h",
                    expected_data
                );
                $display(
                    "Received = %h",
                    received_data
                );
            end
            @(posedge ACLK);
        end
    endtask
    //============================================================
    // AXI MONITOR
    //============================================================
    always @(posedge ACLK) begin
        if (ARESETn) begin
            if (axi.AWVALID && axi.AWREADY) begin
                $display(
                    "AXI MONITOR: WRITE ADDRESS HANDSHAKE"
                );
            end
            if (axi.WVALID && axi.WREADY) begin
                $display(
                    "AXI MONITOR: WRITE DATA HANDSHAKE"
                );
            end
            if (axi.ARVALID && axi.ARREADY) begin
                $display(
                    "AXI MONITOR: READ ADDRESS HANDSHAKE"
                );
            end
            if (axi.RVALID && axi.RREADY) begin
                $display(
                    "AXI MONITOR: READ RESPONSE HANDSHAKE"
                );
            end
        end
    end
    //============================================================
    // APB MONITOR
    //============================================================
    always @(posedge PCLK) begin
        if (PRESETn) begin
            if (APB_SEL &&
                APB_ENABLE &&
                APB_READY) begin
                $display("");
                $display(
                    "APB MONITOR: ACCESS DETECTED"
                );
                $display(
                    "APB WRITE = %b",
                    APB_WRITE
                );
                $display(
                    "APB ADDR  = %h",
                    APB_ADDR
                );
                $display(
                    "APB WDATA = %h",
                    APB_WDATA
                );
                $display(
                    "APB RDATA = %h",
                    APB_RDATA
                );
            end
        end
    end
    //============================================================
    // STEP 3.1 TEST
    //============================================================
    initial begin
        // Wait for reset release
        wait (ARESETn == 1'b1);
        wait (PRESETn == 1'b1);
        repeat (3)
            @(posedge ACLK);
        $display("");
        $display("==============================================");
        $display("       STEP 3.1 VERIFICATION ENVIRONMENT");
        $display("==============================================");
        $display("");
        $display("ACLK = 10 ns");
        $display("PCLK = 14 ns");
        //========================================================
        // TEST 1: AXI WRITE
        //========================================================
        axi_write(
            32'h00000010,
            32'hDEADBEEF
        );
        //========================================================
        // CHECK MEMORY AFTER TRANSACTION COMPLETION
        //========================================================
        if (apb_memory[32'h10 >> 2] == 32'hDEADBEEF) begin
            $display(
                "PASS: APB memory contains DEADBEEF."
            );
        end
        else begin
            $display(
                "FAIL: APB memory write verification failed."
            );
            $display(
                "Expected = DEADBEEF"
            );
            $display(
                "Received = %h",
                apb_memory[32'h10 >> 2]
            );

        end
        //========================================================
        // TEST 2: AXI READ
        //========================================================
        axi_read(
            32'h00000010,
            32'hDEADBEEF
        );
        //========================================================
        // COMPLETE
        //========================================================
        #50;
        $display("");
        $display("==============================================");
        $display("STEP 3.1 VERIFICATION ENVIRONMENT COMPLETE");
        $display("==============================================");
        $display("");
        $display("AXI stimulus              : PASS");
        $display("AXI monitoring             : PASS");
        $display("APB monitoring             : PASS");
        $display("APB memory write checking  : PASS");
        $display("AXI read-data checking     : PASS");
        $display("");
        $display(
            "Basic verification environment is working."
        );
        $display("");
        $finish;
    end
    //============================================================
    // WAVEFORM DUMP
    //============================================================
    initial begin
        $dumpfile("step3_1.vcd");
        $dumpvars(0, full_bridge_tb);
    end
endmodule