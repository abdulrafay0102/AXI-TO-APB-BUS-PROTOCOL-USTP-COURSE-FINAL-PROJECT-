`timescale 1ns/1ps

module full_bridge_constrained_random_tb;

    parameter ADDR_WIDTH = 32;
    parameter DATA_WIDTH = 32;

    // ============================================================
    // CLOCKS AND RESETS
    // ============================================================

    logic ACLK;
    logic PCLK;

    logic ARESETn;
    logic PRESETn;

    // AXI interface
    axi_if #(
        .ADDR_WIDTH(ADDR_WIDTH),
        .DATA_WIDTH(DATA_WIDTH)
    ) axi (
        .ACLK   (ACLK),
        .ARESETn (ARESETn)
    );

    // APB signals
    logic [ADDR_WIDTH-1:0] APB_ADDR;
    logic [DATA_WIDTH-1:0] APB_WDATA;
    logic APB_WRITE;
    logic APB_SEL;
    logic APB_ENABLE;

    logic [DATA_WIDTH-1:0] APB_RDATA;
    logic APB_READY;
    logic APB_ERROR;

    logic transaction_done;


    // ============================================================
    // DUT
    // ============================================================

    full_bridge #(
        .ADDR_WIDTH(ADDR_WIDTH),
        .DATA_WIDTH(DATA_WIDTH)
    ) dut (
        .axi(axi),

        .PCLK(PCLK),
        .PRESETn(PRESETn),

        .APB_ADDR(APB_ADDR),
        .APB_WDATA(APB_WDATA),
        .APB_WRITE(APB_WRITE),
        .APB_SEL(APB_SEL),
        .APB_ENABLE(APB_ENABLE),

        .APB_RDATA(APB_RDATA),
        .APB_READY(APB_READY),
        .APB_ERROR(APB_ERROR),

        .transaction_done(transaction_done)
    );


    // ============================================================
    // APB MEMORY
    // ============================================================

    apb_memory #(
        .ADDR_WIDTH(ADDR_WIDTH),
        .DATA_WIDTH(DATA_WIDTH),
        .DEPTH(256)
    ) memory (
        .PCLK(PCLK),
        .PRESETn(PRESETn),

        .PADDR(APB_ADDR),
        .PWDATA(APB_WDATA),
        .PRDATA(APB_RDATA),

        .PWRITE(APB_WRITE),
        .PSEL(APB_SEL),
        .PENABLE(APB_ENABLE),

        .PREADY(APB_READY),
        .PSLVERR(APB_ERROR)
    );


    // ============================================================
    // CLOCK GENERATION
    // ACLK = 10 ns
    // PCLK = 14 ns
    // ============================================================

    initial begin
        ACLK = 1'b0;

        forever #5 ACLK = ~ACLK;
    end

    initial begin
        PCLK = 1'b0;

        forever #7 PCLK = ~PCLK;
    end


//     // ============================================================
//     // AXI TRANSACTION CLASS
//     // ============================================================

//     class axi_transaction;

//         rand bit [31:0] addr;
//         rand bit [31:0] data;
//         rand bit        is_write;
//         rand bit        separate_aw_w;

//         // --------------------------------------------------------
//         // Address must be word aligned and inside our test memory
//         // --------------------------------------------------------

//         constraint address_constraint {
//             addr inside {
//                 32'h00000010,
//                 32'h00000020,
//                 32'h00000030,
//                 32'h00000040,
//                 32'h00000050,
//                 32'h00000060,
//                 32'h00000070,
//                 32'h00000080
//             };

//             addr[1:0] == 2'b00;
//         }

//         // --------------------------------------------------------
//         // Randomly choose READ or WRITE
//         // --------------------------------------------------------

//         constraint operation_constraint {
//             is_write dist {
//                 1 := 50,
//                 0 := 50
//             };
//         }

//         // --------------------------------------------------------
//         // Separate AW/W is only meaningful for writes
//         // Approximately 30% of writes use separated AW/W
//         // --------------------------------------------------------

//         constraint separate_constraint {
//             separate_aw_w dist {
//                 1 := 30,
//                 0 := 70
//             };
//         }

//     endclass


    // ============================================================
    // VARIABLES
    // ============================================================

    axi_transaction tr;

    integer pass_count;
    integer fail_count;

    integer write_count;
    integer read_count;
    integer separate_count;

    integer transaction_count;

    logic [DATA_WIDTH-1:0] expected_data;


    // ============================================================
    // RESET TASK
    // ============================================================

    task reset_dut;

        begin

            ARESETn = 1'b0;
            PRESETn = 1'b0;

            axi.AWADDR  = '0;
            axi.AWVALID = 1'b0;

            axi.WDATA   = '0;
            axi.WSTRB   = '0;
            axi.WVALID  = 1'b0;

            axi.BREADY  = 1'b1;

            axi.ARADDR  = '0;
            axi.ARVALID = 1'b0;

            axi.RREADY  = 1'b1;

            pass_count        = 0;
            fail_count        = 0;
            write_count       = 0;
            read_count        = 0;
            separate_count    = 0;
            transaction_count = 0;

            repeat (5)
                @(posedge ACLK);

            ARESETn = 1'b1;
            PRESETn = 1'b1;

            repeat (3)
                @(posedge ACLK);

            $display("");
            $display("==============================================");
            $display("             RESET COMPLETE");
            $display("==============================================");
            $display("");

        end

    endtask


    // ============================================================
    // AXI WRITE TASK
    // NORMAL WRITE
    // AW AND W ARE SENT TOGETHER
    // ============================================================

    task axi_write(
        input logic [ADDR_WIDTH-1:0] address,
        input logic [DATA_WIDTH-1:0] write_data
    );

        begin

            $display("");
            $display("----------------------------------------------");
            $display("RANDOM TEST: AXI WRITE");
            $display("Address = %h", address);
            $display("Data    = %h", write_data);
            $display("AW/W    = SAME TIME");
            $display("----------------------------------------------");

            @(posedge ACLK);

            axi.AWADDR  <= address;
            axi.AWVALID <= 1'b1;

            axi.WDATA   <= write_data;
            axi.WSTRB   <= 4'b1111;
            axi.WVALID  <= 1'b1;

            // Wait until both channels are accepted
            while (!(axi.AWREADY && axi.WREADY))
                @(posedge ACLK);

            @(posedge ACLK);

            axi.AWVALID <= 1'b0;
            axi.WVALID  <= 1'b0;

            write_count++;

            // Wait for bridge transaction to complete
            wait(transaction_done == 1'b1);

            // Check APB memory
            if (memory.memory[address >> 2] == write_data) begin

                pass_count++;

                $display(
                    "PASS: Memory[%0d] = %h",
                    address >> 2,
                    memory.memory[address >> 2]
                );

            end
            else begin

                fail_count++;

                $display(
                    "FAIL: Memory[%0d] = %h, Expected = %h",
                    address >> 2,
                    memory.memory[address >> 2],
                    write_data
                );

            end

            @(posedge PCLK);

        end

    endtask


    // ============================================================
    // AXI WRITE TASK
    // SEPARATE AW AND W
    // ============================================================

    task axi_write_separate(
        input logic [ADDR_WIDTH-1:0] address,
        input logic [DATA_WIDTH-1:0] write_data
    );

        begin

            $display("");
            $display("----------------------------------------------");
            $display("RANDOM TEST: SEPARATE AW / W");
            $display("Address = %h", address);
            $display("Data    = %h", write_data);
            $display("AW/W    = SEPARATED");
            $display("----------------------------------------------");

            @(posedge ACLK);

            // ----------------------------------------------------
            // Send AW first
            // ----------------------------------------------------

            axi.AWADDR  <= address;
            axi.AWVALID <= 1'b1;

            while (!axi.AWREADY)
                @(posedge ACLK);

            @(posedge ACLK);

            axi.AWVALID <= 1'b0;


            // ----------------------------------------------------
            // Random delay between AW and W
            // ----------------------------------------------------

            repeat ($urandom_range(1,4))
                @(posedge ACLK);


            // ----------------------------------------------------
            // Send W
            // ----------------------------------------------------

            axi.WDATA   <= write_data;
            axi.WSTRB   <= 4'b1111;
            axi.WVALID  <= 1'b1;

            while (!axi.WREADY)
                @(posedge ACLK);

            @(posedge ACLK);

            axi.WVALID <= 1'b0;

            write_count++;
            separate_count++;


            // ----------------------------------------------------
            // Wait for transaction completion
            // ----------------------------------------------------

            wait(transaction_done == 1'b1);


            // ----------------------------------------------------
            // Check memory
            // ----------------------------------------------------

            if (memory.memory[address >> 2] == write_data) begin

                pass_count++;

                $display(
                    "PASS: Separate AW/W completed. Memory[%0d] = %h",
                    address >> 2,
                    memory.memory[address >> 2]
                );

            end
            else begin

                fail_count++;

                $display(
                    "FAIL: Separate AW/W memory mismatch. Got=%h Expected=%h",
                    memory.memory[address >> 2],
                    write_data
                );

            end

            @(posedge PCLK);

        end

    endtask


    // ============================================================
    // AXI READ TASK
    // ============================================================

    task axi_read(
        input logic [ADDR_WIDTH-1:0] address,
        input logic [DATA_WIDTH-1:0] expected
    );

        logic [DATA_WIDTH-1:0] read_value;

        begin

            $display("");
            $display("----------------------------------------------");
            $display("RANDOM TEST: AXI READ");
            $display("Address  = %h", address);
            $display("Expected = %h", expected);
            $display("----------------------------------------------");

            @(posedge ACLK);

            axi.ARADDR  <= address;
            axi.ARVALID <= 1'b1;

            while (!axi.ARREADY)
                @(posedge ACLK);

            @(posedge ACLK);

            axi.ARVALID <= 1'b0;

            read_count++;


            // ----------------------------------------------------
            // Wait for AXI read response
            // ----------------------------------------------------

            wait(axi.RVALID == 1'b1);

            read_value = axi.RDATA;

            if (read_value == expected) begin

                pass_count++;

                $display(
                    "PASS: AXI READ returned %h",
                    read_value
                );

            end
            else begin

                fail_count++;

                $display(
                    "FAIL: AXI READ returned %h, Expected = %h",
                    read_value,
                    expected
                );

            end

            @(posedge ACLK);

        end

    endtask


    // ============================================================
    // MAIN RANDOMIZED TEST
    // ============================================================

    initial begin

        reset_dut();

        tr = new();


        $display("");
        $display("==============================================");
        $display("   STEP 3.5 CONSTRAINED-RANDOM VERIFICATION");
        $display("==============================================");
        $display("");


        // --------------------------------------------------------
        // Generate 20 random transactions
        // --------------------------------------------------------

        repeat (20) begin

            transaction_count++;

            // Randomize transaction
            if (!tr.randomize()) begin

                $display("ERROR: Transaction randomization failed.");
                fail_count++;

            end
            else begin

                $display("");
                $display(
                    "TRANSACTION %0d: WRITE=%b ADDR=%h DATA=%h SEPARATE=%b",
                    transaction_count,
                    tr.is_write,
                    tr.addr,
                    tr.data,
                    tr.separate_aw_w
                );


                // ------------------------------------------------
                // WRITE
                // ------------------------------------------------

                if (tr.is_write) begin

                    if (tr.separate_aw_w)
                        axi_write_separate(tr.addr, tr.data);

                    else
                        axi_write(tr.addr, tr.data);

                end


                // ------------------------------------------------
                // READ
                // ------------------------------------------------

                else begin

                    // ------------------------------------------------
                    // Read only addresses that have known data.
                    // First perform a write, then read the same
                    // address so that the expected value is known.
                    // ------------------------------------------------

                    expected_data = tr.data;

                    axi_write(
                        tr.addr,
                        expected_data
                    );

                    axi_read(
                        tr.addr,
                        expected_data
                    );

                end

            end

        end


        // ========================================================
        // FINAL SUMMARY
        // ========================================================

        #20;

        $display("");
        $display("==============================================");
        $display("      STEP 3.5 TEST SUMMARY");
        $display("==============================================");
        $display("Total Random Transactions = %0d", transaction_count);
        $display("Write Transactions        = %0d", write_count);
        $display("Read Transactions         = %0d", read_count);
        $display("Separate AW/W             = %0d", separate_count);
        $display("Total PASS                = %0d", pass_count);
        $display("Total FAIL                = %0d", fail_count);
        $display("==============================================");


        if (fail_count == 0) begin

            $display("");
            $display("STEP 3.5 CONSTRAINED-RANDOM VERIFICATION PASSED!");
            $display("");
            $display("All randomized transactions completed successfully.");

        end
        else begin

            $display("");
            $display("STEP 3.5 CONSTRAINED-RANDOM VERIFICATION FAILED!");
            $display("");
            $display("Please check the waveform and transaction log.");

        end


        $display("==============================================");
        $display("");

        $finish;

    end

    // ============================================================
    // VCD WAVEFORM
    // ============================================================

  	initial begin
        $dumpfile("step3_5_constrained_random.vcd");
        $dumpvars(0, full_bridge_constrained_random_tb);
    end

endmodule