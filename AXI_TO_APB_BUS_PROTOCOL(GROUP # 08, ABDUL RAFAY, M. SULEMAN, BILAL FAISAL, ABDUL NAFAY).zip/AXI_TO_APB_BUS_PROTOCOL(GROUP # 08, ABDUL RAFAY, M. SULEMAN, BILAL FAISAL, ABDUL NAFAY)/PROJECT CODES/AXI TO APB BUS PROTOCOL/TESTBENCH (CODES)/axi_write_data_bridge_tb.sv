`timescale 1ns/1ps

module axi_write_data_bridge_tb;

    //==================================================
    // CLOCKS
    //==================================================

    logic ACLK;
    logic PCLK;

    //==================================================
    // RESETS
    //==================================================

    logic ARESETn;
    logic PRESETn;

    //==================================================
    // AXI INTERFACE
    //==================================================

    axi_if axi (
        .ACLK    (ACLK),
        .ARESETn (ARESETn)
    );

    //==================================================
    // WRITE DATA OUTPUTS
    //==================================================

    logic                  wdata_valid;
    logic [31:0]           wdata;
    logic                  wdata_ready;

    //==================================================
    // TEST RESULT
    //==================================================

    logic test_passed;

    //==================================================
    // DUT
    //==================================================

    axi_write_data_bridge dut (

        .axi          (axi),

        .PCLK         (PCLK),
        .PRESETn      (PRESETn),

        .wdata_valid  (wdata_valid),
        .wdata        (wdata),

        .wdata_ready  (wdata_ready)

    );

    //==================================================
    // CLOCK GENERATION
    //==================================================

    initial begin

        ACLK = 1'b0;

        forever #5 ACLK = ~ACLK;

    end

    initial begin

        PCLK = 1'b0;

        forever #7 PCLK = ~PCLK;

    end

    //==================================================
    // VCD
    //==================================================

    initial begin

        $dumpfile("dump.vcd");
        $dumpvars(0, axi_write_data_bridge_tb);

    end

    //==================================================
    // TEST
    //==================================================

    initial begin

        //================================================
        // INITIAL VALUES
        //================================================

        ARESETn = 1'b0;
        PRESETn = 1'b0;

        axi.AWVALID = 1'b0;
        axi.AWADDR  = '0;

        axi.ARVALID = 1'b0;
        axi.ARADDR  = '0;

        axi.WVALID  = 1'b0;
        axi.WDATA   = '0;
        axi.WSTRB   = '0;

        axi.BREADY  = 1'b0;
        axi.RREADY  = 1'b0;

        wdata_ready = 1'b0;

        test_passed = 1'b1;

        //================================================
        // RESET
        //================================================

        #30;

        ARESETn = 1'b1;
        PRESETn = 1'b1;

        #20;

        //================================================
        // HEADER
        //================================================

        $display("");
        $display("========================================");
        $display("    AXI WRITE DATA FIFO TEST");
        $display("========================================");

        //================================================
        // TEST 1
        //================================================

        $display("");
        $display("TEST 1: SEND WRITE DATA");

        send_write_data(32'hDEADBEEF);

        wait (wdata_valid == 1'b1);

        $display("Write Data = %h", wdata);

        if (wdata == 32'hDEADBEEF) begin

            $display("PASS: Write data transferred.");

        end

        else begin

            $display("ERROR: Write data incorrect.");

            test_passed = 1'b0;

        end

        // Consume data
        @(negedge PCLK);

        wdata_ready = 1'b1;

        @(negedge PCLK);

        wdata_ready = 1'b0;

        //================================================
        // TEST 2
        //================================================

        $display("");
        $display("TEST 2: SEND SECOND WRITE DATA");

        send_write_data(32'h12345678);

        wait (wdata_valid == 1'b1);

        $display("Write Data = %h", wdata);

        if (wdata == 32'h12345678) begin

            $display("PASS: Second write data transferred.");

        end

        else begin

            $display("ERROR: Second write data incorrect.");

            test_passed = 1'b0;

        end

        // Consume data
        @(negedge PCLK);

        wdata_ready = 1'b1;

        @(negedge PCLK);

        wdata_ready = 1'b0;

        //================================================
        // TEST 3
        //================================================

        $display("");
        $display("TEST 3: SEND THIRD WRITE DATA");

        send_write_data(32'hA5A5A5A5);

        wait (wdata_valid == 1'b1);

        $display("Write Data = %h", wdata);

        if (wdata == 32'hA5A5A5A5) begin

            $display("PASS: Third write data transferred.");

        end

        else begin

            $display("ERROR: Third write data incorrect.");

            test_passed = 1'b0;

        end

        // Consume data
        @(negedge PCLK);

        wdata_ready = 1'b1;

        @(negedge PCLK);

        wdata_ready = 1'b0;

        //================================================
        // FINAL RESULT
        //================================================

        #30;

        $display("");

        if (test_passed) begin

            $display("========================================");
            $display(" AXI WRITE DATA FIFO TEST PASSED!");
            $display("========================================");

        end

        else begin

            $display("========================================");
            $display(" AXI WRITE DATA FIFO TEST FAILED!");
            $display("========================================");

        end

        $finish;

    end

    //==================================================
    // SEND WRITE DATA TASK
    //==================================================

    task send_write_data(
        input logic [31:0] data
    );

        begin

            @(negedge ACLK);

            axi.WDATA  = data;
            axi.WVALID = 1'b1;

            // Wait for AXI handshake
            while (!(axi.WVALID && axi.WREADY))
                @(negedge ACLK);

            @(negedge ACLK);

            axi.WVALID = 1'b0;
            axi.WDATA  = '0;

        end

    endtask

endmodule