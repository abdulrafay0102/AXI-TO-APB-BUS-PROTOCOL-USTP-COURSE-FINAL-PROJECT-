`ifndef AXI_AGENT_SV
`define AXI_AGENT_SV

class axi_agent extends uvm_agent;

    `uvm_component_utils(axi_agent)


    // ============================================================
    // UVM COMPONENTS
    // ============================================================

    axi_sequencer sequencer;
    axi_driver    driver;
    axi_monitor   monitor;


    // ============================================================
    // CONSTRUCTOR
    // ============================================================

    function new(
        string name = "axi_agent",
        uvm_component parent = null
    );

        super.new(name, parent);

    endfunction


    // ============================================================
    // BUILD PHASE
    // ============================================================

    virtual function void build_phase(
        uvm_phase phase
    );

        super.build_phase(phase);


        // --------------------------------------------------------
        // Create sequencer
        // --------------------------------------------------------

        sequencer = axi_sequencer::type_id::create(
            "sequencer",
            this
        );


        // --------------------------------------------------------
        // Create driver
        // --------------------------------------------------------

        driver = axi_driver::type_id::create(
            "driver",
            this
        );
      
        // --------------------------------------------------------
        // Create monitor
        // --------------------------------------------------------
        monitor = axi_monitor::type_id::create(
            "monitor",
            this
        );

    endfunction


    // ============================================================
    // CONNECT PHASE
    // ============================================================

    virtual function void connect_phase(
        uvm_phase phase
    );

        super.connect_phase(phase);


        // --------------------------------------------------------
        // Connect sequencer to driver
        // --------------------------------------------------------

        driver.seq_item_port.connect(
            sequencer.seq_item_export
        );

    endfunction

endclass

`endif